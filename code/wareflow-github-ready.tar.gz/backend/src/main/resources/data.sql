-- =====================================================
-- WareFlow - Sample Database Records (MySQL)
-- =====================================================

-- 1. Warehouses
INSERT INTO warehouses (warehouse_id, warehouse_name, location, capacity, occupied_space, available_space, manager, status) VALUES
(1, 'North Logistics Hub', 'Building 4A, Industrial Zone North, Chicago, IL', 15000, 10250, 4750, 'Robert Vance', 'ACTIVE'),
(2, 'Metro Central Depot', 'Bay 12, Terminal Ave, Dallas, TX', 20000, 14800, 5200, 'Elena Rostova', 'ACTIVE'),
(3, 'Pacific Coastal Terminal', 'Pier 9, Harbor Logistics Center, Seattle, WA', 12000, 7900, 4100, 'David Chen', 'ACTIVE'),
(4, 'East Coast Distribution Hub', 'Zone 3, Commerce Way, Newark, NJ', 25000, 19400, 5600, 'Sarah Jenkins', 'ACTIVE'),
(5, 'Southwest Cargo Center', 'Bldg 8, Freight Blvd, Phoenix, AZ', 10000, 3200, 6800, 'Marcus Brody', 'MAINTENANCE');

-- 2. Suppliers
INSERT INTO suppliers (supplier_id, supplier_name, company, phone, email, address, products_supplied, status) VALUES
(1, 'Industrial Hydraulics Corp', 'IHC Global Ltd', '+1-555-019-2831', 'orders@ihcglobal.com', '742 Evergreen Blvd, Detroit, MI', 'Hydraulic pumps, valves, high-pressure fittings', 'ACTIVE'),
(2, 'Apex Fasteners & Hardware', 'Apex Manufacturing Inc', '+1-555-014-9820', 'sales@apexfasteners.com', '128 Assembly Row, Cleveland, OH', 'Grade 8 bolts, structural rivets, anchors', 'ACTIVE'),
(3, 'Quantum Sensor Systems', 'Quantum Tech LLC', '+1-555-017-3341', 'supply@quantumsensors.io', '550 Silicon Way, San Jose, CA', 'IoT telemetry nodes, photoelectric sensors', 'ACTIVE'),
(4, 'Titan Heavy Machinery Parts', 'Titan Industrial', '+1-555-012-7788', 'distribution@titanheavy.com', '900 Ironworks Rd, Pittsburgh, PA', 'Drive sprockets, heavy bearings, conveyor rollers', 'ACTIVE'),
(5, 'EcoPack Industrial Packaging', 'EcoPack Solutions', '+1-555-018-4455', 'service@ecopack.net', '312 Green St, Minneapolis, MN', 'Heavy-duty corrugated boxes, pallet wrap', 'ACTIVE'),
(6, 'Vanguard Electrical Supplies', 'Vanguard Power Systems', '+1-555-016-6622', 'b2b@vanguardpower.com', '405 Volt Dr, Atlanta, GA', 'Circuit breakers, 3-phase relays, cables', 'ACTIVE');

-- 3. Products
INSERT INTO products (product_id, product_name, sku, category, description, quantity, minimum_stock_level, unit_price, supplier_id, warehouse_id) VALUES
(1, 'Heavy Duty Hydraulic Pump 350-Bar', 'PUMP-HYD-350', 'Hydraulics', 'Cast iron dual-displacement hydraulic pump for industrial machinery', 42, 15, 680.00, 1, 1),
(2, 'Rotary Conveyor Roller 60mm', 'ROLL-CONV-060', 'Machinery Parts', 'Precision ball-bearing galvanized steel conveyor roller', 185, 40, 34.50, 4, 1),
(3, 'Grade 8 Zinc Hex Cap Screws (Box of 500)', 'FAST-HEX-G8', 'Fasteners', 'High-tensile zinc plated 1/2-13 structural hex bolts', 12, 25, 89.00, 2, 2),
(4, 'IoT Vibration & Temp Sensor Node', 'SENS-IOT-VT', 'Electronics', 'Wireless telemetry sensor node with IP67 enclosure for predictive maintenance', 68, 20, 145.00, 3, 2),
(5, 'Industrial 3-Phase Circuit Breaker 63A', 'ELEC-CB-63A', 'Electrical', 'DIN rail mounted thermal magnetic trip circuit breaker 400V', 4, 15, 112.50, 6, 2),
(6, 'Heavy Reinforced Pallet Stretch Film (6 Rolls)', 'PACK-STR-01', 'Packaging', '80 gauge puncture-resistant industrial cast stretch wrap', 240, 50, 78.00, 5, 3),
(7, 'Pneumatic Directional Control Valve', 'VALV-PNEU-52', 'Hydraulics', '5/2 way solenoid-actuated pneumatic valve 24V DC', 0, 10, 95.00, 1, 1),
(8, 'Double Row Spherical Roller Bearing', 'BEAR-SPH-222', 'Machinery Parts', 'Self-aligning heavy load bearing with cylindrical bore', 28, 12, 165.00, 4, 3),
(9, 'Optical Photoelectric Retroreflective Sensor', 'SENS-OPT-RR', 'Electronics', 'Compact optical sensor with 4m detection range and PNP output', 84, 18, 52.00, 3, 4),
(10, 'Heavy Duty Polyurethane Caster Wheel 8"', 'WHEEL-PU-08', 'Hardware', 'Swivel plate industrial caster with brake, 1200 lb rating', 96, 30, 44.00, 2, 4);

-- 4. Stock Inward (Sample Receipts)
INSERT INTO stock_inward (inward_id, product_id, supplier_id, warehouse_id, quantity, received_date, received_by, notes, status) VALUES
(1, 1, 1, 1, 20, DATE_SUB(NOW(), INTERVAL 5 DAY), 'John Miller (Supervisor)', 'Passed quality inspection on Dock 3', 'CONFIRMED'),
(2, 2, 4, 1, 100, DATE_SUB(NOW(), INTERVAL 4 DAY), 'Elena Rostova', 'Full pallet verified without damage', 'CONFIRMED'),
(3, 4, 3, 2, 50, DATE_SUB(NOW(), INTERVAL 3 DAY), 'David Chen', 'Firmware v2.4 pre-flashed', 'CONFIRMED'),
(4, 6, 5, 3, 150, DATE_SUB(NOW(), INTERVAL 2 DAY), 'Marcus Brody', 'Restocked packaging supplies for Q3', 'CONFIRMED'),
(5, 9, 3, 4, 60, DATE_SUB(NOW(), INTERVAL 1 DAY), 'Sarah Jenkins', 'Received from FedEx Freight express', 'CONFIRMED'),
(6, 10, 2, 4, 50, NOW(), 'Sarah Jenkins', 'Initial batch for assembly line', 'CONFIRMED');

-- 5. Stock Outward (Sample Dispatches)
INSERT INTO stock_outward (outward_id, product_id, warehouse_id, quantity, destination, dispatch_date, dispatched_by, notes, status) VALUES
(1, 1, 1, 5, 'Production Line A, Plant 2, Detroit', DATE_SUB(NOW(), INTERVAL 4 DAY), 'Marcus Brody', 'Scheduled replacement for stamping press', 'CONFIRMED'),
(2, 2, 1, 40, 'Midwest Logistics Hub, Indianapolis', DATE_SUB(NOW(), INTERVAL 3 DAY), 'Robert Vance', 'Conveyor line expansion project', 'CONFIRMED'),
(3, 6, 3, 30, 'Outbound Shipping Dock, Seattle', DATE_SUB(NOW(), INTERVAL 2 DAY), 'David Chen', 'Daily shipping wrap replenishment', 'CONFIRMED'),
(4, 4, 2, 12, 'Automated Sorting Center, Austin', DATE_SUB(NOW(), INTERVAL 1 DAY), 'Elena Rostova', 'Maintenance work order #WO-9941', 'CONFIRMED'),
(5, 10, 4, 14, 'Assembly Floor, Warehouse 4', NOW(), 'Sarah Jenkins', 'Mobile rack refitting work order', 'CONFIRMED');

-- 6. Purchase Orders
INSERT INTO purchase_orders (order_id, supplier_id, product_id, quantity, order_date, expected_delivery_date, total_amount, status) VALUES
(1, 1, 7, 25, DATE_SUB(NOW(), INTERVAL 6 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 2 DAY), 2375.00, 'APPROVED'),
(2, 6, 5, 30, DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 4 DAY), 3375.00, 'PENDING'),
(3, 2, 3, 50, DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 5 DAY), 4450.00, 'PENDING'),
(4, 4, 8, 40, DATE_SUB(NOW(), INTERVAL 10 DAY), DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), 6600.00, 'RECEIVED'),
(5, 3, 4, 100, DATE_SUB(NOW(), INTERVAL 14 DAY), DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY), 14500.00, 'RECEIVED');

-- 7. Users
INSERT INTO users (user_id, username, password, full_name, email, role, status) VALUES
(1, 'admin', '$2a$10$w09u7C4eZ1e3y4f5b6g7.e9r8t7y6u5i4o3p2a1s0d9f8g7h6j5k4', 'Dr. Alexander Vance', 'admin@wareflow.io', 'ADMIN', 'ACTIVE'),
(2, 'manager', '$2a$10$w09u7C4eZ1e3y4f5b6g7.e9r8t7y6u5i4o3p2a1s0d9f8g7h6j5k4', 'Elena Rostova', 'elena.rostova@wareflow.io', 'MANAGER', 'ACTIVE'),
(3, 'staff', '$2a$10$w09u7C4eZ1e3y4f5b6g7.e9r8t7y6u5i4o3p2a1s0d9f8g7h6j5k4', 'Marcus Brody', 'marcus.brody@wareflow.io', 'STAFF', 'ACTIVE');
