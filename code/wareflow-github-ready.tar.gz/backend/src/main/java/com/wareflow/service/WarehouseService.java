package com.wareflow.service;

import com.wareflow.entity.Warehouse;
import com.wareflow.exception.ResourceNotFoundException;
import com.wareflow.repository.WarehouseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class WarehouseService {

    private final WarehouseRepository warehouseRepository;

    public WarehouseService(WarehouseRepository warehouseRepository) {
        this.warehouseRepository = warehouseRepository;
    }

    public List<Warehouse> getAllWarehouses() {
        return warehouseRepository.findAll();
    }

    public Warehouse getWarehouseById(Long id) {
        return warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
    }

    public Warehouse createWarehouse(Warehouse warehouse) {
        warehouse.calculateAvailableSpace();
        return warehouseRepository.save(warehouse);
    }

    public Warehouse updateWarehouse(Long id, Warehouse details) {
        Warehouse warehouse = getWarehouseById(id);
        warehouse.setWarehouseName(details.getWarehouseName());
        warehouse.setLocation(details.getLocation());
        warehouse.setCapacity(details.getCapacity());
        if (details.getOccupiedSpace() != null) {
            warehouse.setOccupiedSpace(details.getOccupiedSpace());
        }
        warehouse.setManager(details.getManager());
        warehouse.setStatus(details.getStatus());
        warehouse.calculateAvailableSpace();
        return warehouseRepository.save(warehouse);
    }

    public void deleteWarehouse(Long id) {
        Warehouse warehouse = getWarehouseById(id);
        warehouseRepository.delete(warehouse);
    }
}
