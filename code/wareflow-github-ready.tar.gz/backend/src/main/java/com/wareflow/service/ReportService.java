package com.wareflow.service;

import com.wareflow.entity.Product;
import com.wareflow.entity.StockInward;
import com.wareflow.entity.StockOutward;
import com.wareflow.entity.Supplier;
import com.wareflow.entity.Warehouse;
import com.wareflow.repository.InwardRepository;
import com.wareflow.repository.OutwardRepository;
import com.wareflow.repository.ProductRepository;
import com.wareflow.repository.SupplierRepository;
import com.wareflow.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class ReportService {

    private final ProductRepository productRepository;
    private final InwardRepository inwardRepository;
    private final OutwardRepository outwardRepository;
    private final SupplierRepository supplierRepository;
    private final WarehouseRepository warehouseRepository;

    public ReportService(ProductRepository productRepository,
                         InwardRepository inwardRepository,
                         OutwardRepository outwardRepository,
                         SupplierRepository supplierRepository,
                         WarehouseRepository warehouseRepository) {
        this.productRepository = productRepository;
        this.inwardRepository = inwardRepository;
        this.outwardRepository = outwardRepository;
        this.supplierRepository = supplierRepository;
        this.warehouseRepository = warehouseRepository;
    }

    public Map<String, Object> getInventoryReport() {
        List<Product> products = productRepository.findAll();
        long totalItems = products.size();
        long totalStock = products.stream().mapToLong(Product::getQuantity).sum();
        BigDecimal totalValuation = products.stream()
                .map(p -> p.getUnitPrice().multiply(BigDecimal.valueOf(p.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, Object> report = new HashMap<>();
        report.put("generatedAt", new Date());
        report.put("totalProducts", totalItems);
        report.put("totalStockUnits", totalStock);
        report.put("totalValuation", totalValuation);
        report.put("products", products);
        return report;
    }

    public Map<String, Object> getWarehouseUtilizationReport() {
        List<Warehouse> warehouses = warehouseRepository.findAll();
        List<Map<String, Object>> metrics = new ArrayList<>();

        for (Warehouse w : warehouses) {
            Map<String, Object> item = new HashMap<>();
            item.put("warehouseId", w.getWarehouseId());
            item.put("warehouseName", w.getWarehouseName());
            item.put("location", w.getLocation());
            item.put("capacity", w.getCapacity());
            item.put("occupiedSpace", w.getOccupiedSpace());
            item.put("availableSpace", w.getAvailableSpace());
            double pct = w.getCapacity() > 0 ? ((double) w.getOccupiedSpace() / w.getCapacity()) * 100 : 0;
            item.put("utilizationPercentage", Math.round(pct * 10.0) / 10.0);
            item.put("status", w.getStatus());
            metrics.add(item);
        }

        Map<String, Object> report = new HashMap<>();
        report.put("generatedAt", new Date());
        report.put("warehouses", metrics);
        return report;
    }

    public List<StockInward> getInwardReport() {
        return inwardRepository.findAll();
    }

    public List<StockOutward> getOutwardReport() {
        return outwardRepository.findAll();
    }

    public List<Supplier> getSupplierReport() {
        return supplierRepository.findAll();
    }

    public List<Product> getLowStockReport() {
        return productRepository.findLowStockProducts();
    }
}
