package com.wareflow.controller;

import com.wareflow.dto.OutwardRequestDTO;
import com.wareflow.entity.StockOutward;
import com.wareflow.service.InventoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/outward")
@CrossOrigin(origins = "*")
public class OutwardController {

    private final InventoryService inventoryService;

    public OutwardController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping
    public ResponseEntity<List<StockOutward>> getAllOutward() {
        return ResponseEntity.ok(inventoryService.getAllOutward());
    }

    @GetMapping("/recent")
    public ResponseEntity<List<StockOutward>> getRecentOutward() {
        return ResponseEntity.ok(inventoryService.getRecentOutward());
    }

    @PostMapping
    public ResponseEntity<StockOutward> processOutwardStock(@RequestBody OutwardRequestDTO dto) {
        StockOutward created = inventoryService.processOutwardStock(dto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }
}
