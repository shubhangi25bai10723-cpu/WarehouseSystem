package com.wareflow.controller;

import com.wareflow.dto.DashboardSummaryDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.StockInward;
import com.wareflow.entity.StockOutward;
import com.wareflow.repository.*;
import com.wareflow.service.AlertService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final InwardRepository inwardRepository;
    private final OutwardRepository outwardRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final AlertService alertService;

    public DashboardController(ProductRepository productRepository,
                               SupplierRepository supplierRepository,
                               InwardRepository inwardRepository,
                               OutwardRepository outwardRepository,
                               PurchaseOrderRepository purchaseOrderRepository,
                               AlertService alertService) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
        this.inwardRepository = inwardRepository;
        this.outwardRepository = outwardRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.alertService = alertService;
    }

    @GetMapping("/summary")
    public ResponseEntity<DashboardSummaryDTO> getDashboardSummary() {
        DashboardSummaryDTO summary = new DashboardSummaryDTO();

        long totalProducts = productRepository.count();
        long totalStock = productRepository.sumTotalStock();
        long lowStock = productRepository.findLowStockProducts().size();
        long outOfStock = productRepository.findOutOfStockProducts().size();
        long totalSuppliers = supplierRepository.count();
        long pendingOrders = purchaseOrderRepository.countPendingOrders();

        LocalDateTime startOfToday = LocalDate.now().atStartOfDay();
        long todayInward = inwardRepository.sumQuantityReceivedSince(startOfToday);
        long todayOutward = outwardRepository.sumQuantityDispatchedSince(startOfToday);

        summary.setTotalProducts(totalProducts);
        summary.setTotalStock(totalStock);
        summary.setLowStockItems(lowStock);
        summary.setOutOfStockItems(outOfStock);
        summary.setTotalSuppliers(totalSuppliers);
        summary.setPendingOrders(pendingOrders);
        summary.setTodayInwardStock(todayInward);
        summary.setTodayOutwardStock(todayOutward);

        // Category distribution breakdown
        List<Product> products = productRepository.findAll();
        Map<String, Long> catCounts = products.stream()
                .collect(Collectors.groupingBy(Product::getCategory, Collectors.counting()));

        List<Map<String, Object>> catList = new ArrayList<>();
        catCounts.forEach((cat, count) -> {
            Map<String, Object> map = new HashMap<>();
            map.put("category", cat);
            map.put("count", count);
            catList.add(map);
        });
        summary.setCategoryDistribution(catList);

        // Recent stock movements (combining recent inward and outward)
        List<Map<String, Object>> movements = new ArrayList<>();
        List<StockInward> recentIn = inwardRepository.findTop10ByOrderByReceivedDateDesc();
        for (StockInward in : recentIn) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", "IN-" + in.getInwardId());
            m.put("type", "INWARD");
            m.put("productName", in.getProduct().getProductName());
            m.put("quantity", in.getQuantity());
            m.put("warehouse", in.getWarehouse().getWarehouseName());
            m.put("party", in.getSupplier() != null ? in.getSupplier().getSupplierName() : "External Inflow");
            m.put("timestamp", in.getReceivedDate());
            movements.add(m);
        }
        List<StockOutward> recentOut = outwardRepository.findTop10ByOrderByDispatchDateDesc();
        for (StockOutward out : recentOut) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", "OUT-" + out.getOutwardId());
            m.put("type", "OUTWARD");
            m.put("productName", out.getProduct().getProductName());
            m.put("quantity", out.getQuantity());
            m.put("warehouse", out.getWarehouse().getWarehouseName());
            m.put("party", out.getDestination());
            m.put("timestamp", out.getDispatchDate());
            movements.add(m);
        }
        movements.sort((a, b) -> ((LocalDateTime) b.get("timestamp")).compareTo((LocalDateTime) a.get("timestamp")));
        summary.setRecentStockMovements(movements.stream().limit(8).collect(Collectors.toList()));

        // Active alerts
        summary.setActiveAlerts(alertService.generateActiveAlerts());

        return ResponseEntity.ok(summary);
    }
}
