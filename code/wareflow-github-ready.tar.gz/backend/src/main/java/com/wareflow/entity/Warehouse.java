package com.wareflow.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "warehouses")
public class Warehouse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "warehouse_name", nullable = false, length = 100)
    private String warehouseName;

    @Column(name = "location", nullable = false, length = 200)
    private String location;

    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    @Column(name = "occupied_space", nullable = false)
    private Integer occupiedSpace = 0;

    @Column(name = "available_space", nullable = false)
    private Integer availableSpace;

    @Column(name = "manager", nullable = false, length = 100)
    private String manager;

    @Column(name = "status", nullable = false, length = 50)
    private String status = "ACTIVE";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Warehouse() {}

    public Warehouse(Long warehouseId, String warehouseName, String location, Integer capacity, 
                     Integer occupiedSpace, Integer availableSpace, String manager, String status) {
        this.warehouseId = warehouseId;
        this.warehouseName = warehouseName;
        this.location = location;
        this.capacity = capacity;
        this.occupiedSpace = occupiedSpace;
        this.availableSpace = availableSpace;
        this.manager = manager;
        this.status = status;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    @PreUpdate
    public void calculateAvailableSpace() {
        if (this.capacity != null) {
            int occupied = this.occupiedSpace != null ? this.occupiedSpace : 0;
            this.availableSpace = Math.max(0, this.capacity - occupied);
        }
    }

    // Getters and Setters
    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }

    public String getWarehouseName() { return warehouseName; }
    public void setWarehouseName(String warehouseName) { this.warehouseName = warehouseName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { 
        this.capacity = capacity;
        calculateAvailableSpace();
    }

    public Integer getOccupiedSpace() { return occupiedSpace; }
    public void setOccupiedSpace(Integer occupiedSpace) { 
        this.occupiedSpace = occupiedSpace;
        calculateAvailableSpace();
    }

    public Integer getAvailableSpace() { return availableSpace; }
    public void setAvailableSpace(Integer availableSpace) { this.availableSpace = availableSpace; }

    public String getManager() { return manager; }
    public void setManager(String manager) { this.manager = manager; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
