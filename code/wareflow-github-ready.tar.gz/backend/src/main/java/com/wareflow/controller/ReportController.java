package com.wareflow.controller;

import com.wareflow.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/inventory")
    public ResponseEntity<?> getInventoryReport() {
        return ResponseEntity.ok(reportService.getInventoryReport());
    }

    @GetMapping("/warehouses")
    public ResponseEntity<?> getWarehouseUtilizationReport() {
        return ResponseEntity.ok(reportService.getWarehouseUtilizationReport());
    }

    @GetMapping("/inward")
    public ResponseEntity<?> getInwardReport() {
        return ResponseEntity.ok(reportService.getInwardReport());
    }

    @GetMapping("/outward")
    public ResponseEntity<?> getOutwardReport() {
        return ResponseEntity.ok(reportService.getOutwardReport());
    }

    @GetMapping("/suppliers")
    public ResponseEntity<?> getSupplierReport() {
        return ResponseEntity.ok(reportService.getSupplierReport());
    }

    @GetMapping("/low-stock")
    public ResponseEntity<?> getLowStockReport() {
        return ResponseEntity.ok(reportService.getLowStockReport());
    }
}
