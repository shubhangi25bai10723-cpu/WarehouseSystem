package com.wareflow.service;

import com.wareflow.entity.Supplier;
import com.wareflow.exception.ResourceNotFoundException;
import com.wareflow.repository.SupplierRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SupplierService {

    private final SupplierRepository supplierRepository;

    public SupplierService(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    public Supplier getSupplierById(Long id) {
        return supplierRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found with ID: " + id));
    }

    public Supplier createSupplier(Supplier supplier) {
        return supplierRepository.save(supplier);
    }

    public Supplier updateSupplier(Long id, Supplier details) {
        Supplier supplier = getSupplierById(id);
        supplier.setSupplierName(details.getSupplierName());
        supplier.setCompany(details.getCompany());
        supplier.setPhone(details.getPhone());
        supplier.setEmail(details.getEmail());
        supplier.setAddress(details.getAddress());
        supplier.setProductsSupplied(details.getProductsSupplied());
        supplier.setStatus(details.getStatus());
        return supplierRepository.save(supplier);
    }

    public void deleteSupplier(Long id) {
        Supplier supplier = getSupplierById(id);
        supplierRepository.delete(supplier);
    }
}
