package com.wareflow.repository;

import com.wareflow.entity.PurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {

    List<PurchaseOrder> findByStatus(String status);

    @Query("SELECT COUNT(po) FROM PurchaseOrder po WHERE po.status = 'PENDING'")
    Long countPendingOrders();

    List<PurchaseOrder> findTop10ByOrderByOrderDateDesc();
}
