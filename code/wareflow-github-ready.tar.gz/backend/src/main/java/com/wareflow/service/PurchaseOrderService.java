package com.wareflow.service;

import com.wareflow.dto.PurchaseOrderDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.PurchaseOrder;
import com.wareflow.entity.Supplier;
import com.wareflow.exception.ResourceNotFoundException;
import com.wareflow.repository.ProductRepository;
import com.wareflow.repository.PurchaseOrderRepository;
import com.wareflow.repository.SupplierRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class PurchaseOrderService {

    private final PurchaseOrderRepository purchaseOrderRepository;
    private final SupplierRepository supplierRepository;
    private final ProductRepository productRepository;

    public PurchaseOrderService(PurchaseOrderRepository purchaseOrderRepository,
                                SupplierRepository supplierRepository,
                                ProductRepository productRepository) {
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.supplierRepository = supplierRepository;
        this.productRepository = productRepository;
    }

    public List<PurchaseOrder> getAllPurchaseOrders() {
        return purchaseOrderRepository.findAll();
    }

    public PurchaseOrder getPurchaseOrderById(Long id) {
        return purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase Order not found with ID: " + id));
    }

    public List<PurchaseOrder> getOrdersByStatus(String status) {
        return purchaseOrderRepository.findByStatus(status);
    }

    public PurchaseOrder createPurchaseOrder(PurchaseOrderDTO dto) {
        Supplier supplier = supplierRepository.findById(dto.getSupplierId())
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found with ID: " + dto.getSupplierId()));

        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + dto.getProductId()));

        PurchaseOrder po = new PurchaseOrder();
        po.setSupplier(supplier);
        po.setProduct(product);
        po.setQuantity(dto.getQuantity());
        po.setExpectedDeliveryDate(dto.getExpectedDeliveryDate());

        BigDecimal amount = dto.getTotalAmount();
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            amount = product.getUnitPrice().multiply(BigDecimal.valueOf(dto.getQuantity()));
        }
        po.setTotalAmount(amount);
        po.setStatus(dto.getStatus() != null ? dto.getStatus() : "PENDING");
        po.setOrderDate(LocalDateTime.now());

        return purchaseOrderRepository.save(po);
    }

    public PurchaseOrder updateStatus(Long id, String status) {
        PurchaseOrder po = getPurchaseOrderById(id);
        po.setStatus(status.toUpperCase());
        return purchaseOrderRepository.save(po);
    }

    public void deletePurchaseOrder(Long id) {
        PurchaseOrder po = getPurchaseOrderById(id);
        purchaseOrderRepository.delete(po);
    }
}
