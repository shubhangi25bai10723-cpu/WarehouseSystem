package com.wareflow.repository;

import com.wareflow.entity.StockOutward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OutwardRepository extends JpaRepository<StockOutward, Long> {

    List<StockOutward> findTop10ByOrderByDispatchDateDesc();

    @Query("SELECT COALESCE(SUM(o.quantity), 0) FROM StockOutward o WHERE o.dispatchDate >= :startOfDay")
    Long sumQuantityDispatchedSince(@Param("startOfDay") LocalDateTime startOfDay);

    List<StockOutward> findByDispatchDateBetween(LocalDateTime start, LocalDateTime end);
}
