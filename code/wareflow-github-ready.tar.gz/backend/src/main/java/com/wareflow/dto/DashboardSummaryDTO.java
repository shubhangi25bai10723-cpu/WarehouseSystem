package com.wareflow.dto;

import java.util.List;
import java.util.Map;

public class DashboardSummaryDTO {
    private long totalProducts;
    private long totalStock;
    private long lowStockItems;
    private long outOfStockItems;
    private long totalSuppliers;
    private long pendingOrders;
    private long todayInwardStock;
    private long todayOutwardStock;
    private List<Map<String, Object>> categoryDistribution;
    private List<Map<String, Object>> recentStockMovements;
    private List<AlertDTO> activeAlerts;

    public DashboardSummaryDTO() {}

    // Getters and Setters
    public long getTotalProducts() { return totalProducts; }
    public void setTotalProducts(long totalProducts) { this.totalProducts = totalProducts; }

    public long getTotalStock() { return totalStock; }
    public void setTotalStock(long totalStock) { this.totalStock = totalStock; }

    public long getLowStockItems() { return lowStockItems; }
    public void setLowStockItems(long lowStockItems) { this.lowStockItems = lowStockItems; }

    public long getOutOfStockItems() { return outOfStockItems; }
    public void setOutOfStockItems(long outOfStockItems) { this.outOfStockItems = outOfStockItems; }

    public long getTotalSuppliers() { return totalSuppliers; }
    public void setTotalSuppliers(long totalSuppliers) { this.totalSuppliers = totalSuppliers; }

    public long getPendingOrders() { return pendingOrders; }
    public void setPendingOrders(long pendingOrders) { this.pendingOrders = pendingOrders; }

    public long getTodayInwardStock() { return todayInwardStock; }
    public void setTodayInwardStock(long todayInwardStock) { this.todayInwardStock = todayInwardStock; }

    public long getTodayOutwardStock() { return todayOutwardStock; }
    public void setTodayOutwardStock(long todayOutwardStock) { this.todayOutwardStock = todayOutwardStock; }

    public List<Map<String, Object>> getCategoryDistribution() { return categoryDistribution; }
    public void setCategoryDistribution(List<Map<String, Object>> categoryDistribution) { this.categoryDistribution = categoryDistribution; }

    public List<Map<String, Object>> getRecentStockMovements() { return recentStockMovements; }
    public void setRecentStockMovements(List<Map<String, Object>> recentStockMovements) { this.recentStockMovements = recentStockMovements; }

    public List<AlertDTO> getActiveAlerts() { return activeAlerts; }
    public void setActiveAlerts(List<AlertDTO> activeAlerts) { this.activeAlerts = activeAlerts; }
}
