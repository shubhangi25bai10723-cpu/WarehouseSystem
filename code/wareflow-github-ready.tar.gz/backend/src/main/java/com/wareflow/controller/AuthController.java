package com.wareflow.controller;

import com.wareflow.dto.AuthResponse;
import com.wareflow.dto.LoginRequest;
import com.wareflow.entity.User;
import com.wareflow.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final UserRepository userRepository;

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername()).orElse(null);

        // Demo user check or password verification
        if (user != null && ("admin123".equals(request.getPassword()) || "password".equals(request.getPassword()) || request.getPassword().length() >= 4)) {
            String dummyJwt = "wareflow_token_" + UUID.randomUUID().toString();
            AuthResponse res = new AuthResponse(
                    dummyJwt,
                    user.getUserId(),
                    user.getUsername(),
                    user.getFullName(),
                    user.getRole()
            );
            return ResponseEntity.ok(res);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
    }

    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(@RequestParam(defaultValue = "admin") String username) {
        return userRepository.findByUsername(username)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
