package com.wareflow.repository;

import com.wareflow.entity.StockInward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface InwardRepository extends JpaRepository<StockInward, Long> {

    List<StockInward> findTop10ByOrderByReceivedDateDesc();

    @Query("SELECT COALESCE(SUM(i.quantity), 0) FROM StockInward i WHERE i.receivedDate >= :startOfDay")
    Long sumQuantityReceivedSince(@Param("startOfDay") LocalDateTime startOfDay);

    List<StockInward> findByReceivedDateBetween(LocalDateTime start, LocalDateTime end);
}
