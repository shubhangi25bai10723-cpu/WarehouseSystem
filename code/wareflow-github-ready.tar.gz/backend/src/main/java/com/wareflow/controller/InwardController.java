package com.wareflow.controller;

import com.wareflow.dto.InwardRequestDTO;
import com.wareflow.entity.StockInward;
import com.wareflow.service.InventoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inward")
@CrossOrigin(origins = "*")
public class InwardController {

    private final InventoryService inventoryService;

    public InwardController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping
    public ResponseEntity<List<StockInward>> getAllInward() {
        return ResponseEntity.ok(inventoryService.getAllInward());
    }

    @GetMapping("/recent")
    public ResponseEntity<List<StockInward>> getRecentInward() {
        return ResponseEntity.ok(inventoryService.getRecentInward());
    }

    @PostMapping
    public ResponseEntity<StockInward> processInwardStock(@RequestBody InwardRequestDTO dto) {
        StockInward created = inventoryService.processInwardStock(dto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }
}
