package com.wareflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * WareFlow - Warehouse Management System
 * Main Spring Boot Application Entry Point
 *
 * College Project Implementation
 * Tech Stack: Java 17+, Spring Boot 3, Spring Data JPA, Hibernate, MySQL, React.js
 */
@SpringBootApplication
public class WareFlowApplication {

    public static void main(String[] args) {
        SpringApplication.run(WareFlowApplication.class, args);
        System.out.println("=================================================");
        System.out.println("  WareFlow Spring Boot Backend Started Successfully! ");
        System.out.println("  REST APIs available on: http://localhost:8080/api ");
        System.out.println("=================================================");
    }
}
