package com.wareflow.service;

import com.wareflow.dto.ProductDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.Supplier;
import com.wareflow.entity.Warehouse;
import com.wareflow.exception.ResourceNotFoundException;
import com.wareflow.repository.ProductRepository;
import com.wareflow.repository.SupplierRepository;
import com.wareflow.repository.WarehouseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ProductService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final WarehouseRepository warehouseRepository;

    public ProductService(ProductRepository productRepository, 
                          SupplierRepository supplierRepository, 
                          WarehouseRepository warehouseRepository) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
        this.warehouseRepository = warehouseRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + id));
    }

    public Product getProductBySku(String sku) {
        return productRepository.findBySku(sku)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with SKU: " + sku));
    }

    public List<Product> searchProducts(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return productRepository.findAll();
        }
        return productRepository.searchProducts(keyword.trim());
    }

    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    public List<Product> getLowStockProducts() {
        return productRepository.findLowStockProducts();
    }

    public List<Product> getOutOfStockProducts() {
        return productRepository.findOutOfStockProducts();
    }

    public Product createProduct(ProductDTO dto) {
        if (productRepository.existsBySku(dto.getSku())) {
            throw new IllegalArgumentException("Product SKU already exists: " + dto.getSku());
        }

        Product product = new Product();
        product.setProductName(dto.getProductName());
        product.setSku(dto.getSku());
        product.setCategory(dto.getCategory());
        product.setDescription(dto.getDescription());
        product.setQuantity(dto.getQuantity() != null ? dto.getQuantity() : 0);
        product.setMinimumStockLevel(dto.getMinimumStockLevel() != null ? dto.getMinimumStockLevel() : 10);
        product.setUnitPrice(dto.getUnitPrice());

        if (dto.getSupplierId() != null) {
            Supplier supplier = supplierRepository.findById(dto.getSupplierId())
                    .orElseThrow(() -> new ResourceNotFoundException("Supplier not found with ID: " + dto.getSupplierId()));
            product.setSupplier(supplier);
        }

        if (dto.getWarehouseId() != null) {
            Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                    .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + dto.getWarehouseId()));
            product.setWarehouse(warehouse);
        }

        return productRepository.save(product);
    }

    public Product updateProduct(Long id, ProductDTO dto) {
        Product product = getProductById(id);

        if (!product.getSku().equals(dto.getSku()) && productRepository.existsBySku(dto.getSku())) {
            throw new IllegalArgumentException("Product SKU already exists: " + dto.getSku());
        }

        product.setProductName(dto.getProductName());
        product.setSku(dto.getSku());
        product.setCategory(dto.getCategory());
        product.setDescription(dto.getDescription());
        if (dto.getQuantity() != null) {
            product.setQuantity(dto.getQuantity());
        }
        product.setMinimumStockLevel(dto.getMinimumStockLevel());
        product.setUnitPrice(dto.getUnitPrice());

        if (dto.getSupplierId() != null) {
            Supplier supplier = supplierRepository.findById(dto.getSupplierId())
                    .orElseThrow(() -> new ResourceNotFoundException("Supplier not found with ID: " + dto.getSupplierId()));
            product.setSupplier(supplier);
        } else {
            product.setSupplier(null);
        }

        if (dto.getWarehouseId() != null) {
            Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                    .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + dto.getWarehouseId()));
            product.setWarehouse(warehouse);
        } else {
            product.setWarehouse(null);
        }

        return productRepository.save(product);
    }

    public void deleteProduct(Long id) {
        Product product = getProductById(id);
        productRepository.delete(product);
    }

    public Product adjustStock(Long productId, int delta) {
        Product product = getProductById(productId);
        int newQty = product.getQuantity() + delta;
        if (newQty < 0) {
            throw new IllegalArgumentException("Stock quantity cannot be negative. Current: " + product.getQuantity());
        }
        product.setQuantity(newQty);
        return productRepository.save(product);
    }
}
