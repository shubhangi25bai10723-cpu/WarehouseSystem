package com.wareflow.service;

import com.wareflow.dto.InwardRequestDTO;
import com.wareflow.dto.OutwardRequestDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.StockInward;
import com.wareflow.entity.StockOutward;
import com.wareflow.entity.Supplier;
import com.wareflow.entity.Warehouse;
import com.wareflow.exception.CapacityExceededException;
import com.wareflow.exception.InsufficientStockException;
import com.wareflow.exception.ResourceNotFoundException;
import com.wareflow.repository.InwardRepository;
import com.wareflow.repository.OutwardRepository;
import com.wareflow.repository.ProductRepository;
import com.wareflow.repository.SupplierRepository;
import com.wareflow.repository.WarehouseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Core Inventory Service handling critical business rules:
 * 1. Adding inward stock increases inventory quantity and adjusts warehouse space.
 * 2. Dispatching outward stock decreases inventory, strictly validating stock sufficiency.
 * 3. Prevents warehouse capacity overfill.
 */
@Service
@Transactional
public class InventoryService {

    private final ProductRepository productRepository;
    private final WarehouseRepository warehouseRepository;
    private final SupplierRepository supplierRepository;
    private final InwardRepository inwardRepository;
    private final OutwardRepository outwardRepository;

    public InventoryService(ProductRepository productRepository,
                            WarehouseRepository warehouseRepository,
                            SupplierRepository supplierRepository,
                            InwardRepository inwardRepository,
                            OutwardRepository outwardRepository) {
        this.productRepository = productRepository;
        this.warehouseRepository = warehouseRepository;
        this.supplierRepository = supplierRepository;
        this.inwardRepository = inwardRepository;
        this.outwardRepository = outwardRepository;
    }

    public List<StockInward> getAllInward() {
        return inwardRepository.findAll();
    }

    public List<StockInward> getRecentInward() {
        return inwardRepository.findTop10ByOrderByReceivedDateDesc();
    }

    public List<StockOutward> getAllOutward() {
        return outwardRepository.findAll();
    }

    public List<StockOutward> getRecentOutward() {
        return outwardRepository.findTop10ByOrderByDispatchDateDesc();
    }

    /**
     * Confirms inward receipt of goods:
     * - Validates warehouse capacity
     * - Increments product quantity
     * - Updates warehouse occupied space
     * - Persists inward transaction record
     */
    public StockInward processInwardStock(InwardRequestDTO dto) {
        if (dto.getQuantity() == null || dto.getQuantity() <= 0) {
            throw new IllegalArgumentException("Inward quantity must be greater than zero.");
        }

        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + dto.getProductId()));

        Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + dto.getWarehouseId()));

        // Business Rule: Validate Warehouse Capacity
        if (warehouse.getAvailableSpace() < dto.getQuantity()) {
            throw new CapacityExceededException("Warehouse capacity exceeded! Available space: " 
                    + warehouse.getAvailableSpace() + ", attempted inward: " + dto.getQuantity());
        }

        Supplier supplier = null;
        if (dto.getSupplierId() != null) {
            supplier = supplierRepository.findById(dto.getSupplierId())
                    .orElse(product.getSupplier());
        } else {
            supplier = product.getSupplier();
        }

        // 1. Increase product quantity
        product.setQuantity(product.getQuantity() + dto.getQuantity());
        product.setWarehouse(warehouse);
        productRepository.save(product);

        // 2. Adjust warehouse occupied & available space
        warehouse.setOccupiedSpace(warehouse.getOccupiedSpace() + dto.getQuantity());
        warehouse.calculateAvailableSpace();
        warehouseRepository.save(warehouse);

        // 3. Record Inward Transaction
        StockInward inward = new StockInward();
        inward.setProduct(product);
        inward.setSupplier(supplier);
        inward.setWarehouse(warehouse);
        inward.setQuantity(dto.getQuantity());
        inward.setReceivedDate(LocalDateTime.now());
        inward.setReceivedBy(dto.getReceivedBy() != null ? dto.getReceivedBy() : "System Logistics");
        inward.setNotes(dto.getNotes());
        inward.setStatus("CONFIRMED");

        return inwardRepository.save(inward);
    }

    /**
     * Confirms outward dispatch of goods:
     * - Checks that requested quantity does not exceed available stock
     * - Decrements product quantity
     * - Frees up warehouse space
     * - Persists outward transaction record
     */
    public StockOutward processOutwardStock(OutwardRequestDTO dto) {
        if (dto.getQuantity() == null || dto.getQuantity() <= 0) {
            throw new IllegalArgumentException("Outward quantity must be greater than zero.");
        }

        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + dto.getProductId()));

        Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + dto.getWarehouseId()));

        // Business Rule: Outward quantity cannot exceed available stock
        if (product.getQuantity() < dto.getQuantity()) {
            throw new InsufficientStockException("Insufficient stock! Available quantity: " 
                    + product.getQuantity() + ", requested outward: " + dto.getQuantity());
        }

        // 1. Decrease product quantity
        product.setQuantity(product.getQuantity() - dto.getQuantity());
        productRepository.save(product);

        // 2. Free warehouse occupied space
        int newOccupied = Math.max(0, warehouse.getOccupiedSpace() - dto.getQuantity());
        warehouse.setOccupiedSpace(newOccupied);
        warehouse.calculateAvailableSpace();
        warehouseRepository.save(warehouse);

        // 3. Record Outward Transaction
        StockOutward outward = new StockOutward();
        outward.setProduct(product);
        outward.setWarehouse(warehouse);
        outward.setQuantity(dto.getQuantity());
        outward.setDestination(dto.getDestination() != null ? dto.getDestination() : "Customer Dispatch");
        outward.setDispatchDate(LocalDateTime.now());
        outward.setDispatchedBy(dto.getDispatchedBy() != null ? dto.getDispatchedBy() : "Logistics Agent");
        outward.setNotes(dto.getNotes());
        outward.setStatus("CONFIRMED");

        return outwardRepository.save(outward);
    }
}
