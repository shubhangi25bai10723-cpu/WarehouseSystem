package com.wareflow.dto;

import java.time.LocalDateTime;

public class AlertDTO {
    private String id;
    private String type; // LOW_STOCK, OUT_OF_STOCK, OVERSTOCK, PENDING_PO
    private String severity; // CRITICAL, WARNING, INFO
    private String title;
    private String message;
    private Long referenceId;
    private LocalDateTime timestamp;

    public AlertDTO() {}

    public AlertDTO(String id, String type, String severity, String title, String message, Long referenceId) {
        this.id = id;
        this.type = type;
        this.severity = severity;
        this.title = title;
        this.message = message;
        this.referenceId = referenceId;
        this.timestamp = LocalDateTime.now();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Long getReferenceId() { return referenceId; }
    public void setReferenceId(Long referenceId) { this.referenceId = referenceId; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
