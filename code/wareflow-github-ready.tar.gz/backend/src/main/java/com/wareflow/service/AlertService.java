package com.wareflow.service;

import com.wareflow.dto.AlertDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.PurchaseOrder;
import com.wareflow.entity.Warehouse;
import com.wareflow.repository.ProductRepository;
import com.wareflow.repository.PurchaseOrderRepository;
import com.wareflow.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Intelligent Warehouse Alert Service:
 * Automatically detects low stock, out of stock, overstocked warehouses, and pending POs.
 */
@Service
public class AlertService {

    private final ProductRepository productRepository;
    private final WarehouseRepository warehouseRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;

    public AlertService(ProductRepository productRepository,
                        WarehouseRepository warehouseRepository,
                        PurchaseOrderRepository purchaseOrderRepository) {
        this.productRepository = productRepository;
        this.warehouseRepository = warehouseRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
    }

    public List<AlertDTO> generateActiveAlerts() {
        List<AlertDTO> alerts = new ArrayList<>();
        List<Product> products = productRepository.findAll();

        for (Product p : products) {
            // Out of stock alert
            if (p.getQuantity() == 0) {
                alerts.add(new AlertDTO(
                        "OOS-" + p.getProductId(),
                        "OUT_OF_STOCK",
                        "CRITICAL",
                        "Out of Stock: " + p.getProductName(),
                        "Zero units available for SKU [" + p.getSku() + "]. Immediate procurement required.",
                        p.getProductId()
                ));
            }
            // Low stock alert
            else if (p.getQuantity() <= p.getMinimumStockLevel()) {
                alerts.add(new AlertDTO(
                        "LOW-" + p.getProductId(),
                        "LOW_STOCK",
                        "WARNING",
                        "Low Stock Warning: " + p.getProductName(),
                        "Current stock (" + p.getQuantity() + ") is at or below threshold (" + p.getMinimumStockLevel() + ").",
                        p.getProductId()
                ));
            }
        }

        // Warehouse Overcapacity alerts (>85% capacity utilization)
        List<Warehouse> warehouses = warehouseRepository.findAll();
        for (Warehouse w : warehouses) {
            if (w.getCapacity() > 0) {
                double utilization = (double) w.getOccupiedSpace() / w.getCapacity();
                if (utilization >= 0.85) {
                    alerts.add(new AlertDTO(
                            "WH-OVER-" + w.getWarehouseId(),
                            "OVERSTOCK",
                            "WARNING",
                            "High Warehouse Utilization: " + w.getWarehouseName(),
                            String.format("Warehouse is at %.1f%% capacity (%d / %d slots occupied).",
                                    utilization * 100, w.getOccupiedSpace(), w.getCapacity()),
                            w.getWarehouseId()
                    ));
                }
            }
        }

        // Pending Purchase Orders alert
        List<PurchaseOrder> pendingOrders = purchaseOrderRepository.findByStatus("PENDING");
        if (!pendingOrders.isEmpty()) {
            alerts.add(new AlertDTO(
                    "PO-PENDING",
                    "PENDING_PO",
                    "INFO",
                    pendingOrders.size() + " Pending Purchase Order(s)",
                    "Awaiting manager approval and supplier confirmation for " + pendingOrders.size() + " orders.",
                    null
            ));
        }

        return alerts;
    }
}
