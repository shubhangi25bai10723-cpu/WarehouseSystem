# WareFlow – Warehouse Management System
### College Major Project Presentation & Source Code

WareFlow is a complete, enterprise-grade **Warehouse Management System (WMS)** built with a real **Java 17+ Spring Boot** backend, **MySQL** relational database with JPA/Hibernate ORM, and a modern **React.js** responsive dashboard.

---

## 1. System Architecture

```
                                 [ User Browser / Device ]
                                             │
                                             ▼
                             [ React.js + Tailwind Dashboard ]
                                             │ (HTTP JSON REST)
                                             ▼
                     [ Spring Boot Web / REST Controllers (Port 8080) ]
                                             │
                                             ▼
                             [ Service Layer / Business Logic ]
                         (Inward/Outward Rules, Capacity Checks)
                                             │
                                             ▼
                             [ Spring Data JPA Repositories ]
                                             │ (Hibernate ORM)
                                             ▼
                                [ MySQL Database: warehouse_management ]
```

---

## 2. Java Backend Package Hierarchy (`com.wareflow`)

```
com.wareflow
│
├── WareFlowApplication.java         # Spring Boot Application entry point
│
├── controller                       # REST Endpoints
│   ├── ProductController.java       # /api/products (CRUD, search, stock adjustments)
│   ├── WarehouseController.java     # /api/warehouses (CRUD, capacity metrics)
│   ├── SupplierController.java      # /api/suppliers (Vendor management)
│   ├── InwardController.java        # /api/inward (Stock receiving & allocation)
│   ├── OutwardController.java       # /api/outward (Stock dispatching & validation)
│   ├── PurchaseOrderController.java # /api/purchase-orders (Procurement lifecycle)
│   ├── DashboardController.java     # /api/dashboard/summary (KPIs & trends)
│   ├── ReportController.java        # /api/reports/* (Analytics & exports)
│   └── AuthController.java          # /api/auth/login (RBAC authentication)
│
├── service                          # Business Logic & Validation Layer
│   ├── ProductService.java          # Product lifecycle & SKU uniqueness
│   ├── WarehouseService.java        # Capacity allocation & utilization
│   ├── SupplierService.java         # Vendor contracts & status
│   ├── InventoryService.java        # Atomic stock inward/outward processing
│   ├── PurchaseOrderService.java    # PO approval workflows
│   ├── AlertService.java            # Low stock, OOS, & overstock threshold alarms
│   └── ReportService.java           # Multi-dimensional reporting
│
├── repository                       # JPA Repositories with JPQL Queries
│   ├── ProductRepository.java
│   ├── WarehouseRepository.java
│   ├── SupplierRepository.java
│   ├── InwardRepository.java
│   ├── OutwardRepository.java
│   ├── PurchaseOrderRepository.java
│   └── UserRepository.java
│
├── entity                           # JPA / Hibernate Entity Model
│   ├── Product.java
│   ├── Warehouse.java
│   ├── Supplier.java
│   ├── StockInward.java
│   ├── StockOutward.java
│   ├── PurchaseOrder.java
│   └── User.java
│
├── dto                              # Data Transfer Objects
├── exception                        # Global Exception Handling (@RestControllerAdvice)
└── config                           # Security & CORS configuration
```

---

## 3. How to Run the Project Locally

### Prerequisites
1. **Java 17 or higher** (`java -version`)
2. **Apache Maven 3.8+** (`mvn -v`)
3. **MySQL Server 8.0+** (`mysql -V`)
4. **Node.js 18+** (`node -v`)

---

### Step-by-Step Instructions

#### Step 1: Clone or Navigate to the Workspace
```bash
cd WareFlow
```

#### Step 2: Set up MySQL Database
Open your MySQL terminal or MySQL Workbench:
```sql
CREATE DATABASE warehouse_management;
```
*(Optional: Run `backend/src/main/resources/schema.sql` and `backend/src/main/resources/data.sql` manually if you have disabled JPA auto-ddl).*

#### Step 3: Configure Database Credentials
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/warehouse_management?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=YOUR_MYSQL_USERNAME   # e.g., root
spring.datasource.password=YOUR_MYSQL_PASSWORD   # e.g., root123
```

#### Step 4: Run the Spring Boot Backend
```bash
cd backend
mvn clean spring-boot:run
```
*Backend will start on `http://localhost:8080`*. Verify by opening:
`http://localhost:8080/api/dashboard/summary`

#### Step 5: Run the React Frontend
In a separate terminal window at the project root:
```bash
npm install
npm run dev
```
*Frontend will open on `http://localhost:3000` (or `http://localhost:5173`).*

---

## 4. Key Business Logic Enforced by Java Backend

1. **Atomic Inward Stock Reception**:
   - Checks warehouse remaining capacity (`availableSpace >= inwardQuantity`).
   - Increments `product.quantity`.
   - Updates `warehouse.occupiedSpace` and recalculates `availableSpace`.
   - Saves immutable audit log in `stock_inward`.

2. **Strict Outward Dispatch Validation**:
   - Checks that requested dispatch quantity does NOT exceed available stock.
   - Throws `InsufficientStockException` (HTTP 400) if user requests more than is available.
   - Decrements `product.quantity` and decreases warehouse occupied space.

3. **Intelligent Dynamic Alerts**:
   - `AlertService` dynamically checks thresholds on every invocation.
   - Generates `OUT_OF_STOCK` (0 units), `LOW_STOCK` (<= minimum threshold), and `OVERSTOCK` (>85% warehouse capacity).

4. **Role-Based Access Control**:
   - Pre-configured roles: **Warehouse Admin**, **Warehouse Manager**, and **Logistics Staff**.
