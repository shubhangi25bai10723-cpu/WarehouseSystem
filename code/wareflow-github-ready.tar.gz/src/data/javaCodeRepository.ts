export interface JavaSourceFile {
  name: string;
  path: string;
  layer: 'Controller' | 'Service' | 'Repository' | 'Entity' | 'Config' | 'Database' | 'Maven';
  description: string;
  code: string;
}

export const JAVA_PROJECT_FILES: JavaSourceFile[] = [
  {
    name: 'InventoryService.java',
    path: 'com/wareflow/service/InventoryService.java',
    layer: 'Service',
    description: 'Core inventory business logic: validates warehouse capacity for inward receiving and checks stock availability before outward dispatches.',
    code: `package com.wareflow.service;

import com.wareflow.dto.InwardRequestDTO;
import com.wareflow.dto.OutwardRequestDTO;
import com.wareflow.entity.*;
import com.wareflow.exception.*;
import com.wareflow.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
@Transactional
public class InventoryService {

    private final ProductRepository productRepository;
    private final WarehouseRepository warehouseRepository;
    private final InwardRepository inwardRepository;
    private final OutwardRepository outwardRepository;

    public InventoryService(ProductRepository productRepository,
                            WarehouseRepository warehouseRepository,
                            InwardRepository inwardRepository,
                            OutwardRepository outwardRepository) {
        this.productRepository = productRepository;
        this.warehouseRepository = warehouseRepository;
        this.inwardRepository = inwardRepository;
        this.outwardRepository = outwardRepository;
    }

    /**
     * Inward Stock Confirmation:
     * 1. Validates warehouse capacity
     * 2. Increments product quantity
     * 3. Adjusts warehouse occupied & available space
     * 4. Logs audit entry
     */
    public StockInward processInwardStock(InwardRequestDTO dto) {
        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + dto.getProductId()));
        Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + dto.getWarehouseId()));

        // Business Rule: Ensure warehouse has enough space
        if (warehouse.getAvailableSpace() < dto.getQuantity()) {
            throw new CapacityExceededException("Warehouse capacity exceeded! Available: " 
                    + warehouse.getAvailableSpace() + ", requested: " + dto.getQuantity());
        }

        // Increase product quantity & adjust warehouse space
        product.setQuantity(product.getQuantity() + dto.getQuantity());
        productRepository.save(product);

        warehouse.setOccupiedSpace(warehouse.getOccupiedSpace() + dto.getQuantity());
        warehouse.calculateAvailableSpace();
        warehouseRepository.save(warehouse);

        StockInward inward = new StockInward();
        inward.setProduct(product);
        inward.setWarehouse(warehouse);
        inward.setQuantity(dto.getQuantity());
        inward.setReceivedDate(LocalDateTime.now());
        inward.setReceivedBy(dto.getReceivedBy());
        return inwardRepository.save(inward);
    }

    /**
     * Outward Stock Dispatch:
     * 1. Validates quantity <= current available stock
     * 2. Decrements product quantity
     * 3. Frees warehouse occupied capacity
     */
    public StockOutward processOutwardStock(OutwardRequestDTO dto) {
        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + dto.getProductId()));
        Warehouse warehouse = warehouseRepository.findById(dto.getWarehouseId())
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + dto.getWarehouseId()));

        // Business Rule: Outward cannot exceed available stock
        if (product.getQuantity() < dto.getQuantity()) {
            throw new InsufficientStockException("Insufficient stock! Available: " 
                    + product.getQuantity() + ", requested: " + dto.getQuantity());
        }

        product.setQuantity(product.getQuantity() - dto.getQuantity());
        productRepository.save(product);

        warehouse.setOccupiedSpace(Math.max(0, warehouse.getOccupiedSpace() - dto.getQuantity()));
        warehouse.calculateAvailableSpace();
        warehouseRepository.save(warehouse);

        StockOutward outward = new StockOutward();
        outward.setProduct(product);
        outward.setWarehouse(warehouse);
        outward.setQuantity(dto.getQuantity());
        outward.setDestination(dto.getDestination());
        outward.setDispatchDate(LocalDateTime.now());
        outward.setDispatchedBy(dto.getDispatchedBy());
        return outwardRepository.save(outward);
    }
}`
  },
  {
    name: 'ProductController.java',
    path: 'com/wareflow/controller/ProductController.java',
    layer: 'Controller',
    description: 'Spring Boot REST Controller exposing HTTP endpoints for inventory CRUD, filtering, search, and stock level checks.',
    code: `package com.wareflow.controller;

import com.wareflow.dto.ProductDTO;
import com.wareflow.entity.Product;
import com.wareflow.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String category) {
        if (search != null && !search.isEmpty()) {
            return ResponseEntity.ok(productService.searchProducts(search));
        }
        if (category != null && !category.equalsIgnoreCase("ALL")) {
            return ResponseEntity.ok(productService.getProductsByCategory(category));
        }
        return ResponseEntity.ok(productService.getAllProducts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody ProductDTO dto) {
        return new ResponseEntity<>(productService.createProduct(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody ProductDTO dto) {
        return ResponseEntity.ok(productService.updateProduct(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }
}`
  },
  {
    name: 'Product.java',
    path: 'com/wareflow/entity/Product.java',
    layer: 'Entity',
    description: 'JPA / Hibernate Entity mapping the products table with SKU uniqueness constraint, relationships, and low-stock helpers.',
    code: `package com.wareflow.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long productId;

    @Column(name = "product_name", nullable = false, length = 150)
    private String productName;

    @Column(name = "sku", nullable = false, unique = true, length = 60)
    private String sku;

    @Column(name = "category", nullable = false, length = 80)
    private String category;

    @Column(name = "quantity", nullable = false)
    private Integer quantity = 0;

    @Column(name = "minimum_stock_level", nullable = false)
    private Integer minimumStockLevel = 10;

    @Column(name = "unit_price", nullable = false, precision = 10, scale = 2)
    private BigDecimal unitPrice;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "supplier_id")
    private Supplier supplier;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "warehouse_id")
    private Warehouse warehouse;

    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate = LocalDateTime.now();

    public boolean isLowStock() {
        return this.quantity <= this.minimumStockLevel && this.quantity > 0;
    }

    // Getters and Setters omitted for brevity
}`
  },
  {
    name: 'ProductRepository.java',
    path: 'com/wareflow/repository/ProductRepository.java',
    layer: 'Repository',
    description: 'Spring Data JPA Repository providing JPQL queries for search, stock summation, and threshold filtering.',
    code: `package com.wareflow.repository;

import com.wareflow.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    Optional<Product> findBySku(String sku);
    boolean existsBySku(String sku);
    List<Product> findByCategory(String category);

    @Query("SELECT p FROM Product p WHERE p.quantity <= p.minimumStockLevel AND p.quantity > 0")
    List<Product> findLowStockProducts();

    @Query("SELECT p FROM Product p WHERE p.quantity = 0")
    List<Product> findOutOfStockProducts();

    @Query("SELECT p FROM Product p WHERE " +
           "LOWER(p.productName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.sku) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Product> searchProducts(@Param("keyword") String keyword);

    @Query("SELECT COALESCE(SUM(p.quantity), 0) FROM Product p")
    Long sumTotalStock();
}`
  },
  {
    name: 'AlertService.java',
    path: 'com/wareflow/service/AlertService.java',
    layer: 'Service',
    description: 'Automated warehouse alert generator checking low stock, out-of-stock, and warehouse capacity thresholds.',
    code: `package com.wareflow.service;

import com.wareflow.dto.AlertDTO;
import com.wareflow.entity.Product;
import com.wareflow.entity.Warehouse;
import com.wareflow.repository.*;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class AlertService {

    private final ProductRepository productRepository;
    private final WarehouseRepository warehouseRepository;

    public AlertService(ProductRepository productRepository, WarehouseRepository warehouseRepository) {
        this.productRepository = productRepository;
        this.warehouseRepository = warehouseRepository;
    }

    public List<AlertDTO> generateActiveAlerts() {
        List<AlertDTO> alerts = new ArrayList<>();
        List<Product> products = productRepository.findAll();

        for (Product p : products) {
            if (p.getQuantity() == 0) {
                alerts.add(new AlertDTO("OOS-" + p.getProductId(), "OUT_OF_STOCK", "CRITICAL",
                        "Out of Stock: " + p.getProductName(), "Zero inventory available for " + p.getSku(), p.getProductId()));
            } else if (p.getQuantity() <= p.getMinimumStockLevel()) {
                alerts.add(new AlertDTO("LOW-" + p.getProductId(), "LOW_STOCK", "WARNING",
                        "Low Stock: " + p.getProductName(), "Quantity (" + p.getQuantity() + ") is below min threshold (" + p.getMinimumStockLevel() + ")", p.getProductId()));
            }
        }
        return alerts;
    }
}`
  },
  {
    name: 'schema.sql',
    path: 'src/main/resources/schema.sql',
    layer: 'Database',
    description: 'Relational MySQL DDL creating 7 tables with primary keys, auto_increment, foreign keys, and performance indexes.',
    code: `CREATE DATABASE IF NOT EXISTS warehouse_management;
USE warehouse_management;

CREATE TABLE warehouses (
    warehouse_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    warehouse_name VARCHAR(100) NOT NULL,
    location VARCHAR(200) NOT NULL,
    capacity INT NOT NULL,
    occupied_space INT NOT NULL DEFAULT 0,
    available_space INT NOT NULL,
    manager VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE products (
    product_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(150) NOT NULL,
    sku VARCHAR(60) NOT NULL UNIQUE,
    category VARCHAR(80) NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    minimum_stock_level INT NOT NULL DEFAULT 10,
    unit_price DECIMAL(10, 2) NOT NULL,
    supplier_id BIGINT,
    warehouse_id BIGINT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

CREATE TABLE stock_inward (
    inward_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id BIGINT NOT NULL,
    supplier_id BIGINT,
    warehouse_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    received_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    received_by VARCHAR(100) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);`
  },
  {
    name: 'pom.xml',
    path: 'pom.xml',
    layer: 'Maven',
    description: 'Maven Project Object Model configuring Spring Boot 3, Spring Data JPA, Hibernate, MySQL Driver, and Spring Security.',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
	<modelVersion>4.0.0</modelVersion>
	<parent>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>3.2.3</version>
	</parent>
	<groupId>com.wareflow</groupId>
	<artifactId>wareflow-backend</artifactId>
	<version>1.0.0</version>

	<properties>
		<java.version>17</java.version>
	</properties>

	<dependencies>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-jpa</artifactId>
		</dependency>
		<dependency>
			<groupId>com.mysql</groupId>
			<artifactId>mysql-connector-j</artifactId>
			<scope>runtime</scope>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-security</artifactId>
		</dependency>
	</dependencies>
</project>`
  }
];
