import type { IncomingMessage, ServerResponse } from 'http';
import type { Warehouse, Supplier, Product, StockInward, StockOutward, PurchaseOrder, User, DashboardSummary, AlertItem } from '../types/warehouse';

// In-Memory Relational Database State populated from MySQL data.sql
let warehouses: Warehouse[] = [
  { warehouseId: 1, warehouseName: 'North Logistics Hub', location: 'Building 4A, Industrial Zone North, Chicago, IL', capacity: 15000, occupiedSpace: 10250, availableSpace: 4750, manager: 'Robert Vance', status: 'ACTIVE' },
  { warehouseId: 2, warehouseName: 'Metro Central Depot', location: 'Bay 12, Terminal Ave, Dallas, TX', capacity: 20000, occupiedSpace: 14800, availableSpace: 5200, manager: 'Elena Rostova', status: 'ACTIVE' },
  { warehouseId: 3, warehouseName: 'Pacific Coastal Terminal', location: 'Pier 9, Harbor Logistics Center, Seattle, WA', capacity: 12000, occupiedSpace: 7900, availableSpace: 4100, manager: 'David Chen', status: 'ACTIVE' },
  { warehouseId: 4, warehouseName: 'East Coast Distribution Hub', location: 'Zone 3, Commerce Way, Newark, NJ', capacity: 25000, occupiedSpace: 19400, availableSpace: 5600, manager: 'Sarah Jenkins', status: 'ACTIVE' },
  { warehouseId: 5, warehouseName: 'Southwest Cargo Center', location: 'Bldg 8, Freight Blvd, Phoenix, AZ', capacity: 10000, occupiedSpace: 3200, availableSpace: 6800, manager: 'Marcus Brody', status: 'MAINTENANCE' }
];

let suppliers: Supplier[] = [
  { supplierId: 1, supplierName: 'Industrial Hydraulics Corp', company: 'IHC Global Ltd', phone: '+1-555-019-2831', email: 'orders@ihcglobal.com', address: '742 Evergreen Blvd, Detroit, MI', productsSupplied: 'Hydraulic pumps, valves, high-pressure fittings', status: 'ACTIVE' },
  { supplierId: 2, supplierName: 'Apex Fasteners & Hardware', company: 'Apex Manufacturing Inc', phone: '+1-555-014-9820', email: 'sales@apexfasteners.com', address: '128 Assembly Row, Cleveland, OH', productsSupplied: 'Grade 8 bolts, structural rivets, anchors', status: 'ACTIVE' },
  { supplierId: 3, supplierName: 'Quantum Sensor Systems', company: 'Quantum Tech LLC', phone: '+1-555-017-3341', email: 'supply@quantumsensors.io', address: '550 Silicon Way, San Jose, CA', productsSupplied: 'IoT telemetry nodes, photoelectric sensors', status: 'ACTIVE' },
  { supplierId: 4, supplierName: 'Titan Heavy Machinery Parts', company: 'Titan Industrial', phone: '+1-555-012-7788', email: 'distribution@titanheavy.com', address: '900 Ironworks Rd, Pittsburgh, PA', productsSupplied: 'Drive sprockets, heavy bearings, conveyor rollers', status: 'ACTIVE' },
  { supplierId: 5, supplierName: 'EcoPack Industrial Packaging', company: 'EcoPack Solutions', phone: '+1-555-018-4455', email: 'service@ecopack.net', address: '312 Green St, Minneapolis, MN', productsSupplied: 'Heavy-duty corrugated boxes, pallet wrap', status: 'ACTIVE' },
  { supplierId: 6, supplierName: 'Vanguard Electrical Supplies', company: 'Vanguard Power Systems', phone: '+1-555-016-6622', email: 'b2b@vanguardpower.com', address: '405 Volt Dr, Atlanta, GA', productsSupplied: 'Circuit breakers, 3-phase relays, cables', status: 'ACTIVE' }
];

let products: Product[] = [
  { productId: 1, productName: 'Heavy Duty Hydraulic Pump 350-Bar', sku: 'PUMP-HYD-350', category: 'Hydraulics', description: 'Cast iron dual-displacement hydraulic pump for industrial machinery', quantity: 42, minimumStockLevel: 15, unitPrice: 680.00, supplierId: 1, warehouseId: 1, createdDate: '2026-03-01T10:00:00Z' },
  { productId: 2, productName: 'Rotary Conveyor Roller 60mm', sku: 'ROLL-CONV-060', category: 'Machinery Parts', description: 'Precision ball-bearing galvanized steel conveyor roller', quantity: 185, minimumStockLevel: 40, unitPrice: 34.50, supplierId: 4, warehouseId: 1, createdDate: '2026-03-02T11:30:00Z' },
  { productId: 3, productName: 'Grade 8 Zinc Hex Cap Screws (Box of 500)', sku: 'FAST-HEX-G8', category: 'Fasteners', description: 'High-tensile zinc plated 1/2-13 structural hex bolts', quantity: 12, minimumStockLevel: 25, unitPrice: 89.00, supplierId: 2, warehouseId: 2, createdDate: '2026-03-03T09:15:00Z' },
  { productId: 4, productName: 'IoT Vibration & Temp Sensor Node', sku: 'SENS-IOT-VT', category: 'Electronics', description: 'Wireless telemetry sensor node with IP67 enclosure for predictive maintenance', quantity: 68, minimumStockLevel: 20, unitPrice: 145.00, supplierId: 3, warehouseId: 2, createdDate: '2026-03-04T14:20:00Z' },
  { productId: 5, productName: 'Industrial 3-Phase Circuit Breaker 63A', sku: 'ELEC-CB-63A', category: 'Electrical', description: 'DIN rail mounted thermal magnetic trip circuit breaker 400V', quantity: 4, minimumStockLevel: 15, unitPrice: 112.50, supplierId: 6, warehouseId: 2, createdDate: '2026-03-05T08:45:00Z' },
  { productId: 6, productName: 'Heavy Reinforced Pallet Stretch Film (6 Rolls)', sku: 'PACK-STR-01', category: 'Packaging', description: '80 gauge puncture-resistant industrial cast stretch wrap', quantity: 240, minimumStockLevel: 50, unitPrice: 78.00, supplierId: 5, warehouseId: 3, createdDate: '2026-03-06T13:10:00Z' },
  { productId: 7, productName: 'Pneumatic Directional Control Valve', sku: 'VALV-PNEU-52', category: 'Hydraulics', description: '5/2 way solenoid-actuated pneumatic valve 24V DC', quantity: 0, minimumStockLevel: 10, unitPrice: 95.00, supplierId: 1, warehouseId: 1, createdDate: '2026-03-07T16:00:00Z' },
  { productId: 8, productName: 'Double Row Spherical Roller Bearing', sku: 'BEAR-SPH-222', category: 'Machinery Parts', description: 'Self-aligning heavy load bearing with cylindrical bore', quantity: 28, minimumStockLevel: 12, unitPrice: 165.00, supplierId: 4, warehouseId: 3, createdDate: '2026-03-08T12:00:00Z' },
  { productId: 9, productName: 'Optical Photoelectric Retroreflective Sensor', sku: 'SENS-OPT-RR', category: 'Electronics', description: 'Compact optical sensor with 4m detection range and PNP output', quantity: 84, minimumStockLevel: 18, unitPrice: 52.00, supplierId: 3, warehouseId: 4, createdDate: '2026-03-09T15:30:00Z' },
  { productId: 10, productName: 'Heavy Duty Polyurethane Caster Wheel 8"', sku: 'WHEEL-PU-08', category: 'Hardware', description: 'Swivel plate industrial caster with brake, 1200 lb rating', quantity: 96, minimumStockLevel: 30, unitPrice: 44.00, supplierId: 2, warehouseId: 4, createdDate: '2026-03-10T11:00:00Z' }
];

let stockInward: StockInward[] = [
  { inwardId: 1, productId: 1, supplierId: 1, warehouseId: 1, quantity: 20, receivedDate: '2026-09-10T09:30:00Z', receivedBy: 'John Miller (Supervisor)', notes: 'Passed quality inspection on Dock 3', status: 'CONFIRMED' },
  { inwardId: 2, productId: 2, supplierId: 4, warehouseId: 1, quantity: 100, receivedDate: '2026-09-11T11:15:00Z', receivedBy: 'Elena Rostova', notes: 'Full pallet verified without damage', status: 'CONFIRMED' },
  { inwardId: 3, productId: 4, supplierId: 3, warehouseId: 2, quantity: 50, receivedDate: '2026-09-12T14:45:00Z', receivedBy: 'David Chen', notes: 'Firmware v2.4 pre-flashed', status: 'CONFIRMED' },
  { inwardId: 4, productId: 6, supplierId: 5, warehouseId: 3, quantity: 150, receivedDate: '2026-09-13T10:20:00Z', receivedBy: 'Marcus Brody', notes: 'Restocked packaging supplies for Q3', status: 'CONFIRMED' },
  { inwardId: 5, productId: 9, supplierId: 3, warehouseId: 4, quantity: 60, receivedDate: '2026-09-14T16:00:00Z', receivedBy: 'Sarah Jenkins', notes: 'Received from FedEx Freight express', status: 'CONFIRMED' },
  { inwardId: 6, productId: 10, supplierId: 2, warehouseId: 4, quantity: 50, receivedDate: new Date().toISOString(), receivedBy: 'Sarah Jenkins', notes: 'Initial batch for assembly line', status: 'CONFIRMED' }
];

let stockOutward: StockOutward[] = [
  { outwardId: 1, productId: 1, warehouseId: 1, quantity: 5, destination: 'Production Line A, Plant 2, Detroit', dispatchDate: '2026-09-11T14:00:00Z', dispatchedBy: 'Marcus Brody', notes: 'Scheduled replacement for stamping press', status: 'CONFIRMED' },
  { outwardId: 2, productId: 2, warehouseId: 1, quantity: 40, destination: 'Midwest Logistics Hub, Indianapolis', dispatchDate: '2026-09-12T10:30:00Z', dispatchedBy: 'Robert Vance', notes: 'Conveyor line expansion project', status: 'CONFIRMED' },
  { outwardId: 3, productId: 6, warehouseId: 3, quantity: 30, destination: 'Outbound Shipping Dock, Seattle', dispatchDate: '2026-09-13T15:10:00Z', dispatchedBy: 'David Chen', notes: 'Daily shipping wrap replenishment', status: 'CONFIRMED' },
  { outwardId: 4, productId: 4, warehouseId: 2, quantity: 12, destination: 'Automated Sorting Center, Austin', dispatchDate: '2026-09-14T11:40:00Z', dispatchedBy: 'Elena Rostova', notes: 'Maintenance work order #WO-9941', status: 'CONFIRMED' },
  { outwardId: 5, productId: 10, warehouseId: 4, quantity: 14, destination: 'Assembly Floor, Warehouse 4', dispatchDate: new Date().toISOString(), dispatchedBy: 'Sarah Jenkins', notes: 'Mobile rack refitting work order', status: 'CONFIRMED' }
];

let purchaseOrders: PurchaseOrder[] = [
  { orderId: 1, supplierId: 1, productId: 7, quantity: 25, orderDate: '2026-09-09T08:00:00Z', expectedDeliveryDate: '2026-09-18', totalAmount: 2375.00, status: 'APPROVED' },
  { orderId: 2, supplierId: 6, productId: 5, quantity: 30, orderDate: '2026-09-12T10:15:00Z', expectedDeliveryDate: '2026-09-20', totalAmount: 3375.00, status: 'PENDING' },
  { orderId: 3, supplierId: 2, productId: 3, quantity: 50, orderDate: '2026-09-14T13:45:00Z', expectedDeliveryDate: '2026-09-21', totalAmount: 4450.00, status: 'PENDING' },
  { orderId: 4, supplierId: 4, productId: 8, quantity: 40, orderDate: '2026-09-05T09:00:00Z', expectedDeliveryDate: '2026-09-14', totalAmount: 6600.00, status: 'RECEIVED' },
  { orderId: 5, supplierId: 3, productId: 4, quantity: 100, orderDate: '2026-09-01T15:30:00Z', expectedDeliveryDate: '2026-09-08', totalAmount: 14500.00, status: 'RECEIVED' }
];

let users: User[] = [
  { userId: 1, username: 'admin', fullName: 'Dr. Alexander Vance', email: 'admin@wareflow.io', role: 'ADMIN', status: 'ACTIVE' },
  { userId: 2, username: 'manager', fullName: 'Elena Rostova', email: 'elena.rostova@wareflow.io', role: 'MANAGER', status: 'ACTIVE' },
  { userId: 3, username: 'staff', fullName: 'Marcus Brody', email: 'marcus.brody@wareflow.io', role: 'STAFF', status: 'ACTIVE' }
];

function enrichProduct(p: Product): Product {
  const supplier = suppliers.find(s => s.supplierId === p.supplierId);
  const warehouse = warehouses.find(w => w.warehouseId === p.warehouseId);
  return {
    ...p,
    supplierName: supplier ? supplier.supplierName : 'Unassigned',
    supplier,
    warehouseName: warehouse ? warehouse.warehouseName : 'Unassigned',
    warehouse
  };
}

function enrichInward(i: StockInward): StockInward {
  const product = products.find(p => p.productId === i.productId);
  const supplier = suppliers.find(s => s.supplierId === i.supplierId);
  const warehouse = warehouses.find(w => w.warehouseId === i.warehouseId);
  return {
    ...i,
    productName: product ? product.productName : `Product #${i.productId}`,
    product: product ? enrichProduct(product) : undefined,
    supplierName: supplier ? supplier.supplierName : 'Standard Supplier',
    supplier,
    warehouseName: warehouse ? warehouse.warehouseName : `Warehouse #${i.warehouseId}`,
    warehouse
  };
}

function enrichOutward(o: StockOutward): StockOutward {
  const product = products.find(p => p.productId === o.productId);
  const warehouse = warehouses.find(w => w.warehouseId === o.warehouseId);
  return {
    ...o,
    productName: product ? product.productName : `Product #${o.productId}`,
    product: product ? enrichProduct(product) : undefined,
    warehouseName: warehouse ? warehouse.warehouseName : `Warehouse #${o.warehouseId}`,
    warehouse
  };
}

function enrichPO(po: PurchaseOrder): PurchaseOrder {
  const product = products.find(p => p.productId === po.productId);
  const supplier = suppliers.find(s => s.supplierId === po.supplierId);
  return {
    ...po,
    productName: product ? product.productName : `Product #${po.productId}`,
    product: product ? enrichProduct(product) : undefined,
    supplierName: supplier ? supplier.supplierName : `Supplier #${po.supplierId}`,
    supplier
  };
}

function computeAlerts(): AlertItem[] {
  const alerts: AlertItem[] = [];

  // 1. Out of stock alerts
  for (const p of products) {
    if (p.quantity === 0) {
      alerts.push({
        id: `OOS-${p.productId}`,
        type: 'OUT_OF_STOCK',
        severity: 'CRITICAL',
        title: `Out of Stock: ${p.productName}`,
        message: `Zero units remaining for SKU [${p.sku}]. Replenishment required immediately.`,
        referenceId: p.productId,
        timestamp: new Date().toISOString()
      });
    } else if (p.quantity <= p.minimumStockLevel) {
      alerts.push({
        id: `LOW-${p.productId}`,
        type: 'LOW_STOCK',
        severity: 'WARNING',
        title: `Low Stock: ${p.productName}`,
        message: `Current stock (${p.quantity}) is at or below minimum threshold (${p.minimumStockLevel}).`,
        referenceId: p.productId,
        timestamp: new Date().toISOString()
      });
    }
  }

  // 2. Warehouse overstock alerts
  for (const w of warehouses) {
    if (w.capacity > 0) {
      const util = w.occupiedSpace / w.capacity;
      if (util >= 0.85) {
        alerts.push({
          id: `WH-OVER-${w.warehouseId}`,
          type: 'OVERSTOCK',
          severity: 'WARNING',
          title: `Capacity Warning: ${w.warehouseName}`,
          message: `Warehouse is at ${(util * 100).toFixed(1)}% capacity (${w.occupiedSpace} / ${w.capacity} units).`,
          referenceId: w.warehouseId,
          timestamp: new Date().toISOString()
        });
      }
    }
  }

  // 3. Pending Purchase orders
  const pending = purchaseOrders.filter(po => po.status === 'PENDING');
  if (pending.length > 0) {
    alerts.push({
      id: 'PO-PENDING-ALL',
      type: 'PENDING_PO',
      severity: 'INFO',
      title: `${pending.length} Pending Purchase Order(s)`,
      message: `${pending.length} orders are awaiting administrative review and approval.`,
      timestamp: new Date().toISOString()
    });
  }

  return alerts;
}

function computeDashboardSummary(): DashboardSummary {
  const totalStock = products.reduce((acc, p) => acc + p.quantity, 0);
  const lowStockItems = products.filter(p => p.quantity > 0 && p.quantity <= p.minimumStockLevel).length;
  const outOfStockItems = products.filter(p => p.quantity === 0).length;
  const pendingOrders = purchaseOrders.filter(po => po.status === 'PENDING').length;

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayInwardStock = stockInward
    .filter(i => (i.receivedDate || '').startsWith(todayStr))
    .reduce((acc, i) => acc + i.quantity, 0);

  const todayOutwardStock = stockOutward
    .filter(o => (o.dispatchDate || '').startsWith(todayStr))
    .reduce((acc, o) => acc + o.quantity, 0);

  // Category counts
  const catMap = new Map<string, number>();
  for (const p of products) {
    catMap.set(p.category, (catMap.get(p.category) || 0) + 1);
  }
  const categoryDistribution = Array.from(catMap.entries()).map(([category, count]) => ({ category, count }));

  // Combined recent movements
  const inMoves = stockInward.map(i => {
    const p = products.find(prod => prod.productId === i.productId);
    const w = warehouses.find(wh => wh.warehouseId === i.warehouseId);
    const s = suppliers.find(sup => sup.supplierId === i.supplierId);
    return {
      id: `IN-${i.inwardId}`,
      type: 'INWARD' as const,
      productName: p ? p.productName : `Product #${i.productId}`,
      quantity: i.quantity,
      warehouse: w ? w.warehouseName : `Warehouse #${i.warehouseId}`,
      party: s ? s.supplierName : 'External Supplier',
      timestamp: i.receivedDate
    };
  });

  const outMoves = stockOutward.map(o => {
    const p = products.find(prod => prod.productId === o.productId);
    const w = warehouses.find(wh => wh.warehouseId === o.warehouseId);
    return {
      id: `OUT-${o.outwardId}`,
      type: 'OUTWARD' as const,
      productName: p ? p.productName : `Product #${o.productId}`,
      quantity: o.quantity,
      warehouse: w ? w.warehouseName : `Warehouse #${o.warehouseId}`,
      party: o.destination,
      timestamp: o.dispatchDate
    };
  });

  const recentStockMovements = [...inMoves, ...outMoves]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 10);

  return {
    totalProducts: products.length,
    totalStock,
    lowStockItems,
    outOfStockItems,
    totalSuppliers: suppliers.length,
    pendingOrders,
    todayInwardStock,
    todayOutwardStock,
    categoryDistribution,
    recentStockMovements,
    activeAlerts: computeAlerts()
  };
}

// Request Body Parser helper
async function parseJsonBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });
    req.on('end', () => {
      if (!body.trim()) {
        return resolve({});
      }
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res: ServerResponse, statusCode: number, data: any) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function sendError(res: ServerResponse, statusCode: number, error: string, message: string) {
  sendJson(res, statusCode, {
    status: statusCode,
    error,
    message,
    timestamp: new Date().toISOString()
  });
}

/**
 * Main API request router matching Java Spring Boot REST controllers
 */
export async function handleApiRequest(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const urlObj = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = urlObj.pathname;
  const method = req.method?.toUpperCase() || 'GET';

  if (!pathname.startsWith('/api')) {
    return false;
  }

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return true;
  }

  try {
    // -------------------------------------------------------------
    // 1. Dashboard API: /api/dashboard/summary
    // -------------------------------------------------------------
    if (pathname === '/api/dashboard/summary' && method === 'GET') {
      const summary = computeDashboardSummary();
      sendJson(res, 200, summary);
      return true;
    }

    // -------------------------------------------------------------
    // 2. Alerts API: /api/alerts
    // -------------------------------------------------------------
    if (pathname === '/api/alerts' && method === 'GET') {
      const alerts = computeAlerts();
      sendJson(res, 200, alerts);
      return true;
    }

    // -------------------------------------------------------------
    // 3. Products API: /api/products
    // -------------------------------------------------------------
    if (pathname === '/api/products' && method === 'GET') {
      const search = urlObj.searchParams.get('search')?.toLowerCase();
      const category = urlObj.searchParams.get('category');

      let list = products.map(enrichProduct);

      if (search) {
        list = list.filter(p =>
          p.productName.toLowerCase().includes(search) ||
          p.sku.toLowerCase().includes(search) ||
          p.category.toLowerCase().includes(search)
        );
      }

      if (category && category !== 'ALL') {
        list = list.filter(p => p.category.toLowerCase() === category.toLowerCase());
      }

      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/products/low-stock' && method === 'GET') {
      const list = products.filter(p => p.quantity > 0 && p.quantity <= p.minimumStockLevel).map(enrichProduct);
      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/products/out-of-stock' && method === 'GET') {
      const list = products.filter(p => p.quantity === 0).map(enrichProduct);
      sendJson(res, 200, list);
      return true;
    }

    const productMatch = pathname.match(/^\/api\/products\/(\d+)$/);
    if (productMatch) {
      const id = parseInt(productMatch[1], 10);
      const index = products.findIndex(p => p.productId === id);

      if (index === -1) {
        sendError(res, 404, 'Resource Not Found', `Product not found with ID: ${id}`);
        return true;
      }

      if (method === 'GET') {
        sendJson(res, 200, enrichProduct(products[index]));
        return true;
      }

      if (method === 'PUT') {
        const body = await parseJsonBody(req);
        // Validate SKU uniqueness
        if (body.sku && body.sku !== products[index].sku) {
          const duplicate = products.find(p => p.sku === body.sku && p.productId !== id);
          if (duplicate) {
            sendError(res, 400, 'Duplicate SKU', `Product SKU already exists: ${body.sku}`);
            return true;
          }
        }

        products[index] = {
          ...products[index],
          ...body,
          productId: id,
          updatedDate: new Date().toISOString()
        };
        sendJson(res, 200, enrichProduct(products[index]));
        return true;
      }

      if (method === 'DELETE') {
        products.splice(index, 1);
        sendJson(res, 200, { success: true, message: `Product #${id} deleted successfully` });
        return true;
      }
    }

    // Quick stock adjustment: PATCH /api/products/:id/stock?delta=N
    const stockAdjustMatch = pathname.match(/^\/api\/products\/(\d+)\/stock$/);
    if (stockAdjustMatch && method === 'PATCH') {
      const id = parseInt(stockAdjustMatch[1], 10);
      const delta = parseInt(urlObj.searchParams.get('delta') || '0', 10);
      const product = products.find(p => p.productId === id);
      if (!product) {
        sendError(res, 404, 'Resource Not Found', `Product not found with ID: ${id}`);
        return true;
      }
      const newQty = product.quantity + delta;
      if (newQty < 0) {
        sendError(res, 400, 'Invalid Stock Adjustment', `Stock quantity cannot be negative. Current: ${product.quantity}`);
        return true;
      }
      product.quantity = newQty;
      product.updatedDate = new Date().toISOString();
      sendJson(res, 200, enrichProduct(product));
      return true;
    }

    if (pathname === '/api/products' && method === 'POST') {
      const body = await parseJsonBody(req);
      if (!body.productName || !body.sku || !body.category) {
        sendError(res, 400, 'Validation Error', 'Product Name, SKU, and Category are required');
        return true;
      }
      if (products.some(p => p.sku === body.sku)) {
        sendError(res, 400, 'Duplicate SKU', `Product SKU already exists: ${body.sku}`);
        return true;
      }

      const newId = products.length > 0 ? Math.max(...products.map(p => p.productId)) + 1 : 1;
      const newProduct: Product = {
        productId: newId,
        productName: body.productName,
        sku: body.sku,
        category: body.category,
        description: body.description || '',
        quantity: Number(body.quantity) || 0,
        minimumStockLevel: Number(body.minimumStockLevel) || 10,
        unitPrice: Number(body.unitPrice) || 0,
        supplierId: body.supplierId ? Number(body.supplierId) : undefined,
        warehouseId: body.warehouseId ? Number(body.warehouseId) : undefined,
        createdDate: new Date().toISOString()
      };
      products.push(newProduct);
      sendJson(res, 201, enrichProduct(newProduct));
      return true;
    }

    // -------------------------------------------------------------
    // 4. Warehouses API: /api/warehouses
    // -------------------------------------------------------------
    if (pathname === '/api/warehouses' && method === 'GET') {
      sendJson(res, 200, warehouses);
      return true;
    }

    if (pathname === '/api/warehouses' && method === 'POST') {
      const body = await parseJsonBody(req);
      const newId = warehouses.length > 0 ? Math.max(...warehouses.map(w => w.warehouseId)) + 1 : 1;
      const cap = Number(body.capacity) || 10000;
      const occ = Number(body.occupiedSpace) || 0;
      const newWarehouse: Warehouse = {
        warehouseId: newId,
        warehouseName: body.warehouseName,
        location: body.location,
        capacity: cap,
        occupiedSpace: occ,
        availableSpace: Math.max(0, cap - occ),
        manager: body.manager || 'Unassigned',
        status: body.status || 'ACTIVE',
        createdAt: new Date().toISOString()
      };
      warehouses.push(newWarehouse);
      sendJson(res, 201, newWarehouse);
      return true;
    }

    const whMatch = pathname.match(/^\/api\/warehouses\/(\d+)$/);
    if (whMatch) {
      const id = parseInt(whMatch[1], 10);
      const index = warehouses.findIndex(w => w.warehouseId === id);
      if (index === -1) {
        sendError(res, 404, 'Resource Not Found', `Warehouse not found with ID: ${id}`);
        return true;
      }
      if (method === 'GET') {
        sendJson(res, 200, warehouses[index]);
        return true;
      }
      if (method === 'PUT') {
        const body = await parseJsonBody(req);
        const cap = Number(body.capacity) || warehouses[index].capacity;
        const occ = body.occupiedSpace !== undefined ? Number(body.occupiedSpace) : warehouses[index].occupiedSpace;
        warehouses[index] = {
          ...warehouses[index],
          ...body,
          warehouseId: id,
          capacity: cap,
          occupiedSpace: occ,
          availableSpace: Math.max(0, cap - occ)
        };
        sendJson(res, 200, warehouses[index]);
        return true;
      }
      if (method === 'DELETE') {
        warehouses.splice(index, 1);
        sendJson(res, 200, { success: true, message: `Warehouse #${id} deleted` });
        return true;
      }
    }

    // -------------------------------------------------------------
    // 5. Suppliers API: /api/suppliers
    // -------------------------------------------------------------
    if (pathname === '/api/suppliers' && method === 'GET') {
      sendJson(res, 200, suppliers);
      return true;
    }

    if (pathname === '/api/suppliers' && method === 'POST') {
      const body = await parseJsonBody(req);
      const newId = suppliers.length > 0 ? Math.max(...suppliers.map(s => s.supplierId)) + 1 : 1;
      const newSupplier: Supplier = {
        supplierId: newId,
        supplierName: body.supplierName,
        company: body.company || body.supplierName,
        phone: body.phone,
        email: body.email,
        address: body.address,
        productsSupplied: body.productsSupplied || '',
        status: body.status || 'ACTIVE',
        createdAt: new Date().toISOString()
      };
      suppliers.push(newSupplier);
      sendJson(res, 201, newSupplier);
      return true;
    }

    const supMatch = pathname.match(/^\/api\/suppliers\/(\d+)$/);
    if (supMatch) {
      const id = parseInt(supMatch[1], 10);
      const index = suppliers.findIndex(s => s.supplierId === id);
      if (index === -1) {
        sendError(res, 404, 'Resource Not Found', `Supplier not found with ID: ${id}`);
        return true;
      }
      if (method === 'GET') {
        sendJson(res, 200, suppliers[index]);
        return true;
      }
      if (method === 'PUT') {
        const body = await parseJsonBody(req);
        suppliers[index] = { ...suppliers[index], ...body, supplierId: id };
        sendJson(res, 200, suppliers[index]);
        return true;
      }
      if (method === 'DELETE') {
        suppliers.splice(index, 1);
        sendJson(res, 200, { success: true, message: `Supplier #${id} deleted` });
        return true;
      }
    }

    // -------------------------------------------------------------
    // 6. Inward Stock API: /api/inward (Java InventoryService Business Logic)
    // -------------------------------------------------------------
    if (pathname === '/api/inward' && method === 'GET') {
      const list = stockInward.map(enrichInward).reverse();
      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/inward/recent' && method === 'GET') {
      const list = stockInward.map(enrichInward).reverse().slice(0, 8);
      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/inward' && method === 'POST') {
      const body = await parseJsonBody(req);
      const productId = Number(body.productId);
      const warehouseId = Number(body.warehouseId);
      const quantity = Number(body.quantity);

      if (!productId || !warehouseId || !quantity || quantity <= 0) {
        sendError(res, 400, 'Invalid Request', 'Product ID, Warehouse ID, and positive quantity are required');
        return true;
      }

      const product = products.find(p => p.productId === productId);
      if (!product) {
        sendError(res, 404, 'Resource Not Found', `Product not found with ID: ${productId}`);
        return true;
      }

      const warehouse = warehouses.find(w => w.warehouseId === warehouseId);
      if (!warehouse) {
        sendError(res, 404, 'Resource Not Found', `Warehouse not found with ID: ${warehouseId}`);
        return true;
      }

      // CRITICAL BUSINESS RULE: Check Warehouse Capacity
      if (warehouse.availableSpace < quantity) {
        sendError(res, 400, 'Capacity Exceeded', `Warehouse capacity exceeded! Available space: ${warehouse.availableSpace}, attempted inward: ${quantity}`);
        return true;
      }

      // 1. Increment product inventory
      product.quantity += quantity;
      product.warehouseId = warehouseId;
      product.updatedDate = new Date().toISOString();

      // 2. Adjust warehouse space
      warehouse.occupiedSpace += quantity;
      warehouse.availableSpace = Math.max(0, warehouse.capacity - warehouse.occupiedSpace);

      // 3. Record Inward entry
      const newInwardId = stockInward.length > 0 ? Math.max(...stockInward.map(i => i.inwardId)) + 1 : 1;
      const newInward: StockInward = {
        inwardId: newInwardId,
        productId,
        supplierId: body.supplierId ? Number(body.supplierId) : product.supplierId,
        warehouseId,
        quantity,
        receivedDate: new Date().toISOString(),
        receivedBy: body.receivedBy || 'Logistics Inbound Desk',
        notes: body.notes || 'Inward stock receipt processed',
        status: 'CONFIRMED'
      };
      stockInward.push(newInward);

      sendJson(res, 201, enrichInward(newInward));
      return true;
    }

    // -------------------------------------------------------------
    // 7. Outward Stock API: /api/outward (Java InventoryService Business Logic)
    // -------------------------------------------------------------
    if (pathname === '/api/outward' && method === 'GET') {
      const list = stockOutward.map(enrichOutward).reverse();
      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/outward/recent' && method === 'GET') {
      const list = stockOutward.map(enrichOutward).reverse().slice(0, 8);
      sendJson(res, 200, list);
      return true;
    }

    if (pathname === '/api/outward' && method === 'POST') {
      const body = await parseJsonBody(req);
      const productId = Number(body.productId);
      const warehouseId = Number(body.warehouseId);
      const quantity = Number(body.quantity);

      if (!productId || !warehouseId || !quantity || quantity <= 0) {
        sendError(res, 400, 'Invalid Request', 'Product ID, Warehouse ID, and positive quantity are required');
        return true;
      }

      const product = products.find(p => p.productId === productId);
      if (!product) {
        sendError(res, 404, 'Resource Not Found', `Product not found with ID: ${productId}`);
        return true;
      }

      const warehouse = warehouses.find(w => w.warehouseId === warehouseId);
      if (!warehouse) {
        sendError(res, 404, 'Resource Not Found', `Warehouse not found with ID: ${warehouseId}`);
        return true;
      }

      // CRITICAL BUSINESS RULE: Outward cannot exceed available inventory
      if (product.quantity < quantity) {
        sendError(res, 400, 'Insufficient Stock', `Insufficient stock! Available quantity: ${product.quantity}, requested outward: ${quantity}`);
        return true;
      }

      // 1. Decrement product inventory
      product.quantity -= quantity;
      product.updatedDate = new Date().toISOString();

      // 2. Free warehouse capacity
      warehouse.occupiedSpace = Math.max(0, warehouse.occupiedSpace - quantity);
      warehouse.availableSpace = Math.max(0, warehouse.capacity - warehouse.occupiedSpace);

      // 3. Record Outward entry
      const newOutwardId = stockOutward.length > 0 ? Math.max(...stockOutward.map(o => o.outwardId)) + 1 : 1;
      const newOutward: StockOutward = {
        outwardId: newOutwardId,
        productId,
        warehouseId,
        quantity,
        destination: body.destination || 'Customer Dispatch Bay',
        dispatchDate: new Date().toISOString(),
        dispatchedBy: body.dispatchedBy || 'Logistics Outbound Officer',
        notes: body.notes || 'Outward dispatch confirmed',
        status: 'CONFIRMED'
      };
      stockOutward.push(newOutward);

      sendJson(res, 201, enrichOutward(newOutward));
      return true;
    }

    // -------------------------------------------------------------
    // 8. Purchase Orders API: /api/purchase-orders
    // -------------------------------------------------------------
    if (pathname === '/api/purchase-orders' && method === 'GET') {
      const status = urlObj.searchParams.get('status');
      let list = purchaseOrders.map(enrichPO);
      if (status && status !== 'ALL') {
        list = list.filter(po => po.status === status.toUpperCase());
      }
      sendJson(res, 200, list.reverse());
      return true;
    }

    if (pathname === '/api/purchase-orders' && method === 'POST') {
      const body = await parseJsonBody(req);
      const supplierId = Number(body.supplierId);
      const productId = Number(body.productId);
      const quantity = Number(body.quantity);

      if (!supplierId || !productId || !quantity) {
        sendError(res, 400, 'Invalid Request', 'Supplier ID, Product ID, and Quantity are required');
        return true;
      }

      const product = products.find(p => p.productId === productId);
      const unitPrice = product ? product.unitPrice : 50;
      const totalAmount = body.totalAmount ? Number(body.totalAmount) : unitPrice * quantity;

      const newId = purchaseOrders.length > 0 ? Math.max(...purchaseOrders.map(po => po.orderId)) + 1 : 1;
      const newPO: PurchaseOrder = {
        orderId: newId,
        supplierId,
        productId,
        quantity,
        orderDate: new Date().toISOString(),
        expectedDeliveryDate: body.expectedDeliveryDate || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
        totalAmount,
        status: body.status || 'PENDING'
      };
      purchaseOrders.push(newPO);
      sendJson(res, 201, enrichPO(newPO));
      return true;
    }

    const poStatusMatch = pathname.match(/^\/api\/purchase-orders\/(\d+)\/status$/);
    if (poStatusMatch && method === 'PATCH') {
      const id = parseInt(poStatusMatch[1], 10);
      const body = await parseJsonBody(req);
      const po = purchaseOrders.find(p => p.orderId === id);
      if (!po) {
        sendError(res, 404, 'Resource Not Found', `Purchase Order not found with ID: ${id}`);
        return true;
      }
      po.status = (body.status || 'PENDING').toUpperCase() as any;
      sendJson(res, 200, enrichPO(po));
      return true;
    }

    const poDeleteMatch = pathname.match(/^\/api\/purchase-orders\/(\d+)$/);
    if (poDeleteMatch && method === 'DELETE') {
      const id = parseInt(poDeleteMatch[1], 10);
      const index = purchaseOrders.findIndex(p => p.orderId === id);
      if (index !== -1) {
        purchaseOrders.splice(index, 1);
      }
      sendJson(res, 200, { success: true, message: `PO #${id} deleted` });
      return true;
    }

    // -------------------------------------------------------------
    // 9. Reports API: /api/reports/*
    // -------------------------------------------------------------
    if (pathname === '/api/reports/inventory' && method === 'GET') {
      const totalValuation = products.reduce((acc, p) => acc + (p.unitPrice * p.quantity), 0);
      sendJson(res, 200, {
        generatedAt: new Date().toISOString(),
        totalProducts: products.length,
        totalStockUnits: products.reduce((acc, p) => acc + p.quantity, 0),
        totalValuation,
        products: products.map(enrichProduct)
      });
      return true;
    }

    if (pathname === '/api/reports/warehouses' && method === 'GET') {
      const report = warehouses.map(w => ({
        warehouseId: w.warehouseId,
        warehouseName: w.warehouseName,
        location: w.location,
        capacity: w.capacity,
        occupiedSpace: w.occupiedSpace,
        availableSpace: w.availableSpace,
        utilizationPercentage: w.capacity > 0 ? Number(((w.occupiedSpace / w.capacity) * 100).toFixed(1)) : 0,
        status: w.status
      }));
      sendJson(res, 200, {
        generatedAt: new Date().toISOString(),
        warehouses: report
      });
      return true;
    }

    if (pathname === '/api/reports/inward' && method === 'GET') {
      sendJson(res, 200, stockInward.map(enrichInward));
      return true;
    }

    if (pathname === '/api/reports/outward' && method === 'GET') {
      sendJson(res, 200, stockOutward.map(enrichOutward));
      return true;
    }

    if (pathname === '/api/reports/suppliers' && method === 'GET') {
      sendJson(res, 200, suppliers);
      return true;
    }

    if (pathname === '/api/reports/low-stock' && method === 'GET') {
      sendJson(res, 200, products.filter(p => p.quantity <= p.minimumStockLevel).map(enrichProduct));
      return true;
    }

    // -------------------------------------------------------------
    // 10. Auth API: /api/auth/login
    // -------------------------------------------------------------
    if (pathname === '/api/auth/login' && method === 'POST') {
      const body = await parseJsonBody(req);
      const user = users.find(u => u.username.toLowerCase() === (body.username || '').toLowerCase());
      if (user) {
        sendJson(res, 200, {
          token: `wareflow_jwt_${Date.now()}`,
          userId: user.userId,
          username: user.username,
          fullName: user.fullName,
          role: user.role
        });
        return true;
      }
      sendError(res, 401, 'Unauthorized', 'Invalid username or password');
      return true;
    }

    if (pathname === '/api/auth/me' && method === 'GET') {
      const username = urlObj.searchParams.get('username') || 'admin';
      const user = users.find(u => u.username === username) || users[0];
      sendJson(res, 200, user);
      return true;
    }

    // Default 404 for unknown /api path
    sendError(res, 404, 'Endpoint Not Found', `REST endpoint [${method} ${pathname}] is not registered.`);
    return true;

  } catch (err: any) {
    console.error('API Router Exception:', err);
    sendError(res, 500, 'Internal Server Error', err.message || 'An unexpected error occurred in REST processing');
    return true;
  }
}
