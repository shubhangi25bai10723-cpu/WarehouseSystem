export interface Warehouse {
  warehouseId: number;
  warehouseName: string;
  location: string;
  capacity: number;
  occupiedSpace: number;
  availableSpace: number;
  manager: string;
  status: 'ACTIVE' | 'MAINTENANCE' | 'FULL';
  createdAt?: string;
}

export interface Supplier {
  supplierId: number;
  supplierName: string;
  company: string;
  phone: string;
  email: string;
  address: string;
  productsSupplied: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt?: string;
}

export interface Product {
  productId: number;
  productName: string;
  sku: string;
  category: string;
  description: string;
  quantity: number;
  minimumStockLevel: number;
  unitPrice: number;
  supplierId?: number;
  supplierName?: string;
  supplier?: Supplier;
  warehouseId?: number;
  warehouseName?: string;
  warehouse?: Warehouse;
  createdDate?: string;
  updatedDate?: string;
}

export interface StockInward {
  inwardId: number;
  productId: number;
  productName?: string;
  product?: Product;
  supplierId?: number;
  supplierName?: string;
  supplier?: Supplier;
  warehouseId: number;
  warehouseName?: string;
  warehouse?: Warehouse;
  quantity: number;
  receivedDate: string;
  receivedBy: string;
  notes?: string;
  status: 'CONFIRMED' | 'PENDING_INSPECTION' | 'REJECTED';
}

export interface StockOutward {
  outwardId: number;
  productId: number;
  productName?: string;
  product?: Product;
  warehouseId: number;
  warehouseName?: string;
  warehouse?: Warehouse;
  quantity: number;
  destination: string;
  dispatchDate: string;
  dispatchedBy: string;
  notes?: string;
  status: 'CONFIRMED' | 'DISPATCHED' | 'CANCELLED';
}

export interface PurchaseOrder {
  orderId: number;
  supplierId: number;
  supplierName?: string;
  supplier?: Supplier;
  productId: number;
  productName?: string;
  product?: Product;
  quantity: number;
  orderDate: string;
  expectedDeliveryDate: string;
  totalAmount: number;
  status: 'PENDING' | 'APPROVED' | 'RECEIVED' | 'CANCELLED';
}

export interface User {
  userId: number;
  username: string;
  fullName: string;
  email: string;
  role: 'ADMIN' | 'MANAGER' | 'STAFF';
  status: 'ACTIVE' | 'INACTIVE';
}

export interface AlertItem {
  id: string;
  type: 'LOW_STOCK' | 'OUT_OF_STOCK' | 'OVERSTOCK' | 'PENDING_PO';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  referenceId?: number;
  timestamp: string;
}

export interface DashboardSummary {
  totalProducts: number;
  totalStock: number;
  lowStockItems: number;
  outOfStockItems: number;
  totalSuppliers: number;
  pendingOrders: number;
  todayInwardStock: number;
  todayOutwardStock: number;
  categoryDistribution: { category: string; count: number }[];
  recentStockMovements: {
    id: string;
    type: 'INWARD' | 'OUTWARD';
    productName: string;
    quantity: number;
    warehouse: string;
    party: string;
    timestamp: string;
  }[];
  activeAlerts: AlertItem[];
}
