import type {
  DashboardSummary,
  Product,
  Warehouse,
  Supplier,
  StockInward,
  StockOutward,
  PurchaseOrder,
  AlertItem,
  User
} from '../types/warehouse';

// Base API configuration: can be toggled in settings to point to local Java Spring Boot on http://localhost:8080
let customBaseUrl = '';

export function getApiBaseUrl(): string {
  return customBaseUrl;
}

export function setApiBaseUrl(url: string) {
  customBaseUrl = url.replace(/\/$/, '');
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const base = getApiBaseUrl();
  const url = `${base}/api${endpoint}`;

  const defaultHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  };

  const response = await fetch(url, {
    ...options,
    headers: {
      ...defaultHeaders,
      ...(options.headers as Record<string, string>)
    }
  });

  if (!response.ok) {
    let errorMsg = `HTTP Error ${response.status}: ${response.statusText}`;
    try {
      const errData = await response.json();
      if (errData.message) errorMsg = errData.message;
      else if (errData.error) errorMsg = errData.error;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }

  // If 204 No Content
  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

// 1. Dashboard
export async function getDashboardSummary(): Promise<DashboardSummary> {
  return request<DashboardSummary>('/dashboard/summary');
}

// 2. Alerts
export async function getAlerts(): Promise<AlertItem[]> {
  return request<AlertItem[]>('/alerts');
}

// 3. Products
export async function getProducts(search?: string, category?: string): Promise<Product[]> {
  const params = new URLSearchParams();
  if (search) params.append('search', search);
  if (category && category !== 'ALL') params.append('category', category);
  const query = params.toString() ? `?${params.toString()}` : '';
  return request<Product[]>(`/products${query}`);
}

export async function getProductById(id: number): Promise<Product> {
  return request<Product>(`/products/${id}`);
}

export async function createProduct(product: Partial<Product>): Promise<Product> {
  return request<Product>('/products', {
    method: 'POST',
    body: JSON.stringify(product)
  });
}

export async function updateProduct(id: number, product: Partial<Product>): Promise<Product> {
  return request<Product>(`/products/${id}`, {
    method: 'PUT',
    body: JSON.stringify(product)
  });
}

export async function deleteProduct(id: number): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/products/${id}`, {
    method: 'DELETE'
  });
}

export async function adjustStock(id: number, delta: number): Promise<Product> {
  return request<Product>(`/products/${id}/stock?delta=${delta}`, {
    method: 'PATCH'
  });
}

// 4. Warehouses
export async function getWarehouses(): Promise<Warehouse[]> {
  return request<Warehouse[]>('/warehouses');
}

export async function createWarehouse(warehouse: Partial<Warehouse>): Promise<Warehouse> {
  return request<Warehouse>('/warehouses', {
    method: 'POST',
    body: JSON.stringify(warehouse)
  });
}

export async function updateWarehouse(id: number, warehouse: Partial<Warehouse>): Promise<Warehouse> {
  return request<Warehouse>(`/warehouses/${id}`, {
    method: 'PUT',
    body: JSON.stringify(warehouse)
  });
}

export async function deleteWarehouse(id: number): Promise<{ success: boolean }> {
  return request<{ success: boolean }>(`/warehouses/${id}`, {
    method: 'DELETE'
  });
}

// 5. Suppliers
export async function getSuppliers(): Promise<Supplier[]> {
  return request<Supplier[]>('/suppliers');
}

export async function createSupplier(supplier: Partial<Supplier>): Promise<Supplier> {
  return request<Supplier>('/suppliers', {
    method: 'POST',
    body: JSON.stringify(supplier)
  });
}

export async function updateSupplier(id: number, supplier: Partial<Supplier>): Promise<Supplier> {
  return request<Supplier>(`/suppliers/${id}`, {
    method: 'PUT',
    body: JSON.stringify(supplier)
  });
}

export async function deleteSupplier(id: number): Promise<{ success: boolean }> {
  return request<{ success: boolean }>(`/suppliers/${id}`, {
    method: 'DELETE'
  });
}

// 6. Inward Stock
export async function getInwardStock(): Promise<StockInward[]> {
  return request<StockInward[]>('/inward');
}

export async function processInwardStock(data: {
  productId: number;
  warehouseId: number;
  quantity: number;
  supplierId?: number;
  receivedBy?: string;
  notes?: string;
}): Promise<StockInward> {
  return request<StockInward>('/inward', {
    method: 'POST',
    body: JSON.stringify(data)
  });
}

// 7. Outward Stock
export async function getOutwardStock(): Promise<StockOutward[]> {
  return request<StockOutward[]>('/outward');
}

export async function processOutwardStock(data: {
  productId: number;
  warehouseId: number;
  quantity: number;
  destination: string;
  dispatchedBy?: string;
  notes?: string;
}): Promise<StockOutward> {
  return request<StockOutward>('/outward', {
    method: 'POST',
    body: JSON.stringify(data)
  });
}

// 8. Purchase Orders
export async function getPurchaseOrders(status?: string): Promise<PurchaseOrder[]> {
  const query = status && status !== 'ALL' ? `?status=${status}` : '';
  return request<PurchaseOrder[]>(`/purchase-orders${query}`);
}

export async function createPurchaseOrder(data: {
  supplierId: number;
  productId: number;
  quantity: number;
  expectedDeliveryDate?: string;
  totalAmount?: number;
  status?: string;
}): Promise<PurchaseOrder> {
  return request<PurchaseOrder>('/purchase-orders', {
    method: 'POST',
    body: JSON.stringify(data)
  });
}

export async function updatePOStatus(id: number, status: string): Promise<PurchaseOrder> {
  return request<PurchaseOrder>(`/purchase-orders/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status })
  });
}

export async function deletePurchaseOrder(id: number): Promise<{ success: boolean }> {
  return request<{ success: boolean }>(`/purchase-orders/${id}`, {
    method: 'DELETE'
  });
}

// 9. Reports
export async function getInventoryReport(): Promise<any> {
  return request<any>('/reports/inventory');
}

export async function getWarehouseReport(): Promise<any> {
  return request<any>('/reports/warehouses');
}

export async function getLowStockReport(): Promise<Product[]> {
  return request<Product[]>('/reports/low-stock');
}

// 10. Auth
export async function loginUser(username: string, password: string): Promise<{
  token: string;
  userId: number;
  username: string;
  fullName: string;
  role: 'ADMIN' | 'MANAGER' | 'STAFF';
}> {
  return request<any>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  });
}

export async function getCurrentUser(username: string = 'admin'): Promise<User> {
  return request<User>(`/auth/me?username=${username}`);
}
