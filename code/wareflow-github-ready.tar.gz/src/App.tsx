import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar, NavItemKey } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ProductManagement } from './components/ProductManagement';
import { WarehouseManagement } from './components/WarehouseManagement';
import { SupplierManagement } from './components/SupplierManagement';
import { StockInwardView } from './components/StockInwardView';
import { StockOutwardView } from './components/StockOutwardView';
import { PurchaseOrdersView } from './components/PurchaseOrdersView';
import { AlertsView } from './components/AlertsView';
import { ReportsView } from './components/ReportsView';
import { AboutProjectView } from './components/AboutProjectView';
import { SettingsView } from './components/SettingsView';

import * as api from './services/api';
import type { 
  Product, 
  Warehouse, 
  Supplier, 
  StockInward, 
  StockOutward, 
  PurchaseOrder, 
  DashboardSummary, 
  AlertItem, 
  User 
} from './types/warehouse';

export default function App() {
  const [currentView, setCurrentView] = useState<NavItemKey>('dashboard');
  const [currentUser, setCurrentUser] = useState<User>({
    userId: 1,
    username: 'admin',
    fullName: 'Dr. Alexander Vance',
    email: 'admin@wareflow.io',
    role: 'ADMIN',
    status: 'ACTIVE'
  });

  // Global State fetched from Java Spring Boot / REST API
  const [loading, setLoading] = useState(true);
  const [isBackendConnected, setIsBackendConnected] = useState(true);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [inwardList, setInwardList] = useState<StockInward[]>([]);
  const [outwardList, setOutwardList] = useState<StockOutward[]>([]);
  const [orders, setOrders] = useState<PurchaseOrder[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);

  const [selectedWarehouseId, setSelectedWarehouseId] = useState<number | null>(null);
  const [notificationToast, setNotificationToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setNotificationToast({ message, type });
    setTimeout(() => {
      setNotificationToast(null);
    }, 4000);
  };

  // Load all data from REST endpoints
  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      const [sumData, prodData, whData, supData, inData, outData, poData, alertData] = await Promise.all([
        api.getDashboardSummary(),
        api.getProducts(),
        api.getWarehouses(),
        api.getSuppliers(),
        api.getInwardStock(),
        api.getOutwardStock(),
        api.getPurchaseOrders(),
        api.getAlerts()
      ]);

      setSummary(sumData);
      setProducts(prodData);
      setWarehouses(whData);
      setSuppliers(supData);
      setInwardList(inData);
      setOutwardList(outData);
      setOrders(poData);
      setAlerts(alertData);
      setIsBackendConnected(true);
    } catch (err) {
      console.error('Failed to load data from Java backend:', err);
      setIsBackendConnected(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Product CRUD
  const handleSaveProduct = async (productData: Partial<Product>) => {
    try {
      if (productData.productId) {
        await api.updateProduct(productData.productId, productData);
        showToast(`Product [${productData.sku}] updated successfully`);
      } else {
        await api.createProduct(productData);
        showToast(`New product [${productData.sku}] created in database`);
      }
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error saving product', 'error');
    }
  };

  const handleDeleteProduct = async (id: number) => {
    try {
      await api.deleteProduct(id);
      showToast('Product removed from database');
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error deleting product', 'error');
    }
  };

  const handleAdjustStock = async (id: number, delta: number) => {
    try {
      await api.adjustStock(id, delta);
      showToast(`Stock adjusted by ${delta > 0 ? '+' : ''}${delta}`);
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error adjusting stock', 'error');
    }
  };

  // Warehouse CRUD
  const handleSaveWarehouse = async (whData: Partial<Warehouse>) => {
    try {
      if (whData.warehouseId) {
        await api.updateWarehouse(whData.warehouseId, whData);
        showToast(`Warehouse facility updated`);
      } else {
        await api.createWarehouse(whData);
        showToast(`Warehouse facility created`);
      }
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error saving warehouse', 'error');
    }
  };

  const handleDeleteWarehouse = async (id: number) => {
    try {
      await api.deleteWarehouse(id);
      showToast('Warehouse deleted');
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error deleting warehouse', 'error');
    }
  };

  // Supplier CRUD
  const handleSaveSupplier = async (supData: Partial<Supplier>) => {
    try {
      if (supData.supplierId) {
        await api.updateSupplier(supData.supplierId, supData);
        showToast(`Supplier record updated`);
      } else {
        await api.createSupplier(supData);
        showToast(`New supplier added to catalog`);
      }
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error saving supplier', 'error');
    }
  };

  const handleDeleteSupplier = async (id: number) => {
    try {
      await api.deleteSupplier(id);
      showToast('Supplier deleted');
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error deleting supplier', 'error');
    }
  };

  // Stock Inward
  const handleProcessInward = async (data: any) => {
    await api.processInwardStock(data);
    showToast(`Inward receipt of ${data.quantity} units processed and committed`);
    await loadAllData();
  };

  // Stock Outward
  const handleProcessOutward = async (data: any) => {
    await api.processOutwardStock(data);
    showToast(`Outward dispatch of ${data.quantity} units processed and committed`);
    await loadAllData();
  };

  // Purchase Orders
  const handleCreatePO = async (data: any) => {
    try {
      await api.createPurchaseOrder(data);
      showToast('Purchase Order generated successfully');
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error creating purchase order', 'error');
    }
  };

  const handleUpdatePOStatus = async (id: number, status: string) => {
    try {
      await api.updatePOStatus(id, status);
      showToast(`Purchase Order #PO-${id} marked as ${status}`);
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error updating purchase order', 'error');
    }
  };

  const handleDeletePO = async (id: number) => {
    try {
      await api.deletePurchaseOrder(id);
      showToast(`Purchase order deleted`);
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error deleting PO', 'error');
    }
  };

  const handleReceivePOIntoStock = async (po: PurchaseOrder) => {
    try {
      const whId = po.product?.warehouseId || warehouses[0]?.warehouseId || 1;
      await api.processInwardStock({
        productId: po.productId,
        warehouseId: whId,
        quantity: po.quantity,
        supplierId: po.supplierId,
        receivedBy: currentUser.fullName,
        notes: `Received fulfillment for Purchase Order #PO-${po.orderId}`
      });
      await api.updatePOStatus(po.orderId, 'RECEIVED');
      showToast(`Fulfillment received! ${po.quantity} units added to inventory for PO #${po.orderId}`);
      await loadAllData();
    } catch (err: any) {
      showToast(err.message || 'Error receiving PO fulfillment', 'error');
    }
  };

  // Quick action from header/dashboard
  const handleQuickAction = (action: 'inward' | 'outward' | 'product' | 'po') => {
    if (action === 'inward') setCurrentView('inward');
    else if (action === 'outward') setCurrentView('outward');
    else if (action === 'product') setCurrentView('inventory');
    else if (action === 'po') setCurrentView('purchase-orders');
  };

  const lowStockCount = products.filter(p => p.quantity <= p.minimumStockLevel).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Global Toast Notification */}
      {notificationToast && (
        <div className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl border text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-5 ${
          notificationToast.type === 'success'
            ? 'bg-emerald-950/90 text-emerald-300 border-emerald-700/80'
            : 'bg-rose-950/90 text-rose-300 border-rose-700/80'
        }`}>
          <span>{notificationToast.message}</span>
        </div>
      )}

      {/* Top Application Header */}
      <Header
        currentUser={currentUser}
        onUserChange={setCurrentUser}
        warehouses={warehouses}
        selectedWarehouseId={selectedWarehouseId}
        onSelectWarehouse={setSelectedWarehouseId}
        alerts={alerts}
        onQuickAction={handleQuickAction}
        onNavigate={(v) => setCurrentView(v as NavItemKey)}
        isBackendConnected={isBackendConnected}
      />

      {/* Main Content Layout with Sidebar */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
          alertCount={alerts.length}
          lowStockCount={lowStockCount}
        />

        <main className="flex-1 overflow-y-auto bg-gradient-to-b from-slate-950 via-slate-900/40 to-slate-950 pb-16">
          {currentView === 'dashboard' && (
            <DashboardView
              summary={summary}
              loading={loading}
              onQuickAction={handleQuickAction}
              onNavigate={setCurrentView}
            />
          )}

          {currentView === 'inventory' && (
            <ProductManagement
              products={selectedWarehouseId ? products.filter(p => p.warehouseId === selectedWarehouseId) : products}
              warehouses={warehouses}
              suppliers={suppliers}
              onSaveProduct={handleSaveProduct}
              onDeleteProduct={handleDeleteProduct}
              onAdjustStock={handleAdjustStock}
            />
          )}

          {currentView === 'warehouses' && (
            <WarehouseManagement
              warehouses={warehouses}
              products={products}
              onSaveWarehouse={handleSaveWarehouse}
              onDeleteWarehouse={handleDeleteWarehouse}
              onSelectWarehouseForInventory={(whId) => {
                setSelectedWarehouseId(whId);
                setCurrentView('inventory');
              }}
            />
          )}

          {currentView === 'suppliers' && (
            <SupplierManagement
              suppliers={suppliers}
              products={products}
              onSaveSupplier={handleSaveSupplier}
              onDeleteSupplier={handleDeleteSupplier}
              onCreatePOForSupplier={(supId) => {
                setCurrentView('purchase-orders');
              }}
            />
          )}

          {currentView === 'inward' && (
            <StockInwardView
              inwardList={inwardList}
              products={products}
              warehouses={warehouses}
              suppliers={suppliers}
              onProcessInward={handleProcessInward}
            />
          )}

          {currentView === 'outward' && (
            <StockOutwardView
              outwardList={outwardList}
              products={products}
              warehouses={warehouses}
              onProcessOutward={handleProcessOutward}
            />
          )}

          {currentView === 'purchase-orders' && (
            <PurchaseOrdersView
              orders={orders}
              suppliers={suppliers}
              products={products}
              warehouses={warehouses}
              onCreatePO={handleCreatePO}
              onUpdatePOStatus={handleUpdatePOStatus}
              onDeletePO={handleDeletePO}
              onReceivePOIntoStock={handleReceivePOIntoStock}
            />
          )}

          {currentView === 'alerts' && (
            <AlertsView
              alerts={alerts}
              products={products}
              onTriggerOrder={() => {
                setCurrentView('purchase-orders');
              }}
              onRefresh={loadAllData}
            />
          )}

          {currentView === 'reports' && (
            <ReportsView
              products={products}
              warehouses={warehouses}
              suppliers={suppliers}
              inwardList={inwardList}
              outwardList={outwardList}
            />
          )}

          {currentView === 'about' && (
            <AboutProjectView />
          )}

          {currentView === 'settings' && (
            <SettingsView
              currentUser={currentUser}
              onUserChange={setCurrentUser}
              isBackendConnected={isBackendConnected}
              onRefreshData={loadAllData}
            />
          )}
        </main>
      </div>
    </div>
  );
}
