import React, { useState } from 'react';
import { 
  FileCode2, 
  Server, 
  Database, 
  Cpu, 
  Layers, 
  CheckCircle2, 
  Copy, 
  Check, 
  ExternalLink, 
  ShieldCheck, 
  Terminal, 
  Boxes, 
  ArrowRight,
  Code2,
  FolderTree
} from 'lucide-react';
import { JAVA_PROJECT_FILES, JavaSourceFile } from '../data/javaCodeRepository';

export const AboutProjectView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<JavaSourceFile>(JAVA_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'ARCHITECTURE' | 'SOURCE_CODE' | 'DATABASE_SCHEMA' | 'LOCAL_RUN'>('ARCHITECTURE');

  const copyCode = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const layers = [
    {
      title: 'React 19 Frontend',
      tech: 'React.js, Tailwind CSS, Lucide',
      desc: 'Responsive web application providing modern logistics dashboard, real-time inventory management, and telemetry charts.',
      color: 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300'
    },
    {
      title: 'REST API Gateway',
      tech: 'HTTP / JSON on Port 8080',
      desc: 'CORS-enabled REST endpoints mapping client requests directly to Java Spring Boot controllers.',
      color: 'border-blue-500/40 bg-blue-950/40 text-blue-300'
    },
    {
      title: 'Spring Boot Controllers',
      tech: '@RestController, @RequestMapping',
      desc: 'Handles HTTP requests, parameter validation, role-based security filters, and DTO parsing.',
      color: 'border-indigo-500/40 bg-indigo-950/40 text-indigo-300'
    },
    {
      title: 'Service Business Logic',
      tech: '@Service, @Transactional',
      desc: 'Enforces warehouse capacity limits, checks available stock, handles atomic inventory updates, and triggers alerts.',
      color: 'border-purple-500/40 bg-purple-950/40 text-purple-300'
    },
    {
      title: 'Spring Data JPA Repositories',
      tech: 'Hibernate ORM & JPQL',
      desc: 'Abstraction layer executing SQL transactions, JPQL custom queries, and foreign-key entity mappings.',
      color: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300'
    },
    {
      title: 'MySQL Relational Database',
      tech: 'MySQL 8.0, InnoDB Engine',
      desc: 'Durable ACID database storing products, warehouses, suppliers, stock movements, and purchase orders.',
      color: 'border-amber-500/40 bg-amber-950/40 text-amber-300'
    }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* College Project Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950/60 to-slate-900 rounded-3xl border border-cyan-500/30 p-6 sm:p-8 shadow-2xl relative overflow-hidden backdrop-blur-md">
        <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/60 text-xs font-bold tracking-wider uppercase font-mono">
                College Project Presentation
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 text-xs font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Full-Stack Java + MySQL
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-['Plus_Jakarta_Sans']">
              WareFlow – Warehouse Management System
            </h1>

            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              An enterprise-grade, full-stack Warehouse Management System designed for academic evaluation.
              Powered by a real **Java 17+ Spring Boot** backend, **Spring Data JPA / Hibernate**, and a **MySQL** relational database.
            </p>
          </div>

          {/* Key Tech Specs Card */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 space-y-2 text-xs shrink-0 min-w-[280px]">
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Backend Framework:</span>
              <span className="font-bold text-white">Java 17+ Spring Boot 3</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Database & ORM:</span>
              <span className="font-bold text-cyan-300">MySQL 8.0 + Hibernate JPA</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Build Tool:</span>
              <span className="font-bold text-white">Apache Maven 3.8+</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Architecture:</span>
              <span className="font-bold text-emerald-400">Layered REST API</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Frontend:</span>
              <span className="font-bold text-indigo-300">React.js + Tailwind CSS</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('ARCHITECTURE')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'ARCHITECTURE'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          System Architecture Flow
        </button>

        <button
          onClick={() => setActiveTab('SOURCE_CODE')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'SOURCE_CODE'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Code2 className="w-4 h-4" />
          Java Source Code Inspector ({JAVA_PROJECT_FILES.length} Files)
        </button>

        <button
          onClick={() => setActiveTab('DATABASE_SCHEMA')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'DATABASE_SCHEMA'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Database className="w-4 h-4" />
          MySQL Schema & Entities
        </button>

        <button
          onClick={() => setActiveTab('LOCAL_RUN')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'LOCAL_RUN'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Terminal className="w-4 h-4" />
          Faculty Evaluation & Local Run Guide
        </button>
      </div>

      {/* Tab 1: System Architecture Diagram */}
      {activeTab === 'ARCHITECTURE' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-cyan-400" />
                6-Layer Enterprise Software Architecture
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Data flows sequentially through strictly decoupled layers enforcing business constraints at the Service level.
              </p>
            </div>

            {/* Architecture Steps Flow */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {layers.map((l, idx) => (
                <div key={idx} className={`p-5 rounded-2xl border ${l.color} space-y-3 relative group`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-950/80 border border-white/10">
                      Layer 0{idx + 1}
                    </span>
                    {idx < layers.length - 1 && (
                      <ArrowRight className="w-4 h-4 text-slate-500 hidden lg:block group-hover:translate-x-1 transition-transform" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{l.title}</h3>
                    <p className="text-xs font-mono text-cyan-400 mt-0.5">{l.tech}</p>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {l.desc}
                  </p>
                </div>
              ))}
            </div>

            {/* Text Flow Diagram */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 overflow-x-auto">
              <div className="font-mono text-xs text-cyan-300 whitespace-pre">
{`[ React.js Frontend ] ──HTTP JSON──> [ Spring Boot Controller ] ──Calls──> [ InventoryService ]
                                                                             │
                                                                             ▼ (Business Rules)
[ MySQL 8.0 Database ] <──Hibernate JPA── [ Spring Data Repository ] <──Enforces Capacity`}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Java Source Code Viewer */}
      {activeTab === 'SOURCE_CODE' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* File Picker Sidebar */}
          <div className="lg:col-span-4 bg-slate-900/90 rounded-2xl border border-slate-800/80 p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <FolderTree className="w-4 h-4 text-cyan-400" />
                Backend Codebase
              </span>
              <span className="text-[10px] font-mono text-slate-400">com.wareflow</span>
            </div>

            <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
              {JAVA_PROJECT_FILES.map((file) => (
                <button
                  key={file.name}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex flex-col gap-1 ${
                    selectedFile.name === file.name
                      ? 'bg-cyan-950/80 border border-cyan-800/60 shadow-lg shadow-cyan-950/50'
                      : 'hover:bg-slate-800/60 border border-transparent text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`font-semibold ${selectedFile.name === file.name ? 'text-white' : 'text-slate-300'}`}>
                      {file.name}
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                      file.layer === 'Service' ? 'bg-purple-950 text-purple-300' :
                      file.layer === 'Controller' ? 'bg-indigo-950 text-indigo-300' :
                      file.layer === 'Repository' ? 'bg-emerald-950 text-emerald-300' :
                      file.layer === 'Entity' ? 'bg-amber-950 text-amber-300' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {file.layer}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500 truncate">{file.path}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="lg:col-span-8 bg-slate-900/90 rounded-2xl border border-slate-800/80 p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <FileCode2 className="w-4 h-4 text-cyan-400" />
                  {selectedFile.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{selectedFile.description}</p>
              </div>

              <button
                onClick={copyCode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Code'}
              </button>
            </div>

            {/* Code Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto max-h-[500px]">
              <pre className="text-xs font-mono text-slate-200 leading-relaxed">
                <code>{selectedFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: MySQL Schema & Relationships */}
      {activeTab === 'DATABASE_SCHEMA' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl space-y-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-amber-400" />
              MySQL Relational Schema (warehouse_management)
            </h2>
            <p className="text-xs text-slate-400">
              Tables created with InnoDB engine, utf8mb4 collation, and foreign key integrity constraints.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-cyan-400 font-mono">1. products</span>
                <ul className="text-[11px] text-slate-400 space-y-1 font-mono">
                  <li>product_id (PK)</li>
                  <li>product_name</li>
                  <li>sku (UNIQUE)</li>
                  <li>quantity, min_stock</li>
                  <li>FK: supplier_id, warehouse_id</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-cyan-400 font-mono">2. warehouses</span>
                <ul className="text-[11px] text-slate-400 space-y-1 font-mono">
                  <li>warehouse_id (PK)</li>
                  <li>warehouse_name</li>
                  <li>capacity, occupied_space</li>
                  <li>available_space</li>
                  <li>manager, status</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-cyan-400 font-mono">3. stock_inward</span>
                <ul className="text-[11px] text-slate-400 space-y-1 font-mono">
                  <li>inward_id (PK)</li>
                  <li>quantity, received_date</li>
                  <li>received_by, notes</li>
                  <li>FK: product_id</li>
                  <li>FK: warehouse_id</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-cyan-400 font-mono">4. stock_outward</span>
                <ul className="text-[11px] text-slate-400 space-y-1 font-mono">
                  <li>outward_id (PK)</li>
                  <li>quantity, dispatch_date</li>
                  <li>destination, dispatched_by</li>
                  <li>FK: product_id</li>
                  <li>FK: warehouse_id</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Local Run Instructions for Evaluator */}
      {activeTab === 'LOCAL_RUN' && (
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl space-y-5">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Terminal className="w-5 h-5 text-emerald-400" />
            Evaluation Guide: Running Java Spring Boot & MySQL Locally
          </h2>
          <p className="text-xs text-slate-300">
            Follow these simple steps on any machine with Java 17+, Maven, and MySQL installed:
          </p>

          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400">Step 1: Create MySQL Database</span>
              <pre className="p-3 rounded-lg bg-slate-900 text-xs font-mono text-slate-200">
                CREATE DATABASE warehouse_management;
              </pre>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400">Step 2: Run Spring Boot Backend</span>
              <pre className="p-3 rounded-lg bg-slate-900 text-xs font-mono text-slate-200">
{`cd backend
mvn clean spring-boot:run`}
              </pre>
              <p className="text-[11px] text-slate-400">
                Spring Boot will start on <code>http://localhost:8080</code>, initialize Hibernate DDL, and load seed records.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400">Step 3: Run React Frontend</span>
              <pre className="p-3 rounded-lg bg-slate-900 text-xs font-mono text-slate-200">
{`npm install
npm run dev`}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
