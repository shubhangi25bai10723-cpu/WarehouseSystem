import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Plus, 
  Check, 
  X, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ArrowDownLeft, 
  DollarSign, 
  Calendar, 
  Building2, 
  Package,
  Trash2
} from 'lucide-react';
import type { PurchaseOrder, Supplier, Product, Warehouse } from '../types/warehouse';

interface PurchaseOrdersViewProps {
  orders: PurchaseOrder[];
  suppliers: Supplier[];
  products: Product[];
  warehouses: Warehouse[];
  onCreatePO: (data: any) => Promise<void>;
  onUpdatePOStatus: (id: number, status: string) => Promise<void>;
  onDeletePO: (id: number) => Promise<void>;
  onReceivePOIntoStock: (po: PurchaseOrder) => void;
}

export const PurchaseOrdersView: React.FC<PurchaseOrdersViewProps> = ({
  orders,
  suppliers,
  products,
  warehouses,
  onCreatePO,
  onUpdatePOStatus,
  onDeletePO,
  onReceivePOIntoStock
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState('ALL');

  const [formData, setFormData] = useState({
    supplierId: suppliers[0]?.supplierId || 1,
    productId: products[0]?.productId || 1,
    quantity: 50,
    expectedDeliveryDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    status: 'PENDING'
  });

  const selectedProduct = products.find(p => p.productId === formData.productId);
  const calculatedTotal = (selectedProduct ? selectedProduct.unitPrice : 45) * formData.quantity;

  const filteredOrders = orders.filter(o => {
    if (statusFilter === 'ALL') return true;
    return o.status === statusFilter;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onCreatePO({
      ...formData,
      totalAmount: calculatedTotal
    });
    setIsModalOpen(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-amber-950 text-amber-300 border-amber-800/50';
      case 'APPROVED':
        return 'bg-blue-950 text-blue-300 border-blue-800/50';
      case 'RECEIVED':
        return 'bg-emerald-950 text-emerald-300 border-emerald-800/50';
      case 'CANCELLED':
        return 'bg-rose-950 text-rose-300 border-rose-800/50';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Purchase Orders & Procurement
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Generate replenishment POs, track vendor fulfillment lifecycles, and receive inbound freight.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Create Purchase Order
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 w-fit">
        {['ALL', 'PENDING', 'APPROVED', 'RECEIVED', 'CANCELLED'].map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              statusFilter === st
                ? 'bg-slate-800 text-white font-bold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {st} ({orders.filter(o => st === 'ALL' || o.status === st).length})
          </button>
        ))}
      </div>

      {/* Orders Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 shadow-xl overflow-hidden backdrop-blur-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                <th className="py-3.5 px-4 font-semibold">PO Number</th>
                <th className="py-3.5 px-4 font-semibold">Supplier</th>
                <th className="py-3.5 px-4 font-semibold">Product</th>
                <th className="py-3.5 px-4 font-semibold">Order Qty</th>
                <th className="py-3.5 px-4 font-semibold">Order Date</th>
                <th className="py-3.5 px-4 font-semibold">Expected Delivery</th>
                <th className="py-3.5 px-4 font-semibold">Total Amount</th>
                <th className="py-3.5 px-4 font-semibold">Status</th>
                <th className="py-3.5 px-4 font-semibold text-right">Actions / Workflow</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-slate-400">
                    No purchase orders found for the selected status.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((po) => (
                  <tr key={po.orderId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-cyan-400">
                      #PO-{po.orderId.toString().padStart(4, '0')}
                    </td>
                    <td className="py-3 px-4 text-slate-200 font-medium">
                      {po.supplierName}
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {po.productName}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {po.quantity} units
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-mono">
                      {new Date(po.orderDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-mono">
                      {po.expectedDeliveryDate}
                    </td>
                    <td className="py-3 px-4 font-mono text-emerald-400 font-bold">
                      ${Number(po.totalAmount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(po.status)}`}>
                        {po.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {po.status === 'PENDING' && (
                          <button
                            onClick={() => onUpdatePOStatus(po.orderId, 'APPROVED')}
                            className="px-2.5 py-1 rounded-lg bg-blue-950 text-blue-300 hover:bg-blue-900 border border-blue-800/50 text-[11px] font-semibold transition-colors"
                          >
                            Approve PO
                          </button>
                        )}

                        {po.status === 'APPROVED' && (
                          <button
                            onClick={() => onReceivePOIntoStock(po)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 hover:bg-emerald-900 border border-emerald-800/50 text-[11px] font-semibold transition-colors"
                          >
                            <ArrowDownLeft className="w-3 h-3" />
                            Receive Goods
                          </button>
                        )}

                        {po.status !== 'CANCELLED' && po.status !== 'RECEIVED' && (
                          <button
                            onClick={() => onUpdatePOStatus(po.orderId, 'CANCELLED')}
                            className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                            title="Cancel Order"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => {
                            if (confirm(`Delete Purchase Order #PO-${po.orderId}?`)) {
                              onDeletePO(po.orderId);
                            }
                          }}
                          className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Order Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden ring-1 ring-white/10 animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-cyan-400" />
                Issue New Purchase Order
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Target Supplier *</label>
                <select
                  value={formData.supplierId}
                  onChange={(e) => setFormData({ ...formData, supplierId: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                >
                  {suppliers.map(s => (
                    <option key={s.supplierId} value={s.supplierId}>
                      {s.supplierName} ({s.company})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Product Item *</label>
                <select
                  value={formData.productId}
                  onChange={(e) => setFormData({ ...formData, productId: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                >
                  {products.map(p => (
                    <option key={p.productId} value={p.productId}>
                      [{p.sku}] {p.productName} — Unit Price: ${p.unitPrice}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Order Quantity *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Math.max(1, Number(e.target.value)) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Expected Delivery Date</label>
                  <input
                    type="date"
                    required
                    value={formData.expectedDeliveryDate}
                    onChange={(e) => setFormData({ ...formData, expectedDeliveryDate: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <span className="text-slate-400">Total Purchase Value:</span>
                <span className="text-base font-mono font-bold text-emerald-400">
                  ${calculatedTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20"
                >
                  Issue Purchase Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
