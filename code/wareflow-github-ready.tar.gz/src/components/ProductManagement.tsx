import React, { useState } from 'react';
import { 
  Package, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Filter, 
  Layers, 
  DollarSign, 
  Building2, 
  Warehouse as WarehouseIcon,
  X,
  ChevronDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import type { Product, Warehouse, Supplier } from '../types/warehouse';

interface ProductManagementProps {
  products: Product[];
  warehouses: Warehouse[];
  suppliers: Supplier[];
  onSaveProduct: (product: Partial<Product>) => Promise<void>;
  onDeleteProduct: (id: number) => Promise<void>;
  onAdjustStock: (id: number, delta: number) => Promise<void>;
}

export const ProductManagement: React.FC<ProductManagementProps> = ({
  products,
  warehouses,
  suppliers,
  onSaveProduct,
  onDeleteProduct,
  onAdjustStock
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'OUT'>('ALL');
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    productName: '',
    sku: '',
    category: 'Machinery Parts',
    description: '',
    quantity: 0,
    minimumStockLevel: 15,
    unitPrice: 50.00,
    supplierId: suppliers[0]?.supplierId || 1,
    warehouseId: warehouses[0]?.warehouseId || 1
  });

  const categories = ['ALL', 'Hydraulics', 'Machinery Parts', 'Fasteners', 'Electronics', 'Electrical', 'Packaging', 'Hardware'];

  // Filter products
  const filteredProducts = products.filter(p => {
    const matchesSearch = 
      p.productName.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase());

    const matchesCategory = selectedCategory === 'ALL' || p.category.toLowerCase() === selectedCategory.toLowerCase();

    let matchesStock = true;
    if (stockFilter === 'LOW') {
      matchesStock = p.quantity > 0 && p.quantity <= p.minimumStockLevel;
    } else if (stockFilter === 'OUT') {
      matchesStock = p.quantity === 0;
    }

    return matchesSearch && matchesCategory && matchesStock;
  });

  const openCreateModal = () => {
    setEditingProduct(null);
    setFormData({
      productName: '',
      sku: `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      category: 'Machinery Parts',
      description: '',
      quantity: 10,
      minimumStockLevel: 15,
      unitPrice: 45.00,
      supplierId: suppliers[0]?.supplierId || 1,
      warehouseId: warehouses[0]?.warehouseId || 1
    });
    setIsModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      productName: product.productName,
      sku: product.sku,
      category: product.category,
      description: product.description || '',
      quantity: product.quantity,
      minimumStockLevel: product.minimumStockLevel,
      unitPrice: product.unitPrice,
      supplierId: product.supplierId || suppliers[0]?.supplierId || 1,
      warehouseId: product.warehouseId || warehouses[0]?.warehouseId || 1
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveProduct({
      ...(editingProduct ? { productId: editingProduct.productId } : {}),
      ...formData
    });
    setIsModalOpen(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Product & Inventory Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Browse, search, edit SKUs, track minimum safety stock, and adjust real-time warehouse inventory.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add New Product
        </button>
      </div>

      {/* Filters and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800/80 backdrop-blur-sm">
        {/* Search Input */}
        <div className="md:col-span-5 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Product Name, SKU, or Category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
          />
        </div>

        {/* Category Filter */}
        <div className="md:col-span-4 relative">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors cursor-pointer"
          >
            {categories.map(c => (
              <option key={c} value={c}>
                {c === 'ALL' ? 'All Categories' : c}
              </option>
            ))}
          </select>
        </div>

        {/* Stock Level Filter */}
        <div className="md:col-span-3 flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setStockFilter('ALL')}
            className={`flex-1 py-1 text-[11px] font-medium rounded-lg transition-colors ${
              stockFilter === 'ALL' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All ({products.length})
          </button>
          <button
            onClick={() => setStockFilter('LOW')}
            className={`flex-1 py-1 text-[11px] font-medium rounded-lg transition-colors ${
              stockFilter === 'LOW' ? 'bg-amber-950 text-amber-300 font-bold border border-amber-800/50' : 'text-slate-400 hover:text-amber-400'
            }`}
          >
            Low
          </button>
          <button
            onClick={() => setStockFilter('OUT')}
            className={`flex-1 py-1 text-[11px] font-medium rounded-lg transition-colors ${
              stockFilter === 'OUT' ? 'bg-rose-950 text-rose-300 font-bold border border-rose-800/50' : 'text-slate-400 hover:text-rose-400'
            }`}
          >
            OOS
          </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 shadow-xl overflow-hidden backdrop-blur-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                <th className="py-3.5 px-4 font-semibold">SKU / Product</th>
                <th className="py-3.5 px-4 font-semibold">Category</th>
                <th className="py-3.5 px-4 font-semibold">Warehouse / Location</th>
                <th className="py-3.5 px-4 font-semibold">Current Stock</th>
                <th className="py-3.5 px-4 font-semibold">Safety Level</th>
                <th className="py-3.5 px-4 font-semibold">Unit Price</th>
                <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    No products found matching your search and filter criteria.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => {
                  const isLow = product.quantity > 0 && product.quantity <= product.minimumStockLevel;
                  const isOut = product.quantity === 0;

                  return (
                    <tr key={product.productId} className="hover:bg-slate-800/40 transition-colors group">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors cursor-pointer" onClick={() => setViewingProduct(product)}>
                          {product.productName}
                        </div>
                        <div className="text-[11px] font-mono text-cyan-400 mt-0.5">{product.sku}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[11px] border border-slate-700/60">
                          {product.category}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-300">{product.warehouseName || 'Unassigned'}</div>
                        <div className="text-[11px] text-slate-400">{product.supplierName || 'Standard Supplier'}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className={`font-mono text-sm font-bold ${
                            isOut ? 'text-rose-400' : isLow ? 'text-amber-400' : 'text-emerald-400'
                          }`}>
                            {product.quantity}
                          </span>

                          {/* Quick Increment/Decrement Buttons */}
                          <div className="flex items-center gap-0.5 bg-slate-950 rounded border border-slate-800">
                            <button
                              onClick={() => onAdjustStock(product.productId, 1)}
                              title="Increase Stock (+1)"
                              className="p-1 hover:text-emerald-400 text-slate-400 hover:bg-slate-800 rounded transition-colors"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              disabled={product.quantity <= 0}
                              onClick={() => onAdjustStock(product.productId, -1)}
                              title="Decrease Stock (-1)"
                              className="p-1 hover:text-rose-400 text-slate-400 hover:bg-slate-800 rounded transition-colors disabled:opacity-30"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>

                          {isOut ? (
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800/40">
                              OOS
                            </span>
                          ) : isLow ? (
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800/40">
                              LOW
                            </span>
                          ) : null}
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-400">
                        {product.minimumStockLevel} units
                      </td>

                      <td className="py-3 px-4 font-mono text-white font-medium">
                        ${Number(product.unitPrice).toFixed(2)}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEditModal(product)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                            title="Edit Product"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete SKU [${product.sku}] ${product.productName}?`)) {
                                onDeleteProduct(product.productId);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                            title="Delete Product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden ring-1 ring-white/10 animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Package className="w-4 h-4 text-cyan-400" />
                {editingProduct ? `Edit Product: ${editingProduct.sku}` : 'Add New Warehouse Product'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Product Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                    placeholder="e.g., Heavy Duty Hydraulic Pump"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">SKU (Unique Code) *</label>
                  <input
                    type="text"
                    required
                    value={formData.sku}
                    onChange={(e) => setFormData({ ...formData, sku: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                    placeholder="e.g., PUMP-HYD-350"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    {categories.filter(c => c !== 'ALL').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Unit Price ($ USD) *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={formData.unitPrice}
                    onChange={(e) => setFormData({ ...formData, unitPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Current Stock Quantity</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Minimum Safety Stock Level</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formData.minimumStockLevel}
                    onChange={(e) => setFormData({ ...formData, minimumStockLevel: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Warehouse Facility</label>
                  <select
                    value={formData.warehouseId}
                    onChange={(e) => setFormData({ ...formData, warehouseId: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    {warehouses.map(w => (
                      <option key={w.warehouseId} value={w.warehouseId}>{w.warehouseName}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Primary Supplier</label>
                  <select
                    value={formData.supplierId}
                    onChange={(e) => setFormData({ ...formData, supplierId: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    {suppliers.map(s => (
                      <option key={s.supplierId} value={s.supplierId}>{s.supplierName}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="Industrial specs, dimensions, material rating..."
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02]"
                >
                  {editingProduct ? 'Update Product' : 'Save to MySQL Database'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Product Details Drawer / Modal */}
      {viewingProduct && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-4 ring-1 ring-white/10">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[11px] font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/40">
                  {viewingProduct.sku}
                </span>
                <h2 className="text-lg font-bold text-white mt-1.5">{viewingProduct.productName}</h2>
                <p className="text-xs text-slate-400">{viewingProduct.category}</p>
              </div>
              <button
                onClick={() => setViewingProduct(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/60">
                {viewingProduct.description || 'No additional technical specifications provided for this product.'}
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Available Stock:</span>
                  <div className="text-lg font-mono font-bold text-white mt-0.5">{viewingProduct.quantity} units</div>
                </div>
                <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Safety Threshold:</span>
                  <div className="text-lg font-mono font-bold text-amber-400 mt-0.5">{viewingProduct.minimumStockLevel} units</div>
                </div>
                <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Unit Price:</span>
                  <div className="text-lg font-mono font-bold text-cyan-300 mt-0.5">${Number(viewingProduct.unitPrice).toFixed(2)}</div>
                </div>
                <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Asset Value:</span>
                  <div className="text-lg font-mono font-bold text-emerald-400 mt-0.5">
                    ${(viewingProduct.quantity * viewingProduct.unitPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Warehouse Facility:</span>
                  <span className="text-slate-200 font-medium">{viewingProduct.warehouseName || 'Unassigned'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Primary Supplier:</span>
                  <span className="text-slate-200 font-medium">{viewingProduct.supplierName || 'Unassigned'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Database Record Date:</span>
                  <span className="text-slate-400 font-mono">{viewingProduct.createdDate ? new Date(viewingProduct.createdDate).toLocaleDateString() : 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  const p = viewingProduct;
                  setViewingProduct(null);
                  openEditModal(p);
                }}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
              >
                Edit SKU
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
