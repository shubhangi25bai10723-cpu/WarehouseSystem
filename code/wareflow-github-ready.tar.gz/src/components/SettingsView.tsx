import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Server, 
  Database, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  ShieldCheck, 
  Save, 
  Cpu, 
  Sliders,
  UserCheck
} from 'lucide-react';
import { getApiBaseUrl, setApiBaseUrl, getDashboardSummary } from '../services/api';
import type { User } from '../types/warehouse';

interface SettingsViewProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  isBackendConnected: boolean;
  onRefreshData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onUserChange,
  isBackendConnected,
  onRefreshData
}) => {
  const [apiUrl, setApiUrl] = useState(getApiBaseUrl());
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const handleSaveApiUrl = () => {
    setApiBaseUrl(apiUrl);
    setTestResult({
      success: true,
      message: `REST API Target updated to: ${apiUrl || 'Built-in Container API (/api)'}`
    });
    onRefreshData();
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      setApiBaseUrl(apiUrl);
      const res = await getDashboardSummary();
      setTestResult({
        success: true,
        message: `Connection Successful! Java backend responded with ${res.totalProducts} active catalog products.`
      });
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `Connection Failed: ${err.message || 'Unable to reach backend endpoint.'}`
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="pb-2 border-b border-slate-800/80">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
          System Settings & Backend Connectivity
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Configure Java Spring Boot REST endpoints, test MySQL connectivity, and switch security access roles.
        </p>
      </div>

      {/* Backend Connection Target Card */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-white">Java Spring Boot API Endpoint</h2>
          </div>
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold flex items-center gap-1.5 ${
            isBackendConnected ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/50' : 'bg-rose-950 text-rose-300 border border-rose-800/50'
          }`}>
            <span className={`w-2 h-2 rounded-full ${isBackendConnected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
            {isBackendConnected ? 'Connected & Active' : 'Disconnected'}
          </span>
        </div>

        <div className="space-y-3">
          <label className="block text-xs font-semibold text-slate-300">
            Backend Target Base URL
          </label>
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <input
              type="text"
              value={apiUrl}
              onChange={(e) => setApiUrl(e.target.value)}
              placeholder="Leave empty for built-in container API, or use http://localhost:8080"
              className="w-full sm:flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={handleSaveApiUrl}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-600/20 transition-all flex items-center justify-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              Save Configuration
            </button>
            <button
              onClick={handleTestConnection}
              disabled={isTesting}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center justify-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              Test Connection
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={() => { setApiUrl(''); }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 hover:bg-slate-800 border border-slate-700"
            >
              Use Container Built-in API
            </button>
            <button
              onClick={() => { setApiUrl('http://localhost:8080'); }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 hover:bg-slate-800 border border-slate-700 font-mono"
            >
              Use Local Spring Boot (http://localhost:8080)
            </button>
          </div>

          {testResult && (
            <div className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 mt-2 ${
              testResult.success ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-300' : 'bg-rose-950/60 border-rose-800/60 text-rose-300'
            }`}>
              {testResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <XCircle className="w-4 h-4 text-rose-400 shrink-0" />}
              <span>{testResult.message}</span>
            </div>
          )}
        </div>
      </div>

      {/* Role-Based Access Control (RBAC) */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <UserCheck className="w-5 h-5 text-indigo-400" />
          <h2 className="text-sm font-bold text-white">Spring Security Role-Based Access Control (RBAC)</h2>
        </div>

        <p className="text-xs text-slate-400">
          Switch user roles to test endpoint authority and permission boundaries:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { role: 'ADMIN' as const, name: 'Dr. Alexander Vance', desc: 'Full authority: Product CRUD, warehouse allocation, PO approvals.' },
            { role: 'MANAGER' as const, name: 'Elena Rostova', desc: 'Operational authority: Inward/Outward stock management, reports.' },
            { role: 'STAFF' as const, name: 'Marcus Brody', desc: 'Logistics desk: Dispatch confirmations, dock physical counts.' }
          ].map((item) => (
            <div
              key={item.role}
              onClick={() => onUserChange({ ...currentUser, role: item.role, fullName: item.name })}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                currentUser.role === item.role
                  ? 'bg-cyan-950/60 border-cyan-500 shadow-lg shadow-cyan-950/50'
                  : 'bg-slate-950/50 border-slate-800 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">{item.role}</span>
                {currentUser.role === item.role && (
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                )}
              </div>
              <p className="text-xs font-semibold text-slate-300 mt-1">{item.name}</p>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* System Specifications */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <Cpu className="w-5 h-5 text-slate-400" />
          <h2 className="text-sm font-bold text-white">System Environment Specifications</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">Java Virtual Machine:</span>
            <p className="text-slate-200 font-mono font-bold mt-0.5">OpenJDK 17 LTS</p>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">Spring Boot Version:</span>
            <p className="text-slate-200 font-mono font-bold mt-0.5">v3.2.3</p>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">Database Engine:</span>
            <p className="text-slate-200 font-mono font-bold mt-0.5">MySQL 8.0 / InnoDB</p>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">Frontend Environment:</span>
            <p className="text-slate-200 font-mono font-bold mt-0.5">React 19 + Vite 6</p>
          </div>
        </div>
      </div>
    </div>
  );
};
