import React, { useState } from 'react';
import { 
  Truck, 
  Plus, 
  Edit3, 
  Trash2, 
  Phone, 
  Mail, 
  MapPin, 
  Package, 
  ShoppingCart, 
  X,
  Building2
} from 'lucide-react';
import type { Supplier, Product } from '../types/warehouse';

interface SupplierManagementProps {
  suppliers: Supplier[];
  products: Product[];
  onSaveSupplier: (supplier: Partial<Supplier>) => Promise<void>;
  onDeleteSupplier: (id: number) => Promise<void>;
  onCreatePOForSupplier: (supplierId: number) => void;
}

export const SupplierManagement: React.FC<SupplierManagementProps> = ({
  suppliers,
  products,
  onSaveSupplier,
  onDeleteSupplier,
  onCreatePOForSupplier
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  const [formData, setFormData] = useState({
    supplierName: '',
    company: '',
    phone: '',
    email: '',
    address: '',
    productsSupplied: '',
    status: 'ACTIVE' as 'ACTIVE' | 'INACTIVE'
  });

  const openCreateModal = () => {
    setEditingSupplier(null);
    setFormData({
      supplierName: '',
      company: '',
      phone: '+1-555-010-0000',
      email: '',
      address: '',
      productsSupplied: '',
      status: 'ACTIVE'
    });
    setIsModalOpen(true);
  };

  const openEditModal = (sup: Supplier) => {
    setEditingSupplier(sup);
    setFormData({
      supplierName: sup.supplierName,
      company: sup.company,
      phone: sup.phone,
      email: sup.email,
      address: sup.address,
      productsSupplied: sup.productsSupplied,
      status: sup.status
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSupplier({
      ...(editingSupplier ? { supplierId: editingSupplier.supplierId } : {}),
      ...formData
    });
    setIsModalOpen(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Supplier & Vendor Network
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage authorized industrial equipment manufacturers, contact directories, and supply contracts.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add New Supplier
        </button>
      </div>

      {/* Grid of Suppliers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {suppliers.map((sup) => {
          const suppliedProducts = products.filter(p => p.supplierId === sup.supplierId);

          return (
            <div
              key={sup.supplierId}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/80 shadow-xl backdrop-blur-sm flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all group"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-indigo-950/80 border border-indigo-800/60 flex items-center justify-center text-indigo-400">
                      <Truck className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {sup.supplierName}
                      </h2>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-slate-500" />
                        <span>{sup.company}</span>
                      </div>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    sup.status === 'ACTIVE' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50' :
                    'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}>
                    {sup.status}
                  </span>
                </div>

                {/* Contact info */}
                <div className="mt-4 space-y-2 text-xs bg-slate-950/50 p-3 rounded-xl border border-slate-800/60">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="font-mono text-[11px]">{sup.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="font-mono text-[11px] truncate">{sup.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="text-[11px] truncate">{sup.address}</span>
                  </div>
                </div>

                {/* Products Supplied line */}
                <div className="mt-3">
                  <span className="text-[11px] font-semibold text-slate-400">Products Supplied:</span>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-2 italic">
                    "{sup.productsSupplied || 'Standard warehouse component lines'}"
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={() => onCreatePOForSupplier(sup.supplierId)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/80 text-indigo-300 hover:bg-indigo-900 border border-indigo-800/50 text-xs font-semibold transition-colors"
                >
                  <ShoppingCart className="w-3.5 h-3.5" />
                  Issue Purchase Order
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditModal(sup)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                    title="Edit Supplier"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete supplier ${sup.supplierName}?`)) {
                        onDeleteSupplier(sup.supplierId);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Delete Supplier"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Supplier Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden ring-1 ring-white/10 animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-cyan-400" />
                {editingSupplier ? `Edit Supplier: ${editingSupplier.supplierName}` : 'Add New Supplier Vendor'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Supplier / Vendor Name *</label>
                <input
                  type="text"
                  required
                  value={formData.supplierName}
                  onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., Apex Fasteners & Hardware"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Corporate Entity / Company *</label>
                <input
                  type="text"
                  required
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., Apex Manufacturing Inc"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                    placeholder="+1-555-014-9820"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                    placeholder="sales@vendor.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Office / Warehouse Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., 128 Assembly Row, Cleveland, OH"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Products Supplied Summary</label>
                <textarea
                  rows={2}
                  value={formData.productsSupplied}
                  onChange={(e) => setFormData({ ...formData, productsSupplied: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., Grade 8 bolts, structural rivets, anchors"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20"
                >
                  {editingSupplier ? 'Update Supplier' : 'Save Supplier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
