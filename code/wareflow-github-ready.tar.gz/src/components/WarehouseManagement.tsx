import React, { useState } from 'react';
import { 
  Warehouse as WarehouseIcon, 
  Plus, 
  Edit3, 
  Trash2, 
  MapPin, 
  User, 
  Gauge, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Layers
} from 'lucide-react';
import type { Warehouse, Product } from '../types/warehouse';

interface WarehouseManagementProps {
  warehouses: Warehouse[];
  products: Product[];
  onSaveWarehouse: (warehouse: Partial<Warehouse>) => Promise<void>;
  onDeleteWarehouse: (id: number) => Promise<void>;
  onSelectWarehouseForInventory: (warehouseId: number) => void;
}

export const WarehouseManagement: React.FC<WarehouseManagementProps> = ({
  warehouses,
  products,
  onSaveWarehouse,
  onDeleteWarehouse,
  onSelectWarehouseForInventory
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingWh, setEditingWh] = useState<Warehouse | null>(null);

  const [formData, setFormData] = useState({
    warehouseName: '',
    location: '',
    capacity: 10000,
    occupiedSpace: 0,
    manager: '',
    status: 'ACTIVE' as 'ACTIVE' | 'MAINTENANCE' | 'FULL'
  });

  const openCreateModal = () => {
    setEditingWh(null);
    setFormData({
      warehouseName: '',
      location: '',
      capacity: 15000,
      occupiedSpace: 0,
      manager: '',
      status: 'ACTIVE'
    });
    setIsModalOpen(true);
  };

  const openEditModal = (wh: Warehouse) => {
    setEditingWh(wh);
    setFormData({
      warehouseName: wh.warehouseName,
      location: wh.location,
      capacity: wh.capacity,
      occupiedSpace: wh.occupiedSpace,
      manager: wh.manager,
      status: wh.status
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveWarehouse({
      ...(editingWh ? { warehouseId: editingWh.warehouseId } : {}),
      ...formData
    });
    setIsModalOpen(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Warehouse Facilities & Capacity
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track total storage volume, active capacity utilization rates, and assigned facility managers.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Warehouse Facility
        </button>
      </div>

      {/* Warehouse Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {warehouses.map((wh) => {
          const utilPct = wh.capacity > 0 ? Math.round((wh.occupiedSpace / wh.capacity) * 100) : 0;
          const isHighUtil = utilPct >= 85;
          const whProducts = products.filter(p => p.warehouseId === wh.warehouseId);
          const totalUnitsInWh = whProducts.reduce((acc, p) => acc + p.quantity, 0);

          return (
            <div
              key={wh.warehouseId}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/80 shadow-xl backdrop-blur-sm flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all group"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                      <WarehouseIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {wh.warehouseName}
                      </h2>
                      <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="truncate max-w-[180px]">{wh.location}</span>
                      </div>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    wh.status === 'ACTIVE' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50' :
                    wh.status === 'MAINTENANCE' ? 'bg-amber-950 text-amber-400 border border-amber-800/50' :
                    'bg-rose-950 text-rose-400 border border-rose-800/50'
                  }`}>
                    {wh.status}
                  </span>
                </div>

                {/* Capacity Progress Bar */}
                <div className="mt-5 space-y-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/60">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                      Space Utilization
                    </span>
                    <span className={`font-mono font-bold ${isHighUtil ? 'text-amber-400' : 'text-cyan-300'}`}>
                      {utilPct}%
                    </span>
                  </div>

                  <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        isHighUtil ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-gradient-to-r from-cyan-500 to-blue-500'
                      }`}
                      style={{ width: `${Math.min(utilPct, 100)}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[11px] font-mono text-slate-400 pt-1">
                    <span>Occupied: <b className="text-slate-200">{wh.occupiedSpace.toLocaleString()}</b></span>
                    <span>Available: <b className="text-emerald-400">{wh.availableSpace.toLocaleString()}</b></span>
                    <span>Cap: <b className="text-slate-200">{wh.capacity.toLocaleString()}</b></span>
                  </div>
                </div>

                {/* Facility Details */}
                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      Facility Manager:
                    </span>
                    <span className="text-slate-200 font-medium">{wh.manager}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-slate-500" />
                      Stored Products:
                    </span>
                    <span className="text-slate-200 font-mono">
                      {whProducts.length} SKUs ({totalUnitsInWh.toLocaleString()} units)
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={() => onSelectWarehouseForInventory(wh.warehouseId)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium hover:underline"
                >
                  View Inventory ({whProducts.length})
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditModal(wh)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                    title="Edit Facility"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete warehouse ${wh.warehouseName}?`)) {
                        onDeleteWarehouse(wh.warehouseId);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Delete Facility"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden ring-1 ring-white/10 animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <WarehouseIcon className="w-4 h-4 text-cyan-400" />
                {editingWh ? `Edit Facility: ${editingWh.warehouseName}` : 'Add Warehouse Facility'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Warehouse Facility Name *</label>
                <input
                  type="text"
                  required
                  value={formData.warehouseName}
                  onChange={(e) => setFormData({ ...formData, warehouseName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., Midwest Central Logistics Terminal"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Physical Location / Address *</label>
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  placeholder="e.g., Gate 4, Terminal Blvd, Chicago, IL"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Total Capacity (units) *</label>
                  <input
                    type="number"
                    min="100"
                    required
                    value={formData.capacity}
                    onChange={(e) => setFormData({ ...formData, capacity: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Occupied Space</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.occupiedSpace}
                    onChange={(e) => setFormData({ ...formData, occupiedSpace: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Facility Manager *</label>
                  <input
                    type="text"
                    required
                    value={formData.manager}
                    onChange={(e) => setFormData({ ...formData, manager: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                    placeholder="e.g., Robert Vance"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Operational Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="MAINTENANCE">MAINTENANCE</option>
                    <option value="FULL">FULL</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20"
                >
                  {editingWh ? 'Update Facility' : 'Save Facility to Database'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
