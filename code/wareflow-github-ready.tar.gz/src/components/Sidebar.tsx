import React from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Warehouse as WarehouseIcon, 
  Truck, 
  ArrowDownLeft, 
  ArrowUpRight, 
  ShoppingCart, 
  BarChart3, 
  AlertOctagon, 
  FileCode2, 
  Settings,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export type NavItemKey = 
  | 'dashboard'
  | 'inventory'
  | 'warehouses'
  | 'suppliers'
  | 'inward'
  | 'outward'
  | 'purchase-orders'
  | 'reports'
  | 'alerts'
  | 'about'
  | 'settings';

interface SidebarProps {
  currentView: NavItemKey;
  onNavigate: (view: NavItemKey) => void;
  alertCount: number;
  lowStockCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  alertCount,
  lowStockCount
}) => {
  const navItems: {
    key: NavItemKey;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
    category?: string;
  }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { key: 'inventory', label: 'Inventory / Products', icon: Package, badge: lowStockCount > 0 ? `${lowStockCount} Low` : undefined, badgeColor: 'bg-amber-950 text-amber-400 border border-amber-800/40' },
    { key: 'warehouses', label: 'Warehouses', icon: WarehouseIcon },
    { key: 'suppliers', label: 'Suppliers', icon: Truck },
    { key: 'inward', label: 'Stock Inward', icon: ArrowDownLeft },
    { key: 'outward', label: 'Stock Outward', icon: ArrowUpRight },
    { key: 'purchase-orders', label: 'Purchase Orders', icon: ShoppingCart },
    { key: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { key: 'alerts', label: 'Alerts Center', icon: AlertOctagon, badge: alertCount > 0 ? alertCount : undefined, badgeColor: 'bg-rose-950 text-rose-400 border border-rose-800/40' },
    { key: 'about', label: 'Java Architecture', icon: FileCode2, badge: 'Java 17+', badgeColor: 'bg-cyan-950 text-cyan-300 border border-cyan-800/40' },
    { key: 'settings', label: 'Settings & Config', icon: Settings }
  ];

  return (
    <aside className="w-64 shrink-0 bg-slate-950/80 border-r border-slate-800/80 flex flex-col h-[calc(100vh-4rem)] sticky top-16 select-none">
      {/* Navigation Links */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          Warehouse Operations
        </div>

        {navItems.slice(0, 7).map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 to-blue-500/10 text-cyan-300 font-semibold border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.1)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-300'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        <div className="pt-3 px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          Analytics & College Project
        </div>

        {navItems.slice(7).map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 to-blue-500/10 text-cyan-300 font-semibold border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.1)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-300'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info Box */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-900/40">
        <div 
          onClick={() => onNavigate('about')}
          className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              WareFlow v1.0
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1 leading-snug">
            Spring Boot 3 + MySQL 8.0 Layered Architecture
          </p>
        </div>
      </div>
    </aside>
  );
};
