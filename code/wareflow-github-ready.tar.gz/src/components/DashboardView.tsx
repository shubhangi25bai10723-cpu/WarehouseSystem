import React from 'react';
import { 
  Package, 
  Boxes, 
  AlertTriangle, 
  XCircle, 
  Truck, 
  ShoppingCart, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Plus, 
  TrendingUp, 
  Activity, 
  ExternalLink,
  Clock,
  Warehouse as WarehouseIcon
} from 'lucide-react';
import type { DashboardSummary, AlertItem } from '../types/warehouse';

interface DashboardViewProps {
  summary: DashboardSummary | null;
  loading: boolean;
  onQuickAction: (action: 'inward' | 'outward' | 'product' | 'po') => void;
  onNavigate: (view: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summary,
  loading,
  onQuickAction,
  onNavigate
}) => {
  if (loading || !summary) {
    return (
      <div className="p-6 space-y-6 animate-pulse">
        <div className="h-8 w-64 bg-slate-800 rounded-lg"></div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-28 bg-slate-900 rounded-2xl border border-slate-800"></div>
          ))}
        </div>
      </div>
    );
  }

  const kpis = [
    {
      label: 'Total Products',
      value: summary.totalProducts,
      subtext: 'Catalog SKUs',
      icon: Package,
      color: 'from-blue-500/20 to-cyan-500/10 text-cyan-400 border-cyan-500/30',
      action: () => onNavigate('inventory')
    },
    {
      label: 'Total Stock Units',
      value: summary.totalStock.toLocaleString(),
      subtext: 'Across all warehouses',
      icon: Boxes,
      color: 'from-indigo-500/20 to-blue-500/10 text-blue-400 border-blue-500/30',
      action: () => onNavigate('inventory')
    },
    {
      label: 'Low Stock Items',
      value: summary.lowStockItems,
      subtext: 'Below minimum safety level',
      icon: AlertTriangle,
      color: summary.lowStockItems > 0 
        ? 'from-amber-500/20 to-orange-500/10 text-amber-400 border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.1)]' 
        : 'from-slate-800 to-slate-900 text-slate-400 border-slate-700',
      action: () => onNavigate('alerts')
    },
    {
      label: 'Out of Stock Items',
      value: summary.outOfStockItems,
      subtext: 'Zero inventory recorded',
      icon: XCircle,
      color: summary.outOfStockItems > 0 
        ? 'from-rose-500/20 to-red-500/10 text-rose-400 border-rose-500/40 shadow-[0_0_15px_rgba(244,63,94,0.1)]' 
        : 'from-slate-800 to-slate-900 text-slate-400 border-slate-700',
      action: () => onNavigate('alerts')
    },
    {
      label: 'Total Suppliers',
      value: summary.totalSuppliers,
      subtext: 'Active vendor accounts',
      icon: Truck,
      color: 'from-purple-500/20 to-indigo-500/10 text-purple-400 border-purple-500/30',
      action: () => onNavigate('suppliers')
    },
    {
      label: 'Pending Orders',
      value: summary.pendingOrders,
      subtext: 'Awaiting PO receipt',
      icon: ShoppingCart,
      color: 'from-amber-500/20 to-yellow-500/10 text-yellow-400 border-yellow-500/30',
      action: () => onNavigate('purchase-orders')
    },
    {
      label: "Today's Inward Stock",
      value: `+${summary.todayInwardStock}`,
      subtext: 'Units received today',
      icon: ArrowDownLeft,
      color: 'from-emerald-500/20 to-teal-500/10 text-emerald-400 border-emerald-500/30',
      action: () => onNavigate('inward')
    },
    {
      label: "Today's Outward Stock",
      value: `-${summary.todayOutwardStock}`,
      subtext: 'Units dispatched today',
      icon: ArrowUpRight,
      color: 'from-sky-500/20 to-blue-500/10 text-sky-400 border-sky-500/30',
      action: () => onNavigate('outward')
    }
  ];

  const totalCatItems = summary.categoryDistribution.reduce((acc, c) => acc + c.count, 0) || 1;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Banner: Title & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Warehouse Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time logistics telemetry, inventory tracking, and warehouse capacity monitoring.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onQuickAction('inward')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02]"
          >
            <ArrowDownLeft className="w-4 h-4" />
            Receive Inward Stock
          </button>
          <button
            onClick={() => onQuickAction('outward')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/20 transition-all hover:scale-[1.02]"
          >
            <ArrowUpRight className="w-4 h-4" />
            Dispatch Outward
          </button>
          <button
            onClick={() => onQuickAction('product')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all hover:scale-[1.02]"
          >
            <Plus className="w-4 h-4" />
            Add Product
          </button>
        </div>
      </div>

      {/* KPI Metric Cards Grid (8 stats requested by user) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div
              key={idx}
              onClick={kpi.action}
              className={`p-4 sm:p-5 rounded-2xl bg-gradient-to-br bg-slate-900/90 border backdrop-blur-sm transition-all hover:-translate-y-0.5 cursor-pointer group ${kpi.color}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400 group-hover:text-slate-200 transition-colors">
                  {kpi.label}
                </span>
                <div className="p-2 rounded-xl bg-slate-950/60 border border-white/5">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-2xl sm:text-3xl font-extrabold tracking-tight font-['Plus_Jakarta_Sans']">
                  {kpi.value}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1 font-medium">
                  {kpi.subtext}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Middle Section: Inventory Overview Chart & Stock Movement */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Breakdown & Distribution Chart */}
        <div className="lg:col-span-6 p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-semibold text-white">Inventory by Category</h2>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
            >
              Catalog <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3 pt-2">
            {summary.categoryDistribution.map((cat, idx) => {
              const pct = Math.round((cat.count / totalCatItems) * 100);
              const barColors = [
                'bg-cyan-500',
                'bg-blue-500',
                'bg-indigo-500',
                'bg-purple-500',
                'bg-teal-500',
                'bg-amber-500'
              ];
              const color = barColors[idx % barColors.length];

              return (
                <div key={cat.category} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-300">{cat.category}</span>
                    <span className="text-slate-400 font-mono">{cat.count} SKUs ({pct}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800/60">
                    <div
                      className={`h-full ${color} rounded-full transition-all duration-700`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stock Flow & Movements Ratio */}
        <div className="lg:col-span-6 p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl backdrop-blur-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <h2 className="text-sm font-semibold text-white">Stock Velocity & Movement Ratio</h2>
              </div>
              <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                Today
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="p-4 rounded-xl bg-slate-950/60 border border-emerald-900/40">
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                  <ArrowDownLeft className="w-4 h-4" />
                  Inward Received
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {summary.todayInwardStock} <span className="text-xs font-normal text-slate-400">units</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1">Dock Receiving</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-blue-900/40">
                <div className="flex items-center gap-1.5 text-xs text-blue-400 font-medium">
                  <ArrowUpRight className="w-4 h-4" />
                  Outward Dispatched
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {summary.todayOutwardStock} <span className="text-xs font-normal text-slate-400">units</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1">Customer Logistics</div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span>Today Net Inflow Balance</span>
              <span className="font-mono font-bold text-white">
                {summary.todayInwardStock - summary.todayOutwardStock >= 0 ? '+' : ''}
                {summary.todayInwardStock - summary.todayOutwardStock} units
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
              <div 
                className="bg-emerald-500 h-full" 
                style={{ width: `${summary.todayInwardStock + summary.todayOutwardStock > 0 ? (summary.todayInwardStock / (summary.todayInwardStock + summary.todayOutwardStock)) * 100 : 50}%` }}
              />
              <div 
                className="bg-blue-500 h-full" 
                style={{ width: `${summary.todayInwardStock + summary.todayOutwardStock > 0 ? (summary.todayOutwardStock / (summary.todayInwardStock + summary.todayOutwardStock)) * 100 : 50}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 font-mono">
              <span className="text-emerald-400">● Inward Inflow</span>
              <span className="text-blue-400">● Outward Dispatch</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Movements & Low-Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recent Transactions Table */}
        <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <h2 className="text-sm font-semibold text-white">Recent Transactions</h2>
            </div>
            <div className="flex gap-2 text-xs">
              <button onClick={() => onNavigate('inward')} className="text-slate-400 hover:text-emerald-400">All Inward</button>
              <span className="text-slate-700">|</span>
              <button onClick={() => onNavigate('outward')} className="text-slate-400 hover:text-blue-400">All Outward</button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2 font-medium">Type</th>
                  <th className="pb-2 font-medium">Product</th>
                  <th className="pb-2 font-medium">Qty</th>
                  <th className="pb-2 font-medium">Warehouse</th>
                  <th className="pb-2 font-medium">Destination / Supplier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {summary.recentStockMovements.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        tx.type === 'INWARD'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                          : 'bg-blue-950 text-blue-400 border border-blue-800/50'
                      }`}>
                        {tx.type === 'INWARD' ? <ArrowDownLeft className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-2.5 font-medium text-slate-200 max-w-[160px] truncate" title={tx.productName}>
                      {tx.productName}
                    </td>
                    <td className="py-2.5 font-mono font-bold text-white">
                      {tx.type === 'INWARD' ? `+${tx.quantity}` : `-${tx.quantity}`}
                    </td>
                    <td className="py-2.5 text-slate-400 truncate max-w-[120px]">
                      {tx.warehouse}
                    </td>
                    <td className="py-2.5 text-slate-400 truncate max-w-[140px]">
                      {tx.party}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low-Stock Alerts & System Notifications */}
        <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-white">Inventory & Facility Alerts</h2>
            </div>
            <button
              onClick={() => onNavigate('alerts')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
            >
              Alerts Center ({summary.activeAlerts.length})
            </button>
          </div>

          <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
            {summary.activeAlerts.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs bg-slate-950/40 rounded-xl border border-slate-800">
                No active threshold warnings. All inventory stock is within optimal levels.
              </div>
            ) : (
              summary.activeAlerts.slice(0, 5).map((alert) => (
                <div
                  key={alert.id}
                  onClick={() => onNavigate('alerts')}
                  className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                    alert.severity === 'CRITICAL'
                      ? 'bg-rose-950/40 border-rose-900/60 hover:bg-rose-950/60'
                      : alert.severity === 'WARNING'
                      ? 'bg-amber-950/40 border-amber-900/60 hover:bg-amber-950/60'
                      : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded text-[10px] ${
                      alert.severity === 'CRITICAL' ? 'bg-rose-900 text-rose-200' :
                      alert.severity === 'WARNING' ? 'bg-amber-900 text-amber-200' : 'bg-blue-900 text-blue-200'
                    }`}>
                      {alert.severity}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-slate-200 truncate">{alert.title}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed line-clamp-2">{alert.message}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
