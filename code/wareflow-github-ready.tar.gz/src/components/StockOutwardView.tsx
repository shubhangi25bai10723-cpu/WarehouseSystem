import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  CheckCircle2, 
  AlertTriangle, 
  Package, 
  Warehouse as WarehouseIcon, 
  MapPin, 
  Calendar, 
  User, 
  FileText,
  ShieldAlert
} from 'lucide-react';
import type { StockOutward, Product, Warehouse } from '../types/warehouse';

interface StockOutwardViewProps {
  outwardList: StockOutward[];
  products: Product[];
  warehouses: Warehouse[];
  onProcessOutward: (data: {
    productId: number;
    warehouseId: number;
    quantity: number;
    destination: string;
    dispatchedBy?: string;
    notes?: string;
  }) => Promise<void>;
}

export const StockOutwardView: React.FC<StockOutwardViewProps> = ({
  outwardList,
  products,
  warehouses,
  onProcessOutward
}) => {
  const [selectedProductId, setSelectedProductId] = useState<number>(products[0]?.productId || 1);
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<number>(warehouses[0]?.warehouseId || 1);
  const [quantity, setQuantity] = useState<number>(5);
  const [destination, setDestination] = useState<string>('Manufacturing Plant #4, Detroit, MI');
  const [dispatchedBy, setDispatchedBy] = useState<string>('Marcus Brody (Logistics Officer)');
  const [notes, setNotes] = useState<string>('Priority work order dispatch');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const currentProduct = products.find(p => p.productId === selectedProductId);
  const currentWarehouse = warehouses.find(w => w.warehouseId === selectedWarehouseId);

  // Business logic preview: Check available stock
  const currentStock = currentProduct ? currentProduct.quantity : 0;
  const isInsufficientStock = quantity > currentStock;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (isInsufficientStock) {
      setStatusMessage({
        type: 'error',
        text: `Java Spring Boot Validation Failed: Insufficient stock! Available quantity is ${currentStock}, but requested dispatch is ${quantity}.`
      });
      return;
    }

    try {
      setIsSubmitting(true);
      await onProcessOutward({
        productId: selectedProductId,
        warehouseId: selectedWarehouseId,
        quantity,
        destination,
        dispatchedBy,
        notes
      });
      setStatusMessage({
        type: 'success',
        text: `Stock Outward of ${quantity} units dispatched successfully! Product stock decreased and warehouse space freed.`
      });
      setQuantity(5);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Error processing stock outward transaction'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Page Header */}
      <div className="pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-blue-950 text-blue-400 border border-blue-800/50">
            <ArrowUpRight className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
              Stock Outward (Goods Dispatching)
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Issue outbound shipments to clients or assembly plants with atomic stock availability validation.
            </p>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-4 rounded-xl border text-xs flex items-start gap-3 animate-in fade-in ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-950/80 border-emerald-800/60 text-emerald-300' 
            : 'bg-rose-950/80 border-rose-800/60 text-rose-300'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Main Dispatch Form & Live Validation Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Panel */}
        <div className="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-400" />
              Dispatch Goods from Warehouse
            </h2>
            <span className="text-[11px] font-mono text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-800/40">
              POST /api/outward
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Product selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Select Product to Dispatch *</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  const pid = Number(e.target.value);
                  setSelectedProductId(pid);
                  const prod = products.find(p => p.productId === pid);
                  if (prod && prod.warehouseId) setSelectedWarehouseId(prod.warehouseId);
                }}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                {products.map(p => (
                  <option key={p.productId} value={p.productId}>
                    [{p.sku}] {p.productName} — Available: {p.quantity} units
                  </option>
                ))}
              </select>
            </div>

            {/* Warehouse and Destination */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Source Warehouse Facility *</label>
                <select
                  value={selectedWarehouseId}
                  onChange={(e) => setSelectedWarehouseId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
                >
                  {warehouses.map(w => (
                    <option key={w.warehouseId} value={w.warehouseId}>
                      {w.warehouseName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Dispatch Quantity (Units) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                  className={`w-full px-3 py-2 bg-slate-950 border rounded-xl text-xs font-mono text-white focus:outline-none ${
                    isInsufficientStock ? 'border-rose-500 focus:border-rose-400' : 'border-slate-700 focus:border-blue-500'
                  }`}
                />
              </div>
            </div>

            {/* Destination Address */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Destination / Customer / Department *</label>
              <input
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                placeholder="e.g., Midwest Regional Distribution Center, Bay 7"
              />
            </div>

            {/* Dispatched by & Notes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Dispatched By *</label>
                <input
                  type="text"
                  required
                  value={dispatchedBy}
                  onChange={(e) => setDispatchedBy(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g., Marcus Brody"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Dispatch Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="Carrier bill, work order #..."
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || isInsufficientStock || currentStock === 0}
              className={`w-full py-3 rounded-xl text-xs font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 ${
                isInsufficientStock || currentStock === 0
                  ? 'bg-rose-900/60 cursor-not-allowed text-rose-300 border border-rose-800/40'
                  : 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/20 hover:scale-[1.01]'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              {isInsufficientStock ? 'Insufficient Stock Available' : 'Authorize Outward Dispatch & Update DB'}
            </button>
          </form>
        </div>

        {/* Live Business Logic Verification & Preview */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-5 shadow-xl backdrop-blur-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Spring Boot Business Logic Validation
            </h3>

            {/* Inventory Verification Card */}
            <div className={`p-4 rounded-xl border space-y-2 ${
              isInsufficientStock ? 'bg-rose-950/40 border-rose-800/60' : 'bg-slate-950/60 border-slate-800'
            }`}>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-cyan-400" />
                  {currentProduct?.productName}
                </span>
                <span className={`font-mono text-xs font-bold ${isInsufficientStock ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {isInsufficientStock ? 'STOCK INSUFFICIENT' : 'STOCK AVAILABLE'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div>
                  <span className="text-slate-500">Available Stock:</span>
                  <p className="font-mono text-slate-200 font-bold">{currentStock} units</p>
                </div>
                <div>
                  <span className="text-slate-500">Requested Dispatch:</span>
                  <p className={`font-mono font-bold ${isInsufficientStock ? 'text-rose-400' : 'text-blue-400'}`}>
                    {quantity} units
                  </p>
                </div>
              </div>

              {isInsufficientStock && (
                <div className="pt-2 text-[11px] text-rose-300 flex items-start gap-1.5 border-t border-rose-900/60 mt-1">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    Validation Error: Attempting to dispatch {quantity} units when only {currentStock} are in inventory.
                    Spring Boot will reject with <code>InsufficientStockException</code> (HTTP 400).
                  </span>
                </div>
              )}
            </div>

            {/* Post-Outward Projection */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 text-xs">
              <div className="text-slate-400 font-semibold">Post-Dispatch Inventory Balance:</div>
              <div className="flex justify-between items-center bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-300">Remaining in Stock:</span>
                <span className={`font-mono font-bold ${isInsufficientStock ? 'text-rose-400' : 'text-slate-200'}`}>
                  {isInsufficientStock ? 'Invalid' : `${currentStock - quantity} units`}
                </span>
              </div>
            </div>

            {/* Destination Info */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1 text-xs">
              <div className="text-slate-400 font-semibold">Target Destination:</div>
              <p className="text-slate-200 font-medium">{destination}</p>
              <p className="text-[11px] text-slate-400">Warehouse Origin: {currentWarehouse?.warehouseName}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Outward History Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 shadow-xl overflow-hidden backdrop-blur-sm space-y-4 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            Historical Stock Outward Logs (Table: stock_outward)
          </h2>
          <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
            {outwardList.length} dispatches
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                <th className="py-3 px-4 font-semibold">Dispatch ID</th>
                <th className="py-3 px-4 font-semibold">Product</th>
                <th className="py-3 px-4 font-semibold">Dispatched Qty</th>
                <th className="py-3 px-4 font-semibold">Source Warehouse</th>
                <th className="py-3 px-4 font-semibold">Destination / Customer</th>
                <th className="py-3 px-4 font-semibold">Dispatched By</th>
                <th className="py-3 px-4 font-semibold">Date & Time</th>
                <th className="py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {outwardList.map((rec) => (
                <tr key={rec.outwardId} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-blue-400">
                    #OUT-{rec.outwardId.toString().padStart(4, '0')}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">
                    {rec.productName}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-blue-400">
                    -{rec.quantity} units
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {rec.warehouseName}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {rec.destination}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {rec.dispatchedBy}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {new Date(rec.dispatchDate).toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 text-[10px] font-bold border border-blue-800/50">
                      {rec.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
