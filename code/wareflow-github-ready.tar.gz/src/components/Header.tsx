import React, { useState } from 'react';
import { 
  Boxes, 
  Bell, 
  Server, 
  User as UserIcon, 
  Plus, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CheckCircle2, 
  AlertTriangle,
  ChevronDown
} from 'lucide-react';
import type { User, AlertItem, Warehouse } from '../types/warehouse';

interface HeaderProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  warehouses: Warehouse[];
  selectedWarehouseId: number | null;
  onSelectWarehouse: (id: number | null) => void;
  alerts: AlertItem[];
  onQuickAction: (action: 'inward' | 'outward' | 'product') => void;
  onNavigate: (view: string) => void;
  isBackendConnected: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onUserChange,
  warehouses,
  selectedWarehouseId,
  onSelectWarehouse,
  alerts,
  onQuickAction,
  onNavigate,
  isBackendConnected
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const availableRoles: { role: 'ADMIN' | 'MANAGER' | 'STAFF'; label: string; name: string }[] = [
    { role: 'ADMIN', label: 'Warehouse Admin', name: 'Dr. Alexander Vance' },
    { role: 'MANAGER', label: 'Warehouse Manager', name: 'Elena Rostova' },
    { role: 'STAFF', label: 'Logistics Staff', name: 'Marcus Brody' }
  ];

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md px-4 lg:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Left: Brand & Backend Status */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold text-xl ring-1 ring-white/20">
            <Boxes className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-lg text-white font-['Plus_Jakarta_Sans']">WareFlow</span>
              <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 tracking-wider">WMS</span>
            </div>
            <p className="text-[11px] text-slate-400 -mt-0.5">Industrial Warehouse System</p>
          </div>
        </div>

        {/* Backend Status Badge */}
        <div 
          onClick={() => onNavigate('about')}
          className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 cursor-pointer hover:border-cyan-500/50 transition-colors"
          title="Click to view Java Architecture and Source Code"
        >
          <div className={`w-2 h-2 rounded-full ${isBackendConnected ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'} animate-pulse`} />
          <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-cyan-400" />
            Java 17 Spring Boot REST API
          </span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/40">MySQL</span>
        </div>
      </div>

      {/* Middle: Active Warehouse Scope */}
      <div className="hidden xl:flex items-center gap-2">
        <span className="text-xs text-slate-400 font-medium">Facility:</span>
        <select
          value={selectedWarehouseId ?? ''}
          onChange={(e) => onSelectWarehouse(e.target.value ? Number(e.target.value) : null)}
          className="bg-slate-950/90 border border-slate-700/80 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500 transition-colors cursor-pointer"
        >
          <option value="">All Warehouses ({warehouses.length})</option>
          {warehouses.map((wh) => (
            <option key={wh.warehouseId} value={wh.warehouseId}>
              {wh.warehouseName} ({wh.status})
            </option>
          ))}
        </select>
      </div>

      {/* Right Controls: Quick Actions, Alerts, User Profile */}
      <div className="flex items-center gap-2.5">
        {/* Inward / Outward Quick Buttons */}
        <div className="hidden sm:flex items-center gap-1.5 bg-slate-950/60 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onQuickAction('inward')}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-emerald-950/60 text-emerald-300 border border-emerald-800/50 hover:bg-emerald-900/60 transition-colors"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span>Inward</span>
          </button>
          <button
            onClick={() => onQuickAction('outward')}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-amber-950/60 text-amber-300 border border-amber-800/50 hover:bg-amber-900/60 transition-colors"
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Outward</span>
          </button>
          <button
            onClick={() => onQuickAction('product')}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-cyan-950/60 text-cyan-300 border border-cyan-800/50 hover:bg-cyan-900/60 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Product</span>
          </button>
        </div>

        {/* Notifications / Alerts Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-colors"
            title="System Alerts"
          >
            <Bell className="w-4 h-4" />
            {alerts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-[10px] font-bold text-white flex items-center justify-center shadow-lg shadow-rose-500/50 animate-pulse">
                {alerts.length}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50 overflow-hidden ring-1 ring-white/10 animate-in fade-in slide-in-from-top-2">
              <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm text-white">Active System Alerts</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-rose-950 text-rose-400 border border-rose-800/50 font-mono">
                    {alerts.length}
                  </span>
                </div>
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    onNavigate('alerts');
                  }}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
                >
                  View All
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60">
                {alerts.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 text-xs">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                    All inventory levels and warehouse capacities are nominal.
                  </div>
                ) : (
                  alerts.slice(0, 5).map((alert) => (
                    <div
                      key={alert.id}
                      onClick={() => {
                        setShowNotifications(false);
                        onNavigate('alerts');
                      }}
                      className="p-3 hover:bg-slate-800/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-start gap-2.5">
                        <AlertTriangle className={`w-4 h-4 mt-0.5 shrink-0 ${
                          alert.severity === 'CRITICAL' ? 'text-rose-400' :
                          alert.severity === 'WARNING' ? 'text-amber-400' : 'text-cyan-400'
                        }`} />
                        <div>
                          <p className="text-xs font-medium text-slate-200">{alert.title}</p>
                          <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{alert.message}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Role Switcher */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 border border-slate-700/60 transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
              {currentUser.fullName.charAt(0)}
            </div>
            <div className="text-left hidden md:block">
              <div className="text-xs font-semibold text-slate-200 leading-tight">{currentUser.fullName}</div>
              <div className="text-[10px] text-cyan-400 font-medium leading-none">{currentUser.role}</div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50 overflow-hidden ring-1 ring-white/10">
              <div className="px-4 py-3 border-b border-slate-800 bg-slate-950/60">
                <p className="text-xs text-slate-400 font-medium">Logged in as</p>
                <p className="text-sm font-bold text-white">{currentUser.fullName}</p>
                <p className="text-xs text-cyan-400 font-mono">{currentUser.email}</p>
              </div>

              <div className="p-2">
                <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold px-2 py-1">
                  Switch Role (Spring Security RBAC)
                </p>
                {availableRoles.map((r) => (
                  <button
                    key={r.role}
                    onClick={() => {
                      onUserChange({
                        ...currentUser,
                        role: r.role,
                        fullName: r.name
                      });
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                      currentUser.role === r.role
                        ? 'bg-cyan-950/80 text-cyan-300 font-semibold border border-cyan-800/60'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{r.label}</span>
                    {currentUser.role === r.role && <span className="text-[10px] text-cyan-400">Active</span>}
                  </button>
                ))}
              </div>

              <div className="border-t border-slate-800 p-2 bg-slate-950/40">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onNavigate('about');
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800 flex items-center gap-2"
                >
                  <Server className="w-3.5 h-3.5 text-cyan-400" />
                  College Project & Java Docs
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
