import React, { useState } from 'react';
import { 
  BarChart3, 
  Download, 
  Printer, 
  Filter, 
  FileSpreadsheet, 
  Calendar, 
  Layers, 
  DollarSign, 
  TrendingUp, 
  Warehouse as WarehouseIcon,
  Truck,
  ArrowDownLeft,
  ArrowUpRight
} from 'lucide-react';
import type { Product, Warehouse, Supplier, StockInward, StockOutward } from '../types/warehouse';

interface ReportsViewProps {
  products: Product[];
  warehouses: Warehouse[];
  suppliers: Supplier[];
  inwardList: StockInward[];
  outwardList: StockOutward[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  products,
  warehouses,
  suppliers,
  inwardList,
  outwardList
}) => {
  const [activeReport, setActiveReport] = useState<'INVENTORY' | 'WAREHOUSES' | 'MOVEMENTS' | 'SUPPLIERS' | 'LOW_STOCK'>('INVENTORY');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('ALL');

  // Inventory valuation
  const totalValuation = products.reduce((acc, p) => acc + (p.unitPrice * p.quantity), 0);
  const totalUnits = products.reduce((acc, p) => acc + p.quantity, 0);

  // Filter products by warehouse
  const filteredProducts = products.filter(p => {
    if (selectedWarehouseId === 'ALL') return true;
    return p.warehouseId === Number(selectedWarehouseId);
  });

  // Export to CSV helper
  const exportToCSV = () => {
    let headers: string[] = [];
    let rows: string[][] = [];
    let filename = `WareFlow_${activeReport}_Report_${new Date().toISOString().slice(0, 10)}.csv`;

    if (activeReport === 'INVENTORY' || activeReport === 'LOW_STOCK') {
      headers = ['Product ID', 'SKU', 'Product Name', 'Category', 'Quantity', 'Min Stock', 'Unit Price ($)', 'Valuation ($)', 'Warehouse', 'Supplier'];
      const list = activeReport === 'LOW_STOCK' ? products.filter(p => p.quantity <= p.minimumStockLevel) : filteredProducts;
      rows = list.map(p => [
        p.productId.toString(),
        p.sku,
        `"${p.productName.replace(/"/g, '""')}"`,
        p.category,
        p.quantity.toString(),
        p.minimumStockLevel.toString(),
        p.unitPrice.toFixed(2),
        (p.quantity * p.unitPrice).toFixed(2),
        `"${(p.warehouseName || '').replace(/"/g, '""')}"`,
        `"${(p.supplierName || '').replace(/"/g, '""')}"`
      ]);
    } else if (activeReport === 'WAREHOUSES') {
      headers = ['Warehouse ID', 'Warehouse Name', 'Location', 'Capacity', 'Occupied Space', 'Available Space', 'Utilization %', 'Status', 'Manager'];
      rows = warehouses.map(w => [
        w.warehouseId.toString(),
        `"${w.warehouseName.replace(/"/g, '""')}"`,
        `"${w.location.replace(/"/g, '""')}"`,
        w.capacity.toString(),
        w.occupiedSpace.toString(),
        w.availableSpace.toString(),
        (w.capacity > 0 ? ((w.occupiedSpace / w.capacity) * 100).toFixed(1) : '0') + '%',
        w.status,
        `"${w.manager.replace(/"/g, '""')}"`
      ]);
    } else if (activeReport === 'MOVEMENTS') {
      headers = ['Type', 'Log ID', 'Product', 'Quantity', 'Warehouse', 'Party / Destination', 'Timestamp'];
      const inRows = inwardList.map(i => [
        'INWARD',
        `INW-${i.inwardId}`,
        `"${(i.productName || '').replace(/"/g, '""')}"`,
        `+${i.quantity}`,
        `"${(i.warehouseName || '').replace(/"/g, '""')}"`,
        `"${(i.supplierName || '').replace(/"/g, '""')}"`,
        i.receivedDate
      ]);
      const outRows = outwardList.map(o => [
        'OUTWARD',
        `OUT-${o.outwardId}`,
        `"${(o.productName || '').replace(/"/g, '""')}"`,
        `-${o.quantity}`,
        `"${(o.warehouseName || '').replace(/"/g, '""')}"`,
        `"${o.destination.replace(/"/g, '""')}"`,
        o.dispatchDate
      ]);
      rows = [...inRows, ...outRows];
    } else if (activeReport === 'SUPPLIERS') {
      headers = ['Supplier ID', 'Supplier Name', 'Company', 'Phone', 'Email', 'Status', 'Products Supplied'];
      rows = suppliers.map(s => [
        s.supplierId.toString(),
        `"${s.supplierName.replace(/"/g, '""')}"`,
        `"${s.company.replace(/"/g, '""')}"`,
        s.phone,
        s.email,
        s.status,
        `"${s.productsSupplied.replace(/"/g, '""')}"`
      ]);
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
            Reports & Analytical Intelligence
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Generate audit sheets, inventory valuations, warehouse utilization matrices, and CSV data exports.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={exportToCSV}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02]"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all hover:scale-[1.02]"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-slate-900/80 p-2 rounded-2xl border border-slate-800/80 backdrop-blur-sm">
        <button
          onClick={() => setActiveReport('INVENTORY')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
            activeReport === 'INVENTORY' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Inventory Valuation
        </button>
        <button
          onClick={() => setActiveReport('WAREHOUSES')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
            activeReport === 'WAREHOUSES' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <WarehouseIcon className="w-3.5 h-3.5" />
          Space Utilization
        </button>
        <button
          onClick={() => setActiveReport('MOVEMENTS')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
            activeReport === 'MOVEMENTS' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          Stock Movements
        </button>
        <button
          onClick={() => setActiveReport('LOW_STOCK')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
            activeReport === 'LOW_STOCK' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          Low-Stock Audit
        </button>
        <button
          onClick={() => setActiveReport('SUPPLIERS')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
            activeReport === 'SUPPLIERS' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          Suppliers Directory
        </button>
      </div>

      {/* Summary KPI Ribbon for Reports */}
      {activeReport === 'INVENTORY' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400">Total Catalog Valuation</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-0.5">
                ${totalValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-3 bg-emerald-950/60 rounded-xl text-emerald-400 border border-emerald-800/40">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400">Total Physical Units</span>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-0.5">
                {totalUnits.toLocaleString()} units
              </div>
            </div>
            <div className="p-3 bg-cyan-950/60 rounded-xl text-cyan-400 border border-cyan-800/40">
              <Layers className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400">Active SKUs</span>
              <div className="text-2xl font-bold font-mono text-white mt-0.5">
                {products.length} products
              </div>
            </div>
            <div className="p-3 bg-slate-800 rounded-xl text-slate-300">
              <BarChart3 className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}

      {/* Report Data Display */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 shadow-xl overflow-hidden backdrop-blur-sm">
        {/* Table for Inventory & Low-Stock Report */}
        {(activeReport === 'INVENTORY' || activeReport === 'LOW_STOCK') && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                  <th className="py-3 px-4 font-semibold">SKU / Code</th>
                  <th className="py-3 px-4 font-semibold">Product Name</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Stock Quantity</th>
                  <th className="py-3 px-4 font-semibold">Unit Price</th>
                  <th className="py-3 px-4 font-semibold">Total Valuation</th>
                  <th className="py-3 px-4 font-semibold">Warehouse</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {(activeReport === 'LOW_STOCK' ? products.filter(p => p.quantity <= p.minimumStockLevel) : filteredProducts).map((p) => {
                  const val = p.quantity * p.unitPrice;
                  const isOut = p.quantity === 0;
                  const isLow = p.quantity > 0 && p.quantity <= p.minimumStockLevel;

                  return (
                    <tr key={p.productId} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-cyan-400">{p.sku}</td>
                      <td className="py-3 px-4 font-medium text-slate-200">{p.productName}</td>
                      <td className="py-3 px-4 text-slate-400">{p.category}</td>
                      <td className="py-3 px-4 font-mono font-bold text-white">{p.quantity} units</td>
                      <td className="py-3 px-4 font-mono text-slate-300">${p.unitPrice.toFixed(2)}</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                        ${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-4 text-slate-300">{p.warehouseName || 'Unassigned'}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isOut ? 'bg-rose-950 text-rose-400 border border-rose-800/50' :
                          isLow ? 'bg-amber-950 text-amber-400 border border-amber-800/50' :
                          'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                        }`}>
                          {isOut ? 'OUT OF STOCK' : isLow ? 'LOW STOCK' : 'OPTIMAL'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Table for Warehouses Utilization Report */}
        {activeReport === 'WAREHOUSES' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                  <th className="py-3 px-4 font-semibold">Warehouse ID</th>
                  <th className="py-3 px-4 font-semibold">Facility Name</th>
                  <th className="py-3 px-4 font-semibold">Total Capacity</th>
                  <th className="py-3 px-4 font-semibold">Occupied Space</th>
                  <th className="py-3 px-4 font-semibold">Available Space</th>
                  <th className="py-3 px-4 font-semibold">Utilization Rate</th>
                  <th className="py-3 px-4 font-semibold">Manager</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {warehouses.map((w) => {
                  const util = w.capacity > 0 ? Math.round((w.occupiedSpace / w.capacity) * 100) : 0;
                  return (
                    <tr key={w.warehouseId} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono text-cyan-400">#WH-{w.warehouseId}</td>
                      <td className="py-3 px-4 font-bold text-slate-200">{w.warehouseName}</td>
                      <td className="py-3 px-4 font-mono">{w.capacity.toLocaleString()}</td>
                      <td className="py-3 px-4 font-mono text-slate-300">{w.occupiedSpace.toLocaleString()}</td>
                      <td className="py-3 px-4 font-mono text-emerald-400 font-bold">{w.availableSpace.toLocaleString()}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${util >= 85 ? 'bg-amber-500' : 'bg-cyan-500'}`}
                              style={{ width: `${util}%` }}
                            />
                          </div>
                          <span className="font-mono font-bold text-slate-200">{util}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-400">{w.manager}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold">
                          {w.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Table for Stock Movements Report */}
        {activeReport === 'MOVEMENTS' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                  <th className="py-3 px-4 font-semibold">Direction</th>
                  <th className="py-3 px-4 font-semibold">Transaction ID</th>
                  <th className="py-3 px-4 font-semibold">Product</th>
                  <th className="py-3 px-4 font-semibold">Quantity</th>
                  <th className="py-3 px-4 font-semibold">Facility</th>
                  <th className="py-3 px-4 font-semibold">Counterparty</th>
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {inwardList.map((i) => (
                  <tr key={`in-${i.inwardId}`} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/50 text-[10px] font-bold">
                        <ArrowDownLeft className="w-3 h-3" /> INWARD
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-cyan-400">#INW-{i.inwardId}</td>
                    <td className="py-3 px-4 font-medium text-slate-200">{i.productName}</td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400">+{i.quantity}</td>
                    <td className="py-3 px-4 text-slate-400">{i.warehouseName}</td>
                    <td className="py-3 px-4 text-slate-400">{i.supplierName}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{new Date(i.receivedDate).toLocaleString()}</td>
                  </tr>
                ))}
                {outwardList.map((o) => (
                  <tr key={`out-${o.outwardId}`} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800/50 text-[10px] font-bold">
                        <ArrowUpRight className="w-3 h-3" /> OUTWARD
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-cyan-400">#OUT-{o.outwardId}</td>
                    <td className="py-3 px-4 font-medium text-slate-200">{o.productName}</td>
                    <td className="py-3 px-4 font-mono font-bold text-blue-400">-{o.quantity}</td>
                    <td className="py-3 px-4 text-slate-400">{o.warehouseName}</td>
                    <td className="py-3 px-4 text-slate-400">{o.destination}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{new Date(o.dispatchDate).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Table for Suppliers */}
        {activeReport === 'SUPPLIERS' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                  <th className="py-3 px-4 font-semibold">Vendor ID</th>
                  <th className="py-3 px-4 font-semibold">Supplier Name</th>
                  <th className="py-3 px-4 font-semibold">Company</th>
                  <th className="py-3 px-4 font-semibold">Phone</th>
                  <th className="py-3 px-4 font-semibold">Email</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Products Supplied</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {suppliers.map((s) => (
                  <tr key={s.supplierId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-cyan-400">#SUP-{s.supplierId}</td>
                    <td className="py-3 px-4 font-bold text-slate-200">{s.supplierName}</td>
                    <td className="py-3 px-4 text-slate-300">{s.company}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{s.phone}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{s.email}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/50 text-[10px] font-bold">
                        {s.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 truncate max-w-xs">{s.productsSupplied}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
