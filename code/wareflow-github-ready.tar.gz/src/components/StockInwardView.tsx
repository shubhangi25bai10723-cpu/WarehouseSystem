import React, { useState } from 'react';
import { 
  ArrowDownLeft, 
  CheckCircle2, 
  AlertTriangle, 
  Package, 
  Warehouse as WarehouseIcon, 
  Truck, 
  Calendar, 
  User, 
  FileText,
  ShieldAlert
} from 'lucide-react';
import type { StockInward, Product, Warehouse, Supplier } from '../types/warehouse';

interface StockInwardViewProps {
  inwardList: StockInward[];
  products: Product[];
  warehouses: Warehouse[];
  suppliers: Supplier[];
  onProcessInward: (data: {
    productId: number;
    warehouseId: number;
    quantity: number;
    supplierId?: number;
    receivedBy?: string;
    notes?: string;
  }) => Promise<void>;
}

export const StockInwardView: React.FC<StockInwardViewProps> = ({
  inwardList,
  products,
  warehouses,
  suppliers,
  onProcessInward
}) => {
  const [selectedProductId, setSelectedProductId] = useState<number>(products[0]?.productId || 1);
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<number>(warehouses[0]?.warehouseId || 1);
  const [selectedSupplierId, setSelectedSupplierId] = useState<number>(suppliers[0]?.supplierId || 1);
  const [quantity, setQuantity] = useState<number>(25);
  const [receivedBy, setReceivedBy] = useState<string>('John Miller (Supervisor)');
  const [notes, setNotes] = useState<string>('Standard receiving inspection dock #3');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const currentProduct = products.find(p => p.productId === selectedProductId);
  const currentWarehouse = warehouses.find(w => w.warehouseId === selectedWarehouseId);
  const currentSupplier = suppliers.find(s => s.supplierId === selectedSupplierId);

  // Business logic preview
  const availableSpace = currentWarehouse ? currentWarehouse.availableSpace : 0;
  const isCapacityExceeded = quantity > availableSpace;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (isCapacityExceeded) {
      setStatusMessage({
        type: 'error',
        text: `Java Spring Boot Validation Failed: Capacity exceeded! Warehouse available space is ${availableSpace}, but attempted inward is ${quantity}.`
      });
      return;
    }

    try {
      setIsSubmitting(true);
      await onProcessInward({
        productId: selectedProductId,
        warehouseId: selectedWarehouseId,
        quantity,
        supplierId: selectedSupplierId,
        receivedBy,
        notes
      });
      setStatusMessage({
        type: 'success',
        text: `Stock Inward of ${quantity} units recorded successfully in MySQL database. Inventory increased and warehouse space updated!`
      });
      setQuantity(20);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Error processing stock inward transaction'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Page Header */}
      <div className="pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800/50">
            <ArrowDownLeft className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
              Stock Inward (Goods Receiving)
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Receive shipments, verify purchase specifications, and update inventory with automated warehouse capacity constraint checks.
            </p>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-4 rounded-xl border text-xs flex items-start gap-3 animate-in fade-in ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-950/80 border-emerald-800/60 text-emerald-300' 
            : 'bg-rose-950/80 border-rose-800/60 text-rose-300'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Main Receiving Form & Live Validation Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Panel */}
        <div className="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl backdrop-blur-sm space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-400" />
              Receive New Inbound Shipment
            </h2>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
              POST /api/inward
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Product selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Select Product *</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  const pid = Number(e.target.value);
                  setSelectedProductId(pid);
                  const prod = products.find(p => p.productId === pid);
                  if (prod && prod.supplierId) setSelectedSupplierId(prod.supplierId);
                  if (prod && prod.warehouseId) setSelectedWarehouseId(prod.warehouseId);
                }}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                {products.map(p => (
                  <option key={p.productId} value={p.productId}>
                    [{p.sku}] {p.productName} (Current Stock: {p.quantity})
                  </option>
                ))}
              </select>
            </div>

            {/* Warehouse and Supplier */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Destination Warehouse *</label>
                <select
                  value={selectedWarehouseId}
                  onChange={(e) => setSelectedWarehouseId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                >
                  {warehouses.map(w => (
                    <option key={w.warehouseId} value={w.warehouseId}>
                      {w.warehouseName} (Avail: {w.availableSpace})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Supplying Vendor *</label>
                <select
                  value={selectedSupplierId}
                  onChange={(e) => setSelectedSupplierId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                >
                  {suppliers.map(s => (
                    <option key={s.supplierId} value={s.supplierId}>
                      {s.supplierName}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quantity and Received By */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Inward Quantity (Units) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                  className={`w-full px-3 py-2 bg-slate-950 border rounded-xl text-xs font-mono text-white focus:outline-none ${
                    isCapacityExceeded ? 'border-rose-500 focus:border-rose-400' : 'border-slate-700 focus:border-emerald-500'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Received By (Officer/Inspector) *</label>
                <input
                  type="text"
                  required
                  value={receivedBy}
                  onChange={(e) => setReceivedBy(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  placeholder="e.g., John Miller (Supervisor)"
                />
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Receiving Notes / Bill of Lading</label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                placeholder="Inspection notes, dock bay, batch number..."
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting || isCapacityExceeded}
              className={`w-full py-3 rounded-xl text-xs font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 ${
                isCapacityExceeded
                  ? 'bg-rose-900/60 cursor-not-allowed text-rose-300 border border-rose-800/40'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20 hover:scale-[1.01]'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              {isCapacityExceeded ? 'Capacity Exceeded: Cannot Inward' : 'Confirm Inward Receipt & Commit to DB'}
            </button>
          </form>
        </div>

        {/* Live Business Logic Verification & Preview */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 p-5 shadow-xl backdrop-blur-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Spring Boot Service Rule Preview
            </h3>

            {/* Warehouse Capacity Check Card */}
            <div className={`p-4 rounded-xl border space-y-2 ${
              isCapacityExceeded ? 'bg-rose-950/40 border-rose-800/60' : 'bg-slate-950/60 border-slate-800'
            }`}>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                  <WarehouseIcon className="w-4 h-4 text-cyan-400" />
                  {currentWarehouse?.warehouseName}
                </span>
                <span className={`font-mono text-xs font-bold ${isCapacityExceeded ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {isCapacityExceeded ? 'INSUFFICIENT SPACE' : 'SPACE AVAILABLE'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div>
                  <span className="text-slate-500">Current Occupied:</span>
                  <p className="font-mono text-slate-200 font-bold">{currentWarehouse?.occupiedSpace} units</p>
                </div>
                <div>
                  <span className="text-slate-500">Available Space:</span>
                  <p className="font-mono text-emerald-400 font-bold">{currentWarehouse?.availableSpace} units</p>
                </div>
              </div>

              {isCapacityExceeded && (
                <div className="pt-2 text-[11px] text-rose-300 flex items-start gap-1.5 border-t border-rose-900/60 mt-1">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    Rule Violation: Inward quantity ({quantity}) exceeds warehouse available capacity ({availableSpace}).
                    Spring Boot will reject with <code>CapacityExceededException</code>.
                  </span>
                </div>
              )}
            </div>

            {/* Product Stock Impact Card */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 text-xs">
              <div className="text-slate-400 font-semibold">Post-Inward Inventory Projection:</div>
              <div className="flex justify-between items-center bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-300">{currentProduct?.productName}</span>
                <span className="font-mono font-bold text-emerald-400">
                  {currentProduct?.quantity} → {(currentProduct?.quantity || 0) + (isCapacityExceeded ? 0 : quantity)} units
                </span>
              </div>
            </div>

            {/* Supplier Details */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1 text-xs">
              <div className="text-slate-400 font-semibold">Supplier Verification:</div>
              <p className="text-slate-200 font-medium">{currentSupplier?.supplierName}</p>
              <p className="text-[11px] text-slate-400">{currentSupplier?.email} | {currentSupplier?.phone}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Inward History Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 shadow-xl overflow-hidden backdrop-blur-sm space-y-4 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            Historical Stock Inward Logs (Table: stock_inward)
          </h2>
          <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
            {inwardList.length} receipts
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400">
                <th className="py-3 px-4 font-semibold">Receipt ID</th>
                <th className="py-3 px-4 font-semibold">Product</th>
                <th className="py-3 px-4 font-semibold">Received Qty</th>
                <th className="py-3 px-4 font-semibold">Warehouse</th>
                <th className="py-3 px-4 font-semibold">Supplier</th>
                <th className="py-3 px-4 font-semibold">Received By</th>
                <th className="py-3 px-4 font-semibold">Date & Time</th>
                <th className="py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {inwardList.map((rec) => (
                <tr key={rec.inwardId} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-400">
                    #INW-{rec.inwardId.toString().padStart(4, '0')}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">
                    {rec.productName}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                    +{rec.quantity} units
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {rec.warehouseName}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {rec.supplierName}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {rec.receivedBy}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {new Date(rec.receivedDate).toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-800/50">
                      {rec.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
