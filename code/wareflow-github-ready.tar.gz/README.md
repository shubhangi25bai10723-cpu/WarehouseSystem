# WareFlow – Warehouse Management System (WMS)
### Enterprise Full-Stack College Project (Java 17+ Spring Boot, MySQL, React.js)

**WareFlow** is an enterprise-grade Warehouse Management System developed for college project presentation and evaluation. It features a complete **Java 17+ Spring Boot** backend with a layered architecture, **MySQL** relational database with Hibernate ORM, and a modern industrial dashboard frontend built in **React.js**.

---

## 1. System Architecture

WareFlow follows a decoupled **Layered Architecture (N-Tier)**:

```
┌─────────────────────────────────────────────────────────────┐
│                   React 19 Frontend (Vite)                  │
│       Modern Logistics Dashboard, Inward/Outward UI         │
└──────────────────────────────┬──────────────────────────────┘
                               │ HTTP / JSON (Port 8080)
┌──────────────────────────────▼──────────────────────────────┐
│             Spring Boot REST API Controllers                │
│    @RestController, @CrossOrigin, @Valid, DTO Parsing       │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│                    Service Business Logic                   │
│   Capacity Constraint Checks, Stock Availability, Alerts    │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│                 Spring Data JPA Repositories                │
│           Hibernate ORM, JPQL Queries, Transactions         │
└──────────────────────────────┬──────────────────────────────┘
                               │ JDBC
┌──────────────────────────────▼──────────────────────────────┐
│                    MySQL 8.0 Database                       │
│    InnoDB Engine, Foreign Keys, ACID Consistency            │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Technology Stack

### Backend
- **Language**: Java 17+ (LTS)
- **Framework**: Spring Boot 3.2.3
- **Data Access**: Spring Data JPA & Hibernate ORM
- **Database Engine**: MySQL 8.0 / MariaDB
- **Build Tool**: Apache Maven 3.8+
- **Security & Validation**: Spring Security, Bean Validation (`@NotNull`, `@Min`)

### Frontend
- **Framework**: React 19 (TypeScript)
- **Styling**: Tailwind CSS 4
- **Icons**: Lucide React
- **Build Tool**: Vite 6

---

## 3. Core Modules & Features

1. **Dashboard & Analytics**:
   - Total inventory valuation, physical units in stock, warehouse utilization percentage, active supplier count.
   - Monthly inward vs. outward movement analytics.
   - Low stock visual alerts with direct re-ordering workflows.

2. **Product Management**:
   - Unique SKU enforcement (`unique = true` in JPA).
   - CRUD with unit pricing, reorder thresholds, warehouse bin assignment, and supplier linkage.
   - Instant stock adjustment actions (+/- units).

3. **Warehouse Facility Management**:
   - Multiple warehouse locations (Distribution Centers, High-Bay Cold Storage, Express Hubs).
   - Real-time capacity monitoring (`occupied_space` vs. `available_space`).
   - Hard constraint verification: Inward shipments cannot exceed available space.

4. **Stock Inward (Goods Receiving)**:
   - Select product, warehouse, supplying vendor, quantity, inspector name.
   - Atomic increase in product inventory + warehouse occupied space.
   - Rejection if `quantity > warehouse.availableSpace` with `CapacityExceededException`.

5. **Stock Outward (Goods Dispatching)**:
   - Select product, warehouse origin, destination/customer, quantity, dispatch officer.
   - Atomic check of available stock: Rejection if `quantity > product.quantity` with `InsufficientStockException`.
   - Decreases product stock and frees warehouse space.

6. **Purchase Orders & Procurement**:
   - Multi-state workflow (`PENDING` → `APPROVED` → `RECEIVED` → `CANCELLED`).
   - One-click receipt into stock: Automatically logs inward movement when goods arrive.

7. **Alerts & Notifications**:
   - Out-of-Stock and Low-Stock threshold triggers.
   - Warehouse capacity alerts when utilization exceeds 85%.

8. **Reports & Exports**:
   - Inventory valuation audit, warehouse space utilization, stock movements history.
   - Direct CSV export and printable audit slips.

9. **College Project Code Inspector**:
   - In-app interactive Java Source Code Viewer for faculty examination of Controllers, Services, Repositories, Entities, and DTOs.

---

## 4. Local Setup & Execution Guide

### Prerequisites
- JDK 17 or higher (`java -version`)
- Apache Maven 3.8+ (`mvn -version`)
- MySQL 8.0 Server running on port 3306
- Node.js 18+ & npm (`node -v`)

### Step 1: Initialize the MySQL Database
Log into MySQL:
```sql
CREATE DATABASE warehouse_management;
```
*(The schema and seed data are automatically executed by Spring Boot on startup via `schema.sql` and `data.sql`, or you can execute `/backend/src/main/resources/schema.sql` manually).*

### Step 2: Configure Database Credentials
Edit `/backend/src/main/resources/application.properties` if your MySQL username/password differs from `root`/`root`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/warehouse_management?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=root
```

### Step 3: Run the Java Spring Boot Backend
```bash
cd backend
mvn clean spring-boot:run
```
The REST API will boot on `http://localhost:8080`.

### Step 4: Run the React Frontend
```bash
npm install
npm run dev
```
Open `http://localhost:3000` in your browser.

---

## 5. REST API Endpoints Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/dashboard/summary` | Get aggregated inventory KPIs & statistics |
| `GET` | `/api/products` | Retrieve catalog products list |
| `POST` | `/api/products` | Create new product with unique SKU |
| `PUT` | `/api/products/{id}` | Update product details |
| `DELETE` | `/api/products/{id}` | Remove product from inventory |
| `POST` | `/api/products/{id}/adjust-stock?delta=N` | Adjust stock quantity |
| `GET` | `/api/warehouses` | Retrieve all warehouse facilities |
| `POST` | `/api/warehouses` | Add a new warehouse facility |
| `GET` | `/api/suppliers` | List authorized vendors & suppliers |
| `POST` | `/api/suppliers` | Add a new vendor |
| `GET` | `/api/inward` | Retrieve all stock receiving records |
| `POST` | `/api/inward` | Process inward shipment (verifies capacity) |
| `GET` | `/api/outward` | Retrieve all stock dispatch records |
| `POST` | `/api/outward` | Process outward dispatch (verifies stock) |
| `GET` | `/api/purchase-orders` | List purchase orders |
| `POST` | `/api/purchase-orders` | Create new purchase order |
| `PUT` | `/api/purchase-orders/{id}/status?status=...` | Transition PO status |
| `GET` | `/api/alerts` | List inventory and capacity alerts |

---

## 6. Author & College Project Credits
- **Project Name**: WareFlow – Warehouse Management System
- **Submitted for**: College Major/Final Project Evaluation
- **Architecture**: Decoupled Layered REST API (Java Spring Boot + MySQL + React)
